# By adding this file, we make `rasax` a regular package, instead of a
# namespace package. This is needed as users of the old `rasa-x-ee`
# distribution will still have a `rasax` namespace package installed,
# but we want the new `rasa-x` distribution to provide all files for the
# `rasax` package (Enterprise and non-Enterprise). Regular packages take
# precedence over namespace packages with the same name.
