# flake8: noqa

# TODO(fede): This module is abandonded and I would prefer not to waste time
# writing docstrings for it.

# EXPERIMENTAL: report incoming events to an external analytics tool
import logging
import os
from functools import wraps
from typing import Any, Dict, Optional, Text, Callable

import requests
import rasax.community.telemetry as telemetry
import rasax.community.utils.common as common_utils
from rasax.community.telemetry import TELEMETRY_HTTP_TIMEOUT, SEGMENT_ENDPOINT

logger = logging.getLogger(__name__)

# EXPERIMENTAL: forward events of connected Rasa bots to analytics services,
# e.g. segment can be used for advanced KPI tracking (e.g. number of active users)
event_reporting_segment_key = os.environ.get("EXPERIMENTAL_RASAX_SEGMENT_KEY")


def ensure_reporting_is_enabled(f: Callable[..., Any]) -> Callable[..., Any]:
    """Function decorator for reporting functions that only runs the decorated
    function if the user setup a reporting service (e.g. segment)."""

    @wraps(f)
    def decorated(*args: Any, **kwargs: Any) -> Any:
        try:
            if common_utils.in_continuous_integration():
                logger.debug("Skip sending event reports: running in a CI context.")
                return
            if event_reporting_segment_key is None:
                return

            return f(*args, **kwargs)
        except Exception as e:
            logger.debug(f"Skipping reporting: {e}")

    return decorated


def _report(
    distinct_id: Text, event_name: Text, properties: Optional[Dict[Text, Any]] = None
) -> None:
    """Sends the contents of an event to the `/track` Segment endpoint.
    Documentation: https://segment.com/docs/sources/server/http/

    Args:
        distinct_id: Unique telemetry ID.
        event_name: Name of the event.
        properties: Values to send along the event.
    """
    headers = telemetry.segment_request_header(event_reporting_segment_key)
    payload = telemetry.segment_request_payload(distinct_id, event_name, properties)

    response = requests.post(
        SEGMENT_ENDPOINT, json=payload, headers=headers, timeout=TELEMETRY_HTTP_TIMEOUT
    )

    if not response.status_code < 400:
        raise Exception(f"Error sending event to segment: {response.text}")


def sanitize_event(event: Dict[Text, Any]) -> Dict[Text, Any]:
    """Remove any user specific information, data protection!"""
    sanitized_event = event.copy()

    if sanitized_event.get("text"):
        del sanitized_event["text"]

    if sanitized_event.get("parse_data", {}).get("text"):
        del sanitized_event["parse_data"]["text"]

    return sanitized_event


@ensure_reporting_is_enabled
def report_event(event: Dict[Text, Any], sender_id: Text) -> None:
    """Reports an event to an external analytics tool."""
    sanitized_event = sanitize_event(event)
    event_name = sanitized_event.get("event")
    if not event_name:
        logger.debug("Missing 'event_name' in event, skipping reporting.")
        return
    _report(sender_id, event_name, sanitized_event)
