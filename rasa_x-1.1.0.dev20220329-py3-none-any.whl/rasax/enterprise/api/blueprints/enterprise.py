import http
import logging
import time

from sanic import Blueprint, response
from sanic.request import Request
from sanic.response import HTTPResponse

import rasax.community.config as rasa_x_config
import rasax.community.constants as constants
import rasax.community.utils.common as common_utils
from rasax.community.api.decorators import rasa_x_scoped, requires_enterprise
from rasax.community.services.analytics_service import (
    AnalyticsService,
    CACHED_ANALYTICS_CONFIG,
)
from rasax.community.services.settings_service import SettingsService
from rasax.community.services.user_service import UserService

logger = logging.getLogger(__name__)


def cache_key_from_time_range(start_time, until_time, tolerance=0.1):
    """Matches a time range to an analytics cache_key within `tolerance`."""
    if not start_time:
        return None

    if not until_time:
        until_time = time.time()

    requested_timedelta = until_time - start_time

    for cache_key, v in CACHED_ANALYTICS_CONFIG.items():
        cache_timedelta = common_utils.duration_to_seconds(v["range"])
        if (
            (1 - tolerance) * requested_timedelta
            <= cache_timedelta
            <= (1 + tolerance) * requested_timedelta
        ):
            return cache_key

    return None


def blueprint() -> Blueprint:
    """Declare a collection of Enterprise-only endpoints.

    Returns:
        Sanic `Blueprint` with endpoints.
    """
    enterprise_endpoints = Blueprint("enterprise_endpoints")

    def get_cached_analytics_result(
        request, start_time, until_time, include_platform_users
    ):
        """Fetches cached analytics result from analytics_service."""
        max_age = common_utils.extract_numeric_value_from_header(
            request, "Cache-Control", "max-age"
        )
        analytics_service = AnalyticsService.from_request(request)
        cache_key = cache_key_from_time_range(start_time, until_time)
        cached_result = analytics_service.analytics_result_with_cutoff_time(
            cache_key,
            include_platform_users,
            time.time() - max_age if max_age else None,
        )

        return cached_result

    @enterprise_endpoints.route("/analytics", methods=["GET", "HEAD"])
    @rasa_x_scoped("analytics.get")
    @requires_enterprise
    async def analytics(request):
        start_time = common_utils.time_arg(request, "start", None)
        until_time = common_utils.time_arg(request, "end", None)
        window = common_utils.duration_to_seconds(
            common_utils.default_arg(request, "window")
        )

        if rasa_x_config.rasa_x_user_analytics:
            # include platform users in analytics, i.e. exclude no sender_ids
            sender_ids_to_exclude = None
        else:
            # exclude sender_ids that are platform users
            user_service = UserService.from_request(request)
            user_cursor = user_service.fetch_all_users(rasa_x_config.team_name)
            sender_ids_to_exclude = [u[constants.USERNAME_KEY] for u in user_cursor]

        result = get_cached_analytics_result(
            request,
            start_time,
            until_time,
            include_platform_users=sender_ids_to_exclude is None,
        )
        x_cache = "HIT"

        if result is None:
            analytics_service = AnalyticsService.from_request(request)
            result = analytics_service.calculate_analytics(
                start_time, until_time, window, sender_ids_to_exclude
            )
            x_cache = "MISS"

        if result is not None:
            return response.json(
                result, headers={"Cache-Control": "max-age=3600", "X-Cache": x_cache}
            )

        return common_utils.error(
            404,
            "AnalyticsNotFound",
            f"Analytics from {start_time} until {until_time} not found.",
        )

    @enterprise_endpoints.route("/environments", methods=["PUT"])
    @rasa_x_scoped("environments.update")
    @requires_enterprise
    async def save_environments(request: Request):
        environments = request.json
        settings_service = SettingsService.from_request(request)

        try:
            environments = settings_service.inspect_environments(environments)
        except (AttributeError, KeyError, ValueError) as e:
            return common_utils.error(400, "ConfigInspectionFailed", str(e))

        environments = settings_service.save_environments(
            rasa_x_config.project_name, environments
        )
        if not environments:
            return common_utils.error(
                400, "SaveEnvironmentsFailed", "Could not save environments",
            )

        return response.json(environments)

    @enterprise_endpoints.route("/environments/<name:str>", methods=["PUT"])
    @rasa_x_scoped("environments.update")
    @requires_enterprise
    async def save_environment(request: Request, name: str) -> HTTPResponse:
        environment = request.json
        settings_service = SettingsService.from_request(request)

        environment = settings_service.update_environment(
            rasa_x_config.project_name, name, environment
        )

        if not environment:
            return common_utils.error(
                400, "SaveEnvironmentFailed", "Could not save environment",
            )

        return response.json(environment)

    @enterprise_endpoints.route("/environments", methods=["POST"])
    @rasa_x_scoped("environments.create")
    @requires_enterprise
    async def create_environment(request: Request) -> HTTPResponse:
        return await save_environment(request, request.json.get("name"))

    @enterprise_endpoints.route("/environments/<name>", methods=["DELETE"])
    @rasa_x_scoped("environments.delete")
    @requires_enterprise
    async def delete_environment(request: Request, name: str) -> HTTPResponse:
        if name in constants.ENVIRONMENTS_MANDATORY_KEYS:
            return common_utils.error(
                403, "MandatoryEnvironment", "cannot delete mandatory environment",
            )

        settings_service = SettingsService.from_request(request)
        deleted = settings_service.delete_environment(rasa_x_config.project_name, name)

        if deleted is False:
            return common_utils.error(
                404, "EnvironmentNotFound", "could not find environment",
            )

        return response.text("", status=http.HTTPStatus.NO_CONTENT)

    return enterprise_endpoints
