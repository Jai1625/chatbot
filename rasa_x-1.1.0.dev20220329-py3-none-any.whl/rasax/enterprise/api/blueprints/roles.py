import logging

import rasax.community.utils.common as common_utils

from sanic import Blueprint, response
from sanic.request import Request
from urllib import parse

import rasax.community.constants as constants
from rasax.community.api.decorators import (
    rasa_x_scoped,
    validate_schema,
    inject_rasa_x_user,
    requires_enterprise,
)
from rasax.community.services.role_service import RoleService
from rasax.community.services.user_service import (
    UserException,
    UserService,
    RoleException,
)

logger = logging.getLogger(__name__)


def _role_service(request: Request) -> RoleService:
    return RoleService.from_request(request)


def _user_service(request: Request) -> UserService:
    return UserService.from_request(request)


def blueprint() -> Blueprint:
    """Declare endpoints related to roles.

    Returns:
        Sanic `Blueprint` with endpoints.
    """
    role_endpoints = Blueprint("role_endpoints")

    @role_endpoints.route("/roles", methods=["GET", "HEAD"])
    @rasa_x_scoped("roles.list")
    @requires_enterprise
    async def list_roles(request):
        role_service = _role_service(request)
        roles = role_service.roles
        roles = role_service.backend_to_frontend_format_roles(roles)
        return response.json(roles, headers={"X-Total-Count": len(roles)})

    @role_endpoints.route("/roles", methods=["POST"])
    @rasa_x_scoped("roles.create")
    @validate_schema("role")
    @requires_enterprise
    async def create_role(request):
        rjs = request.json
        role_service = _role_service(request)
        role = rjs.get("role")
        description = rjs.get("description")
        is_default = rjs.get("is_default")
        grants = rjs.get("grants")

        if role in role_service.roles:
            return common_utils.error(
                404, "RoleAlreadyExists", f"Role '{role}' already exists."
            )

        role_service.create_role(role, grants, description, is_default)

        return response.text(f"Role '{role}' created.", 201)

    @role_endpoints.route("/roles/<role>", methods=["PUT"])
    @rasa_x_scoped("roles.update")
    @validate_schema("role")
    @requires_enterprise
    async def update_role(request, role):
        rjs = request.json
        new_name = rjs.get("role", role)
        grants = rjs.get("grants")
        description = rjs.get("description")
        is_default = rjs.get("is_default")
        user_service = _user_service(request)
        role_service = _role_service(request)
        parsed_role = parse.unquote(role)

        if parsed_role not in role_service.roles:
            return common_utils.error(
                404,
                "RoleNotFound",
                f"Role '{parsed_role}' not found or could not be created.",
            )

        _role_service(request).update_role(
            parsed_role, new_name, grants, user_service, description, is_default
        )
        return response.json(
            role_service.backend_to_frontend_format_roles([new_name])[0]
        )

    @role_endpoints.route("/roles/<role>/users", methods=["PUT"])
    @rasa_x_scoped("roles.users.update")
    @validate_schema("user_list")
    @inject_rasa_x_user()
    @requires_enterprise
    async def create_or_update_role_users(request, role, user=None):
        rjs = request.json
        role_service = _role_service(request)
        parsed_role = parse.unquote(role)

        if parsed_role not in role_service.roles:
            return common_utils.error(
                404,
                "RoleNotFound",
                f"Role '{parsed_role}' not found or could not be created.",
            )

        role_users = role_service.update_role_users(
            parsed_role, rjs, _user_service(request)
        )

        return response.json(role_users, headers={"X-Total-Count": len(role_users)})

    @role_endpoints.route("/roles/<role>/users", methods=["GET", "HEAD"])
    @rasa_x_scoped("roles.users.list")
    @requires_enterprise
    async def get_role_users(request, role):
        role_service = _role_service(request)
        parsed_role = parse.unquote(role)

        if parsed_role not in role_service.roles:
            return common_utils.error(
                404, "RoleNotFound", f"Role '{parsed_role}' does not exist."
            )
        users = role_service.fetch_role_users(parsed_role)

        return response.json(users, headers={"X-Total-Count": len(users)})

    @role_endpoints.route("/roles/<role>", methods=["GET", "HEAD"])
    @rasa_x_scoped("roles.get")
    @requires_enterprise
    async def get_role(request, role):
        role_service = _role_service(request)
        parsed_role = parse.unquote(role)

        roles = role_service.roles
        if parsed_role not in roles:
            return common_utils.error(
                404, "RoleNotFound", f"Role '{parsed_role}' does not exist."
            )

        formatted_role = role_service.backend_to_frontend_format_roles([parsed_role])[0]

        return response.json(formatted_role)

    @role_endpoints.route("/roles/<role>", methods=["DELETE"])
    @rasa_x_scoped("roles.delete")
    @requires_enterprise
    async def delete_role(request, role):
        role_service = _role_service(request)
        parsed_role = parse.unquote(role)

        if parsed_role not in role_service.roles:
            return common_utils.error(404, "RoleNotFound", "Role does not exist")

        # check if role currently is assigned (can't delete assigned roles)
        user_count = role_service.count_role_users(parsed_role)
        if user_count > 0:
            return common_utils.error(
                404,
                "CannotDeleteRole",
                "Cannot delete role '{}' because is "
                "currently assigned to {} users"
                "".format(parsed_role, user_count),
            )

        role_service.delete_permissions_for_role(parsed_role)
        role_service.delete_role(parsed_role)

        return response.text("", 204)

    @role_endpoints.route("/users/<username>/roles", methods=["GET", "HEAD"])
    @rasa_x_scoped("users.roles.list")
    @requires_enterprise
    async def get_user_roles(request, username):
        user = _user_service(request).fetch_user(username)
        if user is None:
            return common_utils.error(
                404, "UserNotFound", f"User '{username}' not found"
            )
        roles = _role_service(request).backend_to_frontend_format_roles(user["roles"])
        return response.json(roles, headers={"X-Total-Count": len(roles)})

    @role_endpoints.route("/users/<username>/roles", methods=["PUT"])
    @rasa_x_scoped("users.roles.update")
    @validate_schema("role_list")
    @inject_rasa_x_user()
    @requires_enterprise
    async def update_user_roles(request, username, user=None):
        roles = request.json
        user_service = _user_service(request)
        existing_user = user_service.fetch_user(username)

        if existing_user is None:
            return common_utils.error(
                404, "UserNotFound", f"User '{username}' not found"
            )

        non_existing_roles = set(roles) - set(_role_service(request).roles)
        if non_existing_roles:
            return common_utils.error(
                404, "RoleNotFound", f"Roles '{non_existing_roles}' not found."
            )

        try:
            user_service.replace_user_roles(
                username, roles, requesting_user=user[constants.USERNAME_KEY]
            )
            return response.json(user_service.fetch_user(username))
        except RoleException as e:
            return common_utils.error(404, "UserRoleError", str(e))

    @role_endpoints.route("/users/<username>/roles/<role>", methods=["DELETE"])
    @rasa_x_scoped("users.roles.delete")
    @inject_rasa_x_user()
    @requires_enterprise
    async def delete_user_role(request, username, role, user=None):
        user_service = _user_service(request)
        parsed_role = parse.unquote(role)
        try:
            user_service.delete_user_role(
                username, parsed_role, requesting_user=user[constants.USERNAME_KEY]
            )
        except RoleException as e:
            return common_utils.error(404, "RoleNotFound", str(e))
        except UserException as e:
            return common_utils.error(404, "UserNotFound", str(e))

        return response.json(user_service.fetch_user(username))

    return role_endpoints
