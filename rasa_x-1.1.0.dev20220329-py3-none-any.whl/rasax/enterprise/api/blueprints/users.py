import http
from sanic import Blueprint, response
from sanic.response import HTTPResponse
from sanic.request import Request

import rasax.community.constants as constants
import rasax.community.utils.common as common_utils
from rasax.community import config as rasa_x_config
from rasax.community.api.decorators import (
    rasa_x_scoped,
    validate_schema,
    requires_enterprise,
)
from rasax.community.services.role_service import RoleService
from rasax.community.services.user_service import (
    RoleException,
    UserException,
    UserService,
    AuthMechanisms,
)


def blueprint() -> Blueprint:
    """Declare endpoints related to user management.

    Returns:
        Sanic `Blueprint` with endpoints.
    """
    users_endpoints = Blueprint("users_endpoints")

    @users_endpoints.route("/users", methods=["POST"])
    @rasa_x_scoped("users.create", allow_api_token=True)
    @validate_schema("user")
    @requires_enterprise
    async def create_user(request: Request) -> HTTPResponse:
        rjs = request.json
        session = request.ctx.db_session
        user_service = UserService(session)
        fullname = rjs.get("fullname")
        team = rjs.get(constants.TEAM_KEY) or rasa_x_config.team_name
        roles = rjs.get(constants.ROLES_KEY) or RoleService(session).get_default_role()

        password = rjs.get("password")
        auth_mechanism = (
            AuthMechanisms.username_password if password else AuthMechanisms.invite_code
        )

        try:
            user = user_service.create_user(
                username=rjs[constants.USERNAME_KEY],
                raw_password=password,
                fullname=fullname,
                team=team,
                roles=roles,
                auth_mechanism=auth_mechanism,
            )
        except UserException:
            return common_utils.error(
                http.HTTPStatus.CONFLICT,
                "UserCreationError",
                message=f"User with username '{rjs[constants.USERNAME_KEY]}' already exists.",
            )
        except RoleException as e:
            return common_utils.error(
                http.HTTPStatus.BAD_REQUEST, "RoleNotFound", details=e
            )

        return response.json(user, http.HTTPStatus.CREATED)

    @users_endpoints.route("/samlUsers", methods=["POST"])
    @rasa_x_scoped("users.create", allow_api_token=True)
    @validate_schema("user_saml")
    @requires_enterprise
    async def create_saml_user(request: Request) -> HTTPResponse:
        rjs = request.json
        session = request.ctx.db_session
        user_service = UserService(session)
        team = rjs.get(constants.TEAM_KEY) or rasa_x_config.team_name
        roles = rjs.get(constants.ROLES_KEY) or rasa_x_config.saml_default_role
        try:
            user = user_service.create_saml_user(
                name_id=rjs["saml_id"], team=team, roles=roles
            )
        except UserException as e:
            return common_utils.error(
                http.HTTPStatus.CONFLICT, "UserCreationError", details=e
            )
        except RoleException as e:
            return common_utils.error(
                http.HTTPStatus.BAD_REQUEST, "RoleNotFound", details=e
            )

        return response.json(user, http.HTTPStatus.CREATED)

    return users_endpoints
