from typing import Text, Dict, Any, Callable
import logging
import typing
from secrets import token_urlsafe
from urllib.parse import urlparse
from pathlib import Path
from functools import wraps

from onelogin.saml2.auth import OneLogin_Saml2_Auth
from sanic import response
from sanic_jwt import BaseEndpoint, utils as sanic_jwt_utils
from sqlalchemy.orm import Session

import rasax.community.utils.common as common_utils
from rasax.community.api.decorators import requires_enterprise
from rasax.community import config, constants
from rasax.community.database.utils import session_scope
from rasax.community.services.role_service import RoleService
from rasax.community.services.user_service import UserService

if typing.TYPE_CHECKING:
    from sanic.request import Request
    from sanic.response import HTTPResponse

SAML_CONFIG_FILE = "settings.json"


logger = logging.getLogger(__name__)


class SAMLConfigurationError(Exception):
    """Exception raised when SAML has not been properly configured by the user."""


def init_saml_auth(prepared_request: Dict) -> OneLogin_Saml2_Auth:
    """Perform SAML auth with prepared request.

    Args:
        prepared_request: Prepared Sanic request for SAML.

    Returns:
        'OneLogin_Saml2_Auth' object.

    """
    config_file_path = Path(config.saml_path, SAML_CONFIG_FILE)
    if not config_file_path.is_file():
        raise SAMLConfigurationError(
            f"Could not perform SAML authentication: missing '{config_file_path}' "
            f"configuration file.\nPlease visit "
            f"{constants.RASA_X_DOCS_URL}/enterprise/single-sign-on for more "
            f"information."
        )

    return OneLogin_Saml2_Auth(prepared_request, custom_base_path=config.saml_path)


def request_protocol(request: "Request") -> Text:
    """Gets protocol of `request`.

    First, we check if `x-forwarded-proto` header is present (in case there's a
    reverse proxy in front of Rasa X).

    Second, if the above didn't work, we fallback to Sanic's `scheme`.

    Args:
        request Sanic `Request` to inspect.

    Returns:
        Request protocol (usually http or https).

    """
    return request.headers.get("x-forwarded-proto", request.scheme)


def prepare_sanic_request_for_saml(request: "Request") -> Dict[Text, Any]:
    """Prepare request for SAML ACS processing.

    Args:
        request: Sanic `Request` to be prepared.

    Returns:
        Processed request.

    """
    post_data = dict()

    for k, v in request.form.items():
        if isinstance(v, list) and len(v) == 1:
            post_data[k] = v[0]
        else:
            post_data[k] = v

    return dict(
        https="on" if request_protocol(request) == "https" else "off",
        http_host=request.host,
        server_port=urlparse(request.url).port,
        script_name=request.path,
        get_data=request.args.copy(),
        post_data=post_data,
    )


def requires_saml_configured(f: Callable) -> Callable:
    """Ensure SAML is properly configured before accessing an endpoint.

    Args:
        f: Endpoint to decorate.

    Returns:
        Decorated endpoint.
    """

    @wraps(f)
    async def wrapped(self, request, *args, **kwargs):
        try:
            return await f(self, request, *args, **kwargs)
        except SAMLConfigurationError as e:
            return common_utils.error(400, "SAMLConfigurationError", details=str(e))

    return wrapped


class EnterpriseTokenLogin(BaseEndpoint):
    """Adapted from sanic_jwt.endpoints.AuthenticateEndpoint."""

    @requires_enterprise
    async def post(self, request, *args, **kwargs) -> "HTTPResponse":
        """Execute POST for /enterpriseTokenLogin.

        Args:
            request: HTTP request.

        Returns:
            HTTP response.
        """
        request, args, kwargs = await self.do_incoming(request, args, kwargs)

        user = await sanic_jwt_utils.call(
            self.instance.auth.authenticate, request, *args, **kwargs
        )

        access_token, output = await self.responses.get_access_token_output(
            request, user, self.config, self.instance
        )

        if self.config.refresh_token_enabled():
            refresh_token = await sanic_jwt_utils.call(
                self.instance.auth.generate_refresh_token, request, user
            )
            output.update({self.config.refresh_token_name(): refresh_token})
        else:
            refresh_token = None

        output.update(
            self.responses.extend_authenticate(
                request,
                user=user,
                access_token=access_token,
                refresh_token=refresh_token,
            )
        )

        output = await self.do_output(output)
        resp = self.responses.get_token_response(
            request,
            access_token,
            output,
            refresh_token=refresh_token,
            config=self.config,
        )

        return await self.do_response(resp)


class SAMLmetadata(BaseEndpoint):
    """Represents a collection of SAML-related endpoints."""

    @requires_enterprise
    @requires_saml_configured
    async def get(self, request, *args, **kwargs) -> "HTTPResponse":
        """Execute GET for /saml/metadata.

        Args:
            request: HTTP request.

        Returns:
            HTTP response.
        """
        prepared_request = prepare_sanic_request_for_saml(request)
        auth = init_saml_auth(prepared_request)
        settings = auth.get_settings()
        _metadata = settings.get_sp_metadata()
        errors = settings.validate_metadata(_metadata)

        if not errors:
            return response.text(_metadata, content_type="text/xml")
        else:
            error_message = "Failed to validate SAML metadata of the service provider"
            logger.error(f"{error_message}:\n{errors}")
            return common_utils.error(
                500, "MetadataValidationFailed", error_message, errors
            )


class SAMLauth(BaseEndpoint):
    """Represents a collection of SAML-related endpoints."""

    @requires_enterprise
    @requires_saml_configured
    async def get(self, request, *args, **kwargs):
        """Execute GET for /saml.

        Args:
            request: HTTP request.

        Returns:
            HTTP response.
        """
        prepared_request = prepare_sanic_request_for_saml(request)
        auth = init_saml_auth(prepared_request)
        a = auth.login()
        return response.json({"redirect_to": a})


class SAMLacs(BaseEndpoint):
    """Represents a collection of SAML-related endpoints."""

    @staticmethod
    def _user_service(session: Session) -> UserService:
        return UserService(session)

    @staticmethod
    def _role_service(session: Session) -> RoleService:
        return RoleService(session)

    @requires_enterprise
    @requires_saml_configured
    async def post(self, request, *args, **kwargs) -> "HTTPResponse":
        """Execute POST for /saml/acs.

        Args:
            request: HTTP request.

        Returns:
            HTTP response.
        """
        prepared_request = prepare_sanic_request_for_saml(request)
        auth = init_saml_auth(prepared_request)
        auth.process_response()
        errors = auth.get_errors()

        if errors:
            return common_utils.error(
                500,
                "SamlAcsRequestError",
                "Could not validate ACS request.",
                details=dict(
                    errors=errors,
                    prepared_request=prepared_request,
                    reason=auth.get_last_error_reason(),
                ),
            )

        if not auth.is_authenticated():
            return common_utils.error(
                401,
                "SamlAuthenticationFailed",
                "Could not authenticate SAML ACS request.",
            )

        # Issue a static dummy name ID in development. SimpleSAMLphp issues
        # an ephemeral name ID which is not useful for development purposes.
        if config.development_mode:
            name_id = "dummy_name_id"
        else:
            name_id = auth.get_nameid()

        with session_scope() as session:
            # check user exists, create one if it doesn't
            user_service = self._user_service(session)
            role_service = self._role_service(session)

            user = user_service.fetch_saml_user(name_id)
            if not user:
                user_service.create_saml_user(
                    name_id=name_id,
                    team=config.team_name,
                    roles=config.saml_default_role or role_service.get_default_role(),
                )

            # generate single-use token and update user object with a token
            # lifetime of 60 seconds
            token = token_urlsafe(64)
            user_service.update_single_use_token(name_id, token, lifetime=60.0)

        return response.redirect(f"/enterprise-login/{token}")
