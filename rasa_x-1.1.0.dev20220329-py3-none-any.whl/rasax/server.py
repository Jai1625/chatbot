from pathlib import Path

import logging
import time
import os
from ssl import SSLContext
import typing
from typing import Union, Tuple, Text, Any, Optional

from sqlalchemy.orm import Session
import sqlalchemy.exc

from rasax.community import global_state
from rasax.community.services.domain_service import DomainService
import rasax.initialise
import rasax.community.jwt
import rasax.community.sql_migrations as sql_migrations
import rasax.community.constants as constants
import rasax.community.utils.cli as cli_utils
import rasax.community.utils.common as common_utils
from rasax.community import config, telemetry, scheduler
from rasax.community.api.app import configure_app, initialize_app
from rasax.community.database import utils as db_utils
from rasax.community.services.settings_service import SettingsService
from rasax.community.services.license_service import (
    LicenseService,
    EnterpriseLicense,
)
from rasax.community.services.user_service import UserService
from rasax.community.services import model_service

if typing.TYPE_CHECKING:
    from multiprocessing import Process

logger = logging.getLogger(__name__)
logging.getLogger("alembic.runtime.migration").setLevel(logging.WARNING)

NUMBER_OF_SANIC_WORKERS = 4


def protocol(ssl_context: Optional[SSLContext]) -> Text:
    """Get the `http` protocol to use.

    Args:
        ssl_context: The current SSL context.

    Returns:
        `https` if there is a SSL context, else `http`
    """
    return "https" if ssl_context else "http"


def create_ssl_context(
    ssl_certificate: Optional[Text],
    ssl_keyfile: Optional[Text],
    ssl_ca_file: Optional[Text] = None,
    ssl_password: Optional[Text] = None,
) -> Optional["SSLContext"]:
    """Create an SSL context if a proper certificate is passed.

    Args:
        ssl_certificate: path to the SSL client certificate
        ssl_keyfile: path to the SSL key file
        ssl_ca_file: path to the SSL CA file for verification (optional)
        ssl_password: SSL private key password (optional)

    Returns:
        SSL context if a valid certificate chain can be loaded, `None` otherwise.
    """
    if ssl_certificate:
        import ssl

        ssl_context = ssl.create_default_context(
            purpose=ssl.Purpose.CLIENT_AUTH, cafile=ssl_ca_file
        )
        ssl_context.load_cert_chain(
            ssl_certificate, keyfile=ssl_keyfile, password=ssl_password
        )
        return ssl_context
    else:
        return None


def additional_auth_endpoints() -> Union[Tuple[()], Tuple[Tuple[Text, Any], ...]]:
    """Returns Enterprise-only authentication endpoints.

    If a SAML-related import fails, no endpoints will be returned.

    Returns:
        Endpoints related to authentication for Enterprise.
    """
    try:
        from rasax.enterprise.api.auth.saml import (
            SAMLauth,
            SAMLacs,
            SAMLmetadata,
            EnterpriseTokenLogin,
        )

        return (
            ("/enterpriseTokenLogin", EnterpriseTokenLogin),
            ("/saml", SAMLauth),
            ("/saml/metadata", SAMLmetadata),
            ("/saml/acs", SAMLacs),
        )
    except ImportError:
        cli_utils.print_error(
            "The SAML authentication endpoints require an installation of "
            "`python3-saml`. Please run `sudo apt-get install libxml2 libxmlsec1 "
            "&& pip install python3-saml`.\nContinuing anyway without "
            "SAML authentication endpoints."
        )

    return ()


def log_license_information(session: Session) -> None:
    """Logs (debug) information about any existing Enterprise license in the database.

    Args:
        session: SQLAlchemy session.
    """
    license_service = LicenseService(session)

    logger.debug("Enterprise license information:")

    encoded = license_service.retrieve_encoded_license()
    if not encoded:
        logger.debug("Did not find an Enterprise license in the database.")
        return

    try:
        enterprise_license = EnterpriseLicense.decode(encoded)
        logger.debug(f"License payload: {enterprise_license.as_dict()}.")
    except Exception as e:
        logger.debug(f"Unable to decode license: {e}")


def _initialize_server_mode() -> None:
    """Run additional processes after the database migration is done."""
    common_utils.update_log_level()

    # Wait for the DB migration that is running as a separate service
    if config.should_run_database_migration_separately:
        logger.debug(
            f"Environment variable '{constants.DATABASE_MIGRATION_SEPARATION_ENV}' "
            f"set to 'True', meaning Rasa X expects the database migration "
            f"to run as a separate service."
        )

        common_utils.run_in_loop(db_utils.wait_for_migrations(quiet=True))

    with db_utils.session_scope() as session:
        # Start the database migration within the process if
        # `DATABASE_MIGRATION_SEPARATION_ENV` is `False`.
        if not config.should_run_database_migration_separately:
            # Change logging level for alembic.runtime.migration
            logging.getLogger("alembic.runtime.migration").setLevel(logging.INFO)

            try:
                sql_migrations.run_migrations(session)
            except Exception as e:
                import signal

                logger.exception(e)
                logger.error("Cannot run the database migration, terminating...")
                os.killpg(os.getpgid(os.getppid()), signal.SIGTERM)

        users_exist = UserService(session).get_number_of_users()
        username, password = rasax.initialise.setup_initial_admin_user(
            session, create=(not users_exist)
        )
        if username and password:
            cli_utils.print_success(
                f"The login password for user '{username}' is '{password}'. Note: "
                "this message will be shown only once."
            )

        log_license_information(session)

        project_path = Path(config.local_project_path)
        domain_path = str(project_path / config.default_domain_path)
        data_path = str(project_path / config.data_dir)
        config_path = str(project_path / config.default_config_path)

        common_utils.run_in_loop(
            _initialize_with_local_data(
                project_path, data_path, session, config_path, domain_path,
            )
        )

        rasax.initialise.setup_blueprints_demo_objects(session)

        # fork telemetry loop and background scheduler
        process = initialise_server_mode(session)

    launch_event_service()
    telemetry.track_server_start()

    # Run models discovery
    logger.debug("Models discovery start.")
    common_utils.run_in_loop(model_service.discover_models())
    logger.debug("Models discovery end.")

    # We need to keep the process where _initialize_server_mode was called alive
    # to avoid creating multiple orphan processes. It's not strictly necessary
    # but it is a good practice. If the scheduler is being killed, then it means
    # the entire Rasa X server is probably being restarted anyways.
    process.join()


def initialise_server_mode(session: Session) -> "Process":
    """Initialise common configuration for the server mode.

    Args:
        session: An established database session.

    Returns:
        The process which runs the background scheduler.
    """
    # Initialize environments before they are used in the model discovery process
    settings_service = SettingsService(session)
    settings_service.inject_environments_config_from_file(
        config.project_name, config.default_environments_config_path
    )

    # Initialize telemetry
    telemetry.initialize_from_db(session)

    # Start background scheduler in separate process
    return scheduler.start_background_scheduler()


def _event_service() -> None:
    from rasax.community.services.event_service import main as event_service_main

    event_service_main(should_run_liveness_endpoint=False)


def launch_event_service() -> None:
    """Starts the event service in a `multiprocessing.Process`.

    This only happens if `EVENT_CONSUMER_SEPARATION_ENV` is `True`, otherwise
    this function does nothing.
    """
    if config.should_run_event_consumer_separately:
        logger.debug(
            f"Environment variable '{constants.EVENT_CONSUMER_SEPARATION_ENV}' "
            f"set to 'True', meaning Rasa X expects the event consumer "
            f"to run as a separate service."
        )
    else:
        logger.debug("Starting event service from Rasa X.")

        common_utils.run_in_process(fn=_event_service, daemon=True)


def safe_is_enterprise_activated(
    db_session: Optional[Session] = None,
    default: bool = True,
    timeout: int = 5,
    sleep_time: int = 1,
) -> bool:
    """Checks if the current server is running Rasa Enterprise.

    If the database has not been setup yet, avoid raising an exception and
    instead return `default`. This function should only be used in contexts
    where we need to check if Enterprise is activated or not, but there is a
    chance that the database has not been setup yet. This happens mostly in
    server initialization code.

    Do not use this function for general license checking. See
    `LicenseService.is_enterprise_activated` instead.

    Args:
        db_session: Optional SQLAlchemy session to use.
        default: Value to return if the database has not been set up.
        timeout: Maximum time in seconds to wait when checking for the
            availability of the configuration table.
        sleep_time: Time in seconds to sleep between checks.

    Returns:
        `True` if Rasa Enterprise is activated, `False` if it is not, or
        `default` if the database has not been setup yet.
    """
    from rasax.community.database.admin import ConfigValue

    with db_utils.try_reuse_session_scope(db_session) as session:
        start = time.time()
        names = []

        while (time.time() - start) < timeout:
            try:
                names = db_utils.get_table_names(session)
                break
            except sqlalchemy.exc.OperationalError:
                # Database may still be starting up.
                time.sleep(sleep_time)

        # Avoid querying the DB if the table does not exist, in order to avoid
        # confusing error logs appearing in the DB container.
        if ConfigValue.__tablename__ not in names:
            return default

        try:
            return LicenseService.is_enterprise_activated(session)
        except sqlalchemy.exc.SQLAlchemyError:
            return default


async def _initialize_with_local_data(
    project_path: Path,
    data_path: Text,
    session: Session,
    config_path: Text,
    domain_path: Text,
) -> None:
    if not os.path.exists(project_path):
        logger.debug(
            "Skipping initial project ingestion: project folder doesn't exist."
        )
        return
    if not os.path.isdir(project_path) or not os.listdir(project_path):
        logger.debug("Skipping initial project ingestion: project folder seems empty.")
        return

    logger.debug("Ingesting project from disk to database")

    try:
        # inject data
        await rasax.initialise.inject_files_from_disk(
            project_path,
            data_path,
            session,
            config_path=config_path,
            domain_path=domain_path,
            username=config.SYSTEM_USER,
        )

        # dump domain once
        domain_service = DomainService(session)
        domain_service.dump_domain(config.project_name)

    except rasax.initialise.InjectionError as e:
        logger.debug(f"An error happened while ingesting the local project: {e}")
        cli_utils.print_error_and_exit(str(e))


def main() -> None:
    """Entry point for Rasa X and Rasa Enterprise Server mode."""
    common_utils.update_log_level()
    logger.debug("Starting API service.")

    # Initialize error reporting (for main process only)
    telemetry.initialize_error_reporting()

    global_state.initialize_global_state(NUMBER_OF_SANIC_WORKERS)

    app = configure_app()
    ssl_context = None

    rasax.community.jwt.initialise_jwt_keys()

    enterprise = safe_is_enterprise_activated()
    if enterprise:
        ssl_context = create_ssl_context(
            ssl_certificate=config.ssl_certificate,
            ssl_keyfile=config.ssl_keyfile,
            ssl_ca_file=config.ssl_ca_file,
            ssl_password=config.ssl_password,
        )

    initialize_app(app, class_views=additional_auth_endpoints())

    # Run initialization processes in background after the db migrations is done
    common_utils.run_in_process(_initialize_server_mode, daemon=False)

    cli_utils.print_success(
        f"Starting Rasa X/Enterprise server ({protocol(ssl_context)})... 🚀"
    )

    app.run(
        host="0.0.0.0",
        port=config.self_port,
        auto_reload=os.environ.get("SANIC_AUTO_RELOAD"),
        workers=NUMBER_OF_SANIC_WORKERS,
        ssl=ssl_context,
    )
