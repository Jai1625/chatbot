from rasax.community import version

# TODO(fede): If we have __version__ here, do we really need version.py...?  We
# could update the release/freeze scripts so that they write to this file
# directly. Even better, we could write this to rasax/__init__.py so that it's
# not inside the community module.
__version__ = version.__version__

del version
