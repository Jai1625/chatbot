import logging
import os
import re
import subprocess
from asyncio import AbstractEventLoop
from multiprocessing import Process
from typing import Text

import pkg_resources
from sanic import Blueprint, response, Sanic
from sanic.exceptions import NotFound
from sanic.request import Request
from sanic.response import text, HTTPResponse
from sanic.compat import open_async

import rasax.community
import rasax.community.utils.cli as cli_utils
import rasax.community.utils.io as io_utils
import rasax.community.constants as constants
import rasax.community.config as config

logger = logging.getLogger(__name__)

PACKAGE_INTERFACE_DIRECTORY = pkg_resources.resource_filename(
    rasax.community.__name__, "interface"
)

# project root, I know, lots of .. :D
root_dir = os.path.join(
    os.path.dirname(os.path.realpath(__file__)), "..", "..", "..", "..", "..", ".."
)

BUILD_IN_PROGRESS_INDEX_HTML = (
    '<html><head><meta http-equiv="refresh" content="1"></head>'
    "<body>Frontend is compiling...<body></html>"
)


def _write_index_html(path, text):
    if not os.path.exists(path):
        os.mkdir(path)
    index = os.path.join(path, "index.html")
    io_utils.write_file(index, text.encode("utf-8"), mode="wb")
    return index


def _run_build(cwd: Text, output: Text) -> None:
    cli_utils.print_info("Building frontend (development mode)...")
    # this will always use the frontend enterprise build, as in this case we
    # have the source anyways (won't happen in packaged build)
    if subprocess.call(["make", "install-frontend"], cwd=cwd):
        cli_utils.print_error(
            "Failed to install frontend dependencies. Check logs for details."
        )
        _write_index_html(
            output, "Frontend install failed! Check the logs for details."
        )
    elif subprocess.call(["make", "build-frontend"], cwd=cwd):
        cli_utils.print_error("Failed to build frontend code. Check logs for details.")
        _write_index_html(output, "Frontend build failed! Check the logs for details.")
    else:
        cli_utils.print_success(
            "Finished building frontend, serving from {}."
            "".format(os.path.abspath(output))
        )


def build_interface() -> Text:
    """Compile the frontend using the repos make file and move it to a temp dir.

    Returns the temporary directory containing the compiled frontend.
    """
    frontend_directory = os.path.join(root_dir, "src", "rasa-frontend", "build")

    p = Process(target=_run_build, args=(root_dir, frontend_directory))
    p.daemon = True
    p.start()

    return frontend_directory


def locate_interface() -> Text:
    """Check if there is a packaged interface - if not build it from source.

    Returns the path to the interface directory.
    """
    pkg_base = PACKAGE_INTERFACE_DIRECTORY

    pkg_index = os.path.join(pkg_base, "index.html")
    if os.path.exists(pkg_index):
        return pkg_base
    else:
        if not config.skip_frontend_build:
            return build_interface()
        else:
            external_frontend = os.getenv(
                "EXTERNAL_FRONTEND",
                os.path.join(root_dir, "src", "rasa-frontend", "build"),
            )
            cli_utils.print_info(
                f"Using external frontend build.\nMake sure there is a frontend build "
                f"available in '{os.path.abspath(external_frontend)}'."
            )
            return external_frontend


async def change_root_url(
    root_url: Text, api_root_url: Text, file: Text
) -> HTTPResponse:
    """Load a file and rewrite its relative URL attributes with the configured root URL."""
    async with await open_async(file, mode="rb") as f:
        page = await f.read()
        page = page.decode("utf-8")
        # Replace resource URLs
        page = re.sub(r"=\"/", f'="{root_url}/', page)
        # Inform the frontend JavaScript runtime
        page = re.sub(r"__SERVER_DATA__", f'{{"api_url": "{api_root_url}"}}', page)
        return response.html(page)


def blueprint() -> Blueprint:
    """Serve the Rasa X interface."""
    interface_directory = locate_interface()

    index_html = os.path.join(interface_directory, "index.html")

    interface = Blueprint("interface")

    # Static files and folders
    static = ["robots.txt", "static", "icons", "fonts"]

    for s in static:
        interface.static(f"/{s}", os.path.join(interface_directory, s))

    @interface.route("/", methods=["GET", "HEAD"])
    async def index(request: Request) -> HTTPResponse:
        if os.path.exists(index_html):
            if config.root_url or config.api_root_url:
                return await change_root_url(
                    config.root_url, config.api_root_url, index_html
                )

            return await response.file(index_html)
        else:
            return response.html(BUILD_IN_PROGRESS_INDEX_HTML)

    async def ignore_404s(request: Request, exception: Exception) -> HTTPResponse:
        if request.path.startswith(constants.API_URL_PREFIX):
            # tries to avoid answering any API calls with
            # the frontend response
            return text("Not found.", status=404)
        logger.debug(f"Answered 404 with index.html. Request url '/': '{request.url}'")
        # we need this, as the frontend does its own routing, but needs
        # the server to always deliver the index.html to not interfere
        return await index(request)

    @interface.listener("main_process_start")
    async def register_frontend_error_handler(app: Sanic, _: AbstractEventLoop) -> None:
        """Register global error handler for UI redirection.

        The `blueprint.exception` decorator only registers error handlers in the scope
        of the blueprint. However, we need the redirection to work globally.

        Args:
            app: The Sanic instance.
            _: The event loop.
        """
        app.error_handler.add(NotFound, ignore_404s)

    return interface
