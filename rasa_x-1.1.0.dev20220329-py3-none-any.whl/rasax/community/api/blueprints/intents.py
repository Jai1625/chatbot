import logging

from sanic import Blueprint, response
from sanic.request import Request

import rasax.community.utils.common as common_utils
from rasax.community.api.decorators import rasa_x_scoped, validate_schema
from rasax.community.services.intent_service import (
    IntentService,
    INTENT_NAME_KEY,
    INTENT_EXAMPLES_KEY,
    INTENT_SUGGESTIONS_KEY,
)

logger = logging.getLogger(__name__)


def _intent_service(request: Request) -> IntentService:
    return IntentService.from_request(request)


def blueprint() -> Blueprint:
    """Declare endpoints for NLU intents management.

    Returns:
        Blueprint with endpoints for NLU intents management.
    """
    intent_endpoints = Blueprint("intent_endpoints")

    @intent_endpoints.route("/projects/<project_id>/intents", methods=["GET", "HEAD"])
    @rasa_x_scoped("intents.list")
    async def get_intents(request, project_id):
        include_temporary_intents = common_utils.bool_arg(request, "is_temporary", True)
        included_fields = common_utils.fields_arg(
            request, {INTENT_SUGGESTIONS_KEY, INTENT_EXAMPLES_KEY}
        )

        intents = await _intent_service(request).get_intents(
            project_id, include_temporary_intents, included_fields
        )
        return response.json(intents, headers={"X-Total-Count": len(intents)})

    @intent_endpoints.route("/projects/<project_id>/intents", methods=["POST"])
    @rasa_x_scoped("intents.create")
    @validate_schema("intent/new")
    async def create_intent(request, project_id):
        intent = request.json
        intent_service = _intent_service(request)
        existing_intents = intent_service.get_permanent_intents(project_id)
        if intent[INTENT_NAME_KEY] not in existing_intents:
            intent_service.add_temporary_intent(intent, project_id)

        return response.text(
            "Intent '{}' created.".format(intent.get(INTENT_NAME_KEY)), 201
        )

    @intent_endpoints.route(
        "/projects/<project_id>/intents/<intent_id>", methods=["PUT"]
    )
    @rasa_x_scoped("intents.update")
    @validate_schema("intent")
    async def update_intent(request, intent_id, project_id):
        intent = request.json

        intent_service = _intent_service(request)
        existing_intents = intent_service.get_permanent_intents(project_id)
        if intent[INTENT_NAME_KEY] not in existing_intents:
            intent_service.update_temporary_intent(intent_id, intent, project_id)

        return response.text(f"Intent '{intent_id}' updated.", 200)

    @intent_endpoints.route(
        "/projects/<project_id>/intents/<intent_id>", methods=["DELETE"]
    )
    @rasa_x_scoped("intents.delete")
    async def delete_intent(request, intent_id, project_id):
        _intent_service(request).delete_temporary_intent(intent_id, project_id)

        return response.text(f"Temporary intent '{intent_id}' deleted.", 200)

    return intent_endpoints
