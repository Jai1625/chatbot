import http

from sanic import Blueprint, response
from sanic.request import Request
from sanic.response import HTTPResponse

import rasax.community.api.decorators
import rasax.community.utils.common
from rasax.community.services.license_service import (
    LicenseService,
    LicenseValidationException,
)


def blueprint() -> Blueprint:
    """Declare endpoints for Enterprise license management.

    Returns:
        Blueprint with endpoints.
    """
    license_endpoints = Blueprint("license_endpoints")

    @license_endpoints.route("/license", methods=["GET", "HEAD"])
    @rasax.community.api.decorators.rasa_x_scoped(
        "enterpriseLicense.get", allow_api_token=True
    )
    async def get_license(request: Request) -> HTTPResponse:
        """Return information about a stored Enterprise license in the database.

        Args:
            request: Received HTTP request.

        Returns:
            HTTP 200 response with license information, if a license is present.
            HTTP 404 if no license is present.
        """
        license_service = LicenseService.from_request(request)
        encoded_license = license_service.retrieve_encoded_license()
        enterprise_license = license_service.retrieve_validated_enterprise_license()

        if not encoded_license:
            return rasax.community.utils.common.error(
                http.HTTPStatus.NOT_FOUND,
                "NoLicensePresent",
                "No Rasa Enterprise license is present.",
            )

        result = {
            "encoded": encoded_license,
            "decoded": enterprise_license.as_dict() if enterprise_license else None,
            "valid": enterprise_license is not None,
        }

        return response.json(result)

    @license_endpoints.route("/license", methods=["POST"])
    @rasax.community.api.decorators.rasa_x_scoped(
        "enterpriseLicense.create", allow_api_token=True
    )
    @rasax.community.api.decorators.validate_schema("enterprise_license")
    async def add_license(request: Request) -> HTTPResponse:
        """Validate and store a Rasa Enterprise license in the database.

        If the provided license is valid, then this endpoint effectively
        transforms this Rasa X instance into a Rasa Enterprise instance.

        If the provided license is valid, and there was already a license
        stored in the database, the old one will be overwritten.

        Args:
            request: Received HTTP request.

        Returns:
            HTTP 201 response, when the provided license was valid.
            HTTP 400, if the license was not valid.
        """
        encoded_license = request.json["license"]
        license_service = LicenseService.from_request(request)

        try:
            enterprise_license = license_service.validate_and_store_license(
                encoded_license
            )

            return response.json(
                enterprise_license.as_dict(), status=http.HTTPStatus.CREATED
            )
        except LicenseValidationException as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.BAD_REQUEST,
                "LicenseValidationException",
                "Could not validate license.",
                details=e,
            )

    @license_endpoints.route("/license", methods=["DELETE"])
    @rasax.community.api.decorators.rasa_x_scoped(
        "enterpriseLicense.delete", allow_api_token=True
    )
    async def delete_license(request: Request) -> HTTPResponse:
        """Delete any enterprise license stored in the database.

        If a valid license was present, this implies Enterprise features will
        be disabled.

        Args:
            request: Received HTTP request.

        Returns:
            HTTP 200, if a license was present and deleted.
            HTTP 404, if no license was present.
        """
        license_service = LicenseService.from_request(request)
        if not license_service.retrieve_encoded_license():
            return rasax.community.utils.common.error(
                http.HTTPStatus.NOT_FOUND,
                "NoLicensePresent",
                "No Rasa Enterprise license is present.",
            )

        license_service.delete_license()
        return response.text("", status=http.HTTPStatus.NO_CONTENT)

    return license_endpoints
