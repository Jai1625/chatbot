from http import HTTPStatus
from typing import Text

from rasax.community.api.decorators import validate_schema, rasa_x_scoped
from sanic import Blueprint, response
from sanic.request import Request

import rasax.community.utils.common as common_utils
from rasax.community.services.assistant_service import (
    AssistantService,
    DuplicateBusinessLogicFlowException,
    BusinessLogicFlowParseException,
    DuplicateSampleConversationException,
    BulkCreateException,
    SampleConversationNotFound,
)


def blueprint() -> Blueprint:
    """Declare endpoints for the assistant.

    Returns:
        Blueprint with endpoints related to the assistant.
    """
    assistant_endpoints = Blueprint("assistant_endpoints")

    @assistant_endpoints.route("/business_logic_flows", methods=["GET"])
    @rasa_x_scoped("blueprints.list")
    async def list_business_logic_flows(request: Request) -> response.HTTPResponse:
        """Lists business logic flows.

        Args:
            request: The incoming request.

        Returns:
            Response with a paginated list of business logic flows.
        """
        assistant_service = AssistantService.from_request(request)

        limit = common_utils.int_arg(request, "limit")
        offset = common_utils.int_arg(request, "offset")
        search = common_utils.default_arg(request, "q", None)
        exclude_linked_conversation_id = common_utils.int_arg(
            request, "exclude_linked_conversation_id", None
        )
        exclude_demos = common_utils.bool_arg(request, "exclude_demos", default=False)

        flows, total = assistant_service.fetch_flows(
            limit=limit,
            offset=offset,
            search=search,
            exclude_linked_conversation_id=exclude_linked_conversation_id,
            exclude_demos=exclude_demos,
        )

        return response.json(flows, headers={"X-Total-Count": total})

    @assistant_endpoints.route("/business_logic_flows/<flow_id>", methods=["GET"])
    @rasa_x_scoped("blueprints.get")
    async def show_business_logic_flow(
        request: Request, flow_id: Text
    ) -> response.HTTPResponse:
        """Shows a business logic flow.

        Args:
            request: The incoming request.
            flow_id: The ID of the Business Logic Flow.

        Returns:
            Response with the Business Logic Flow.
        """
        assistant_service = AssistantService.from_request(request)
        flow = assistant_service.get_flow(flow_id)

        if flow is None:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "BusinessLogicFlowNotFound",
                details="Could not find a business logic flow with the given ID.",
            )

        return response.json(flow.as_dict(include_elements=True))

    @assistant_endpoints.route("/business_logic_flows", methods=["POST"])
    @validate_schema("business_logic_flow")
    @rasa_x_scoped("blueprints.create")
    async def create_business_logic_flow(request: Request) -> response.HTTPResponse:
        """Creates a new business logic flow.

        Args:
            request: The incoming request.

        Returns:
            Response that contains the newly created  flow.
        """
        assistant_service = AssistantService.from_request(request)

        rjs = request.json
        name = rjs.get("name")
        elements = rjs.get("elements")
        description = rjs.get("description")

        try:
            flow = assistant_service.create_flow(
                name, elements, description=description
            )
            return response.json(
                flow.as_dict(include_elements=True), HTTPStatus.CREATED
            )
        except (BusinessLogicFlowParseException, ValueError) as e:
            return common_utils.error(
                HTTPStatus.BAD_REQUEST, "CreateBusinessLogicFlowFailed", details=e,
            )
        except DuplicateBusinessLogicFlowException:
            return common_utils.error(
                HTTPStatus.UNPROCESSABLE_ENTITY,
                "DuplicateBusinessLogicFlowName",
                "A Business Logic Flow with the same name already exists.",
            )

    @assistant_endpoints.route("/business_logic_flows/<flow_id>", methods=["PATCH"])
    @validate_schema("patch_business_logic_flow")
    @rasa_x_scoped("blueprints.update")
    async def update_business_logic_flow(
        request: Request, flow_id: Text
    ) -> response.HTTPResponse:
        """Updates an existing business logic flow.

        Args:
            request: The incoming request.
            flow_id: The ID of the Business Logic Flow.

        Returns:
            The updated business logic flow, otherwise Not Found.
        """
        assistant_service = AssistantService.from_request(request)

        rjs = request.json

        try:
            flow = assistant_service.update_flow(flow_id, rjs)
            return response.json(flow.as_dict(include_elements=True), HTTPStatus.OK)
        except ValueError:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "BusinessLogicFlowNotFound",
                details="Could not find a business logic flow with the given ID.",
            )
        except DuplicateBusinessLogicFlowException:
            return common_utils.error(
                HTTPStatus.UNPROCESSABLE_ENTITY, "DuplicateBusinessLogicFlowName"
            )
        except BusinessLogicFlowParseException as e:
            return common_utils.error(
                HTTPStatus.BAD_REQUEST, "UpdateBusinessLogicFlowFailed", details=e,
            )

    @assistant_endpoints.route("/business_logic_flows/<flow_id>", methods=["DELETE"])
    @rasa_x_scoped("blueprints.delete")
    async def delete_business_logic_flow(
        request: Request, flow_id: Text
    ) -> response.HTTPResponse:
        """Deletes an existing business logic flow.

        Args:
            request: The incoming request.
            flow_id: The ID of the Business Logic Flow.

        Returns:
            Empty response when business logic flow has been deleted, otherwise Not Found.
        """
        assistant_service = AssistantService.from_request(request)

        try:
            assistant_service.delete_flow(flow_id)
            return response.text("", HTTPStatus.NO_CONTENT)
        except ValueError:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "BusinessLogicFlowNotFound",
                details="Could not find a business logic flow with the given ID.",
            )

    @assistant_endpoints.route("/sample_conversations", methods=["GET"])
    @rasa_x_scoped("blueprints.list")
    async def list_sample_conversations(request: Request) -> response.HTTPResponse:
        """Lists sample conversations.

        Args:
            request: The incoming request.

        Returns:
            Response with a paginated list of sample conversations.
        """
        assistant_service = AssistantService.from_request(request)

        limit = common_utils.int_arg(request, "limit")
        offset = common_utils.int_arg(request, "offset")
        search = common_utils.default_arg(request, "q", None)
        exclude_linked_flow_id = common_utils.int_arg(
            request, "exclude_linked_flow_id", None
        )
        exclude_demos = common_utils.bool_arg(request, "exclude_demos", default=False)

        conversations, total = assistant_service.fetch_sample_conversations(
            limit=limit,
            offset=offset,
            search=search,
            exclude_linked_flow_id=exclude_linked_flow_id,
            exclude_demos=exclude_demos,
        )

        return response.json(conversations, headers={"X-Total-Count": total})

    @assistant_endpoints.route(
        "/sample_conversations/<sample_conversation_id>", methods=["GET"]
    )
    @rasa_x_scoped("blueprints.get")
    async def show_sample_conversation(
        request: Request, sample_conversation_id: Text
    ) -> response.HTTPResponse:
        """Shows a sample conversation with its items.

        Args:
            request: The incoming request.
            sample_conversation_id: The ID of the Sample Conversation.

        Returns:
            Response with the Sample Conversation and its items inline.
        """
        assistant_service = AssistantService.from_request(request)
        conversation = assistant_service.get_sample_conversation(sample_conversation_id)

        if conversation is None:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "SampleConversationNotFound",
                details="Could not find a sample conversation with the given ID.",
            )

        return response.json(conversation.as_dict(include_items=True))

    @assistant_endpoints.route("/sample_conversations", methods=["POST"])
    @validate_schema("sample_conversation")
    @rasa_x_scoped("blueprints.create")
    async def create_sample_conversation(request: Request) -> response.HTTPResponse:
        """Creates a new sample conversation.

        Args:
            request: The incoming request.

        Returns:
            Response that contains the newly created sample conversation.
        """
        assistant_service = AssistantService.from_request(request)

        rjs = request.json
        name = rjs.get("name").strip()
        description = rjs.get("description")

        try:
            sample_conversation = assistant_service.create_sample_conversation(
                name, description
            )
            return response.json(sample_conversation.as_dict(), HTTPStatus.CREATED)
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.BAD_REQUEST, "CreateSampleConversationFailed", details=e,
            )
        except DuplicateSampleConversationException:
            return common_utils.error(
                HTTPStatus.UNPROCESSABLE_ENTITY,
                "DuplicateSampleConversationName",
                "A Sample Conversation with the same name already exists.",
            )

    @assistant_endpoints.route("/sample_conversations/clone", methods=["POST"])
    @validate_schema("sample_conversation_clone")
    @rasa_x_scoped("blueprints.create")
    async def clone_sample_conversation(request: Request) -> response.HTTPResponse:
        """Clones an existing sample conversation.

        Args:
            request: The incoming request.

        Returns:
            Response that contains the cloned sample conversation.
        """
        assistant_service = AssistantService.from_request(request)

        rjs = request.json
        name = rjs.get("name").strip()
        description = rjs.get("description")
        source_id = rjs.get("source_id")
        clone_links = rjs.get("clone_links")

        try:
            sample_conversation = assistant_service.clone_sample_conversation(
                source_id, name, description, clone_links
            )
            return response.json(
                sample_conversation.as_dict(include_items=True), HTTPStatus.CREATED
            )

        except DuplicateSampleConversationException:
            return common_utils.error(
                HTTPStatus.UNPROCESSABLE_ENTITY,
                "DuplicateSampleConversationName",
                "A Sample Conversation with the same name already exists.",
            )
        except SampleConversationNotFound:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "SourceSampleConversationNotFound",
                "The sample conversation with the ID given in `source_id` does not exist.",
            )

    @assistant_endpoints.route(
        "/sample_conversations/<sample_conversation_id>/items", methods=["POST"]
    )
    @validate_schema("sample_conversation_item")
    @rasa_x_scoped("blueprints.create")
    async def create_sample_conversation_item(
        request: Request, sample_conversation_id: Text
    ) -> response.HTTPResponse:
        """Creates a new sample conversation item.

        Args:
            request: The incoming request.
            sample_conversation_id: The ID of the Sample Conversation.

        Returns:
            Response that contains the newly created sample conversation.
        """
        assistant_service = AssistantService.from_request(request)

        rjs = request.json
        type_ = rjs.get("type")
        text = rjs.get("text")
        order = rjs.get("order")

        try:
            item = assistant_service.create_sample_conversation_message(
                type_, text, sample_conversation_id, order
            )
            return response.json(item.as_dict(), HTTPStatus.CREATED)
        except ValueError as e:
            if "sample conversation does not exist" in str(e):
                status = HTTPStatus.NOT_FOUND
                reason = "SampleConversationNotFound"
            else:
                status = HTTPStatus.BAD_REQUEST
                reason = "CreateSampleConversationItemFailed"

            return common_utils.error(status, reason, details=e)

    @assistant_endpoints.route(
        "/sample_conversations/<sample_conversation_id>", methods=["PUT"]
    )
    @validate_schema("sample_conversation")
    @rasa_x_scoped("blueprints.update")
    async def update_sample_conversation(
        request: Request, sample_conversation_id: Text
    ) -> response.HTTPResponse:
        """Updates an existing sample conversation.

        Args:
            request:                The incoming request.
            sample_conversation_id: The ID of the Sample Conversation.

        Returns:
            The updated sample conversation, otherwise Not Found.
        """
        assistant_service = AssistantService.from_request(request)

        rjs = request.json
        name = rjs.get("name").strip()
        description = rjs.get("description")

        try:
            conversation = assistant_service.update_sample_conversation(
                sample_conversation_id, name, description
            )
            return response.json(
                conversation.as_dict(include_items=True), HTTPStatus.OK
            )
        except ValueError:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "SampleConversationNotFound",
                details="Could not find a sample conversation with the given ID.",
            )
        except DuplicateSampleConversationException:
            return common_utils.error(
                HTTPStatus.UNPROCESSABLE_ENTITY, "DuplicateSampleConversationName"
            )

    @assistant_endpoints.route(
        "/sample_conversations/<sample_conversation_id>", methods=["DELETE"]
    )
    @rasa_x_scoped("blueprints.delete")
    async def delete_sample_conversation(
        request: Request, sample_conversation_id: Text
    ) -> response.HTTPResponse:
        """Deletes an existing sample conversation.

        Args:
            request: The incoming request.
            sample_conversation_id: The ID of the Sample Conversation.

        Returns:
            Empty response when sample conversation has been deleted, otherwise Not Found.
        """
        assistant_service = AssistantService.from_request(request)

        try:
            assistant_service.delete_sample_conversation(sample_conversation_id)
            return response.text("", HTTPStatus.NO_CONTENT)
        except ValueError:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "SampleConversationNotFound",
                details="Could not find a sample conversation with the given ID.",
            )

    @assistant_endpoints.route(
        "/sample_conversations/<sample_conversation_id>/items/<sample_conversation_item_id>",
        methods=["DELETE"],
    )
    @rasa_x_scoped("blueprints.delete")
    async def delete_sample_conversation_item(
        request: Request,
        sample_conversation_id: Text,
        sample_conversation_item_id: Text,
    ) -> response.HTTPResponse:
        """Deletes an existing sample conversation.

        Args:
            request:                     The incoming request.
            sample_conversation_id:      The ID of the Sample Conversation.
            sample_conversation_item_id: The ID of the Sample Conversation Item.

        Returns:
            Empty response when sample conversation item has been deleted, otherwise Not Found.
        """
        assistant_service = AssistantService.from_request(request)

        try:
            assistant_service.delete_sample_conversation_message(
                sample_conversation_item_id
            )
            return response.text("", HTTPStatus.NO_CONTENT)
        except ValueError:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "SampleConversationItemNotFound",
                details="Could not find a sample conversation item with the given ID.",
            )

    @assistant_endpoints.route(
        "/sample_conversations/<sample_conversation_id>/items/<sample_conversation_item_id>",
        methods=["PUT"],
    )
    @rasa_x_scoped("blueprints.update")
    async def update_sample_conversation_item(
        request: Request,
        sample_conversation_id: Text,
        sample_conversation_item_id: Text,
    ) -> response.HTTPResponse:
        """Updates existing sample conversation item.

        Args:
            request:                     The incoming request.
            sample_conversation_id:      The ID of the Sample Conversation.
            sample_conversation_item_id: The ID of the Sample Conversation Item.

        Returns:
            The updated sample conversation item, otherwise Not Found.
        """
        assistant_service = AssistantService.from_request(request)

        rjs = request.json
        type_ = rjs.get("type")
        text = rjs.get("text")
        order = rjs.get("order")

        try:
            item = assistant_service.update_sample_conversation_message(
                sample_conversation_id, sample_conversation_item_id, type_, text, order
            )
            return response.json(item.as_dict(), HTTPStatus.OK)
        except ValueError as e:
            if "Could not find a sample conversation item" in str(e):
                status = HTTPStatus.NOT_FOUND
                reason = "SampleConversationItemNotFound"
            elif "sample conversation does not exist" in str(e):
                status = HTTPStatus.NOT_FOUND
                reason = "SampleConversationNotFound"
            else:
                status = HTTPStatus.BAD_REQUEST
                reason = "UpdateSampleConversationItemFailed"

            return common_utils.error(status, reason, details=e)

    @assistant_endpoints.route("/assistant_links", methods=["GET"])
    @rasa_x_scoped("blueprints.list")
    async def list_links(request: Request) -> response.HTTPResponse:
        business_logic_flow_id = common_utils.int_arg(request, "business_logic_flow_id")
        sample_conversation_id = common_utils.int_arg(request, "sample_conversation_id")
        limit = common_utils.int_arg(request, "limit")
        offset = common_utils.int_arg(request, "offset")

        assistant_service = AssistantService.from_request(request)

        try:
            links, total = assistant_service.fetch_links(
                business_logic_flow_id=business_logic_flow_id,
                sample_conversation_id=sample_conversation_id,
                limit=limit,
                offset=offset,
            )
        except ValueError as e:
            return common_utils.error(HTTPStatus.BAD_REQUEST, str(e))

        return response.json(links, headers={"X-Total-Count": total})

    @assistant_endpoints.route("/assistant_links", methods=["POST"])
    @rasa_x_scoped("blueprints.create")
    @validate_schema("assistant_link_bulk_create")
    async def bulk_create_links(request: Request) -> response.HTTPResponse:
        """Bulk creates assistant links.

        Args:
            request: The incoming request.

        Returns:
            A list of created assistant links.
        """
        assistant_service = AssistantService.from_request(request)

        rjs = request.json
        create_data = rjs.get("create")

        try:
            links = assistant_service.bulk_create_links(create_data)
            return response.json(links, HTTPStatus.CREATED)
        except BulkCreateException as e:
            return common_utils.error(
                HTTPStatus.UNPROCESSABLE_ENTITY, str(e), details=e.errors
            )

    @assistant_endpoints.route(
        "/assistant_links/<assistant_link_id>", methods=["DELETE"]
    )
    @rasa_x_scoped("blueprints.delete")
    async def delete_link(
        request: Request, assistant_link_id: Text
    ) -> response.HTTPResponse:
        """Delete an assistant link.

        Args:
            request:           The incoming request.
            assistant_link_id: The ID of the link to be deleted.

        Returns:
            No Content
        """
        assistant_service = AssistantService.from_request(request)

        try:
            assistant_service.delete_link(assistant_link_id)
            return response.text("", HTTPStatus.NO_CONTENT)
        except ValueError as e:
            return common_utils.error(HTTPStatus.NOT_FOUND, str(e))

    return assistant_endpoints
