import logging
import os

import time
from typing import Dict, Text

from aiohttp import ClientError
from ruamel.yaml import YAMLError
from sanic import Blueprint, response
from sanic.request import Request
import http

import rasax.community.config as rasa_x_config
import rasax.community.constants as constants
import rasax.community.utils.common as common_utils
import rasax.community.utils.config as config_utils
import rasax.community.utils.yaml as yaml_utils
import rasax.community.telemetry as telemetry
from rasax.community.api.decorators import rasa_x_scoped, inject_rasa_x_user
from rasax.community.services.model_service import ModelService
from rasax.community.services.settings_service import SettingsService
import rasax.community.services.websocket_service as websocket_service
import rasax.community.utils.cli as cli_utils

logger = logging.getLogger(__name__)


def _model_service(request: Request) -> ModelService:
    return ModelService.from_request(
        rasa_x_config.rasa_model_dir, request, constants.DEFAULT_RASA_ENVIRONMENT
    )


def blueprint() -> Blueprint:
    endpoints = Blueprint("model_endpoints")

    @endpoints.route("/projects/<project_id>/models", methods=["GET", "HEAD"])
    @rasa_x_scoped("models.list", allow_api_token=True, allow_rasa_x_token=True)
    async def get_models(request: Request, project_id: Text):
        limit = common_utils.int_arg(request, "limit")
        offset = common_utils.int_arg(request, "offset", 0)
        tag = common_utils.default_arg(request, "tag")

        models, total_models = await _model_service(request).get_models(
            project_id, limit, offset, tag
        )

        return response.json(models, headers={"X-Total-Count": total_models})

    @endpoints.route("/projects/<project_id>/models", methods=["POST"])
    @rasa_x_scoped("models.create", allow_api_token=True, allow_rasa_x_token=True)
    @inject_rasa_x_user(allow_api_token=True)
    async def upload_model(
        request: Request, project_id: Text, user: Dict
    ) -> response.HTTPResponse:
        model_service = _model_service(request)
        try:
            tpath = model_service.save_model_to_disk(request)
        except (FileNotFoundError, ValueError, TypeError) as e:
            return common_utils.error(
                http.HTTPStatus.BAD_REQUEST,
                "ModelSaveError",
                f"Could not save model.\n{e}",
            )

        logger.debug(
            "models.upload_model.model_service.minimum_compatible_version start."
        )
        minimum_version = await model_service.minimum_compatible_version()
        logger.debug(
            "models.upload_model.model_service.minimum_compatible_version end."
        )

        if not model_service.is_model_compatible(minimum_version, fpath=tpath):
            logger.debug(
                f"Model version unsupported. The minimum compatible version is {minimum_version}."
            )
            return common_utils.error(
                http.HTTPStatus.BAD_REQUEST,
                "ModelVersionError",
                f"Model version unsupported.\n"
                f"The minimum compatible version is {minimum_version}.",
            )
        else:
            logger.debug("Model version is supported.")

        try:
            filename: Text = os.path.basename(tpath)
            model_name = filename.split(".tar.gz")[0]
            saved = await model_service.save_uploaded_model(
                project_id, model_name, tpath
            )
            if saved:
                websocket_service.send_message(
                    websocket_service.Message(
                        websocket_service.MessageTopic.MODELS,
                        name="model_added",
                        data={"method": "uploaded", "model_name": model_name},
                        recipient=user[constants.USERNAME_KEY],
                    )
                )
                telemetry.track(telemetry.MODEL_UPLOADED_EVENT)

                return response.json(saved, http.HTTPStatus.CREATED)
            return common_utils.error(
                http.HTTPStatus.BAD_REQUEST,
                "ModelSaveError",
                "Could not save model.\nModel name '{}'."
                "File path '{}'.".format(model_name, tpath),
            )
        except FileExistsError:
            return common_utils.error(
                http.HTTPStatus.CONFLICT,
                "ModelExistsError",
                "A model with that name already exists.",
            )
        except ValueError:
            return common_utils.error(
                http.HTTPStatus.BAD_REQUEST,
                "ModelSaveError",
                "Failed to retrieve metadata from model archive.",
            )

    @endpoints.route("/models/tags/<tag>", methods=["GET", "HEAD"])
    @rasa_x_scoped(
        "models.modelByTag.get", allow_api_token=True, allow_rasa_x_token=True
    )
    async def get_model_for_tag(request: Request, tag: Text) -> response.HTTPResponse:
        return await _model_for_tag(request, rasa_x_config.project_name, tag)

    @endpoints.route(
        "/projects/<project_id>/models/tags/<tag>", methods=["GET", "HEAD"]
    )
    @rasa_x_scoped(
        "models.modelByTag.get", allow_api_token=True, allow_rasa_x_token=True
    )
    async def get_model_for_tag_deprecated(
        request: Request, project_id: Text, tag: Text
    ) -> response.HTTPResponse:
        cli_utils.raise_warning(
            'The "GET /projects/<project_id>/models/tags/<tag>" endpoint is deprecated.'
            ' Please use "GET /models/tags/<tag>" instead".',
            category=FutureWarning,
        )
        return await _model_for_tag(request, project_id, tag)

    async def _model_for_tag(
        request: Request, project_id: Text, tag: Text
    ) -> response.HTTPResponse:
        model = _model_service(request).model_for_tag(project_id, tag)
        if not model:
            return common_utils.error(
                404, "TagNotFound", f"Tag '{tag}' not found for project '{project_id}'."
            )
        model_hash = model["hash"]
        try:
            if model_hash == request.headers.get("If-None-Match"):
                return response.text("", http.HTTPStatus.NO_CONTENT)

            return await response.file_stream(
                location=model["path"],
                headers={
                    "ETag": model_hash,
                    "filename": os.path.basename(model["path"]),
                },
                mime_type="application/gzip",
            )
        except FileNotFoundError:
            logger.warning(
                "Tried to download model file '{}', "
                "but file does not exist.".format(model["path"])
            )
            return common_utils.error(
                404,
                "ModelDownloadFailed",
                "Failed to find model file '{}'.".format(model["path"]),
            )

    @endpoints.route(
        "/projects/<project_id>/models/<model_name>", methods=["GET", "HEAD"]
    )
    @rasa_x_scoped("models.get", allow_api_token=True, allow_rasa_x_token=True)
    async def get_model_by_name(
        request: Request, project_id: Text, model_name: Text
    ) -> response.HTTPResponse:
        if model_name.endswith(".tar.gz"):
            model_name = model_name[:-7]

        logger.debug("models.get_model_by_name.model_service.get_model_by_name start.")
        model = _model_service(request).get_model_by_name(project_id, model_name)
        logger.debug("models.get_model_by_name.model_service.get_model_by_name end.")

        if not model:
            logger.debug(f"Model '{model}' not found for project '{project_id}'.")
            return common_utils.error(
                http.HTTPStatus.NOT_FOUND,
                "ModelNotFound",
                f"Model '{model}' not found for project '{project_id}'.",
            )
        else:
            logger.debug(f"Model '{model}' found for project '{project_id}'.")

        model_hash = model["hash"]
        try:
            if model_hash == request.headers.get("If-None-Match"):
                return response.text("", http.HTTPStatus.NO_CONTENT)

            return await response.file_stream(
                location=model["path"],
                headers={
                    "ETag": model_hash,
                    "filename": os.path.basename(model["path"]),
                },
                mime_type="application/gzip",
            )
        except FileNotFoundError as e:
            logger.exception(e)
            return common_utils.error(
                http.HTTPStatus.NOT_FOUND,
                "ModelDownloadFailed",
                f"Failed to download file.\n{e}",
            )

    # noinspection PyUnusedLocal
    @endpoints.route("/projects/<project_id>/models/<model>", methods=["DELETE"])
    @rasa_x_scoped("models.delete", allow_api_token=True)
    async def delete_model(
        request: Request, project_id: Text, model: Text
    ) -> response.HTTPResponse:
        deleted = _model_service(request).delete_model(project_id, model)
        if deleted:
            return response.text("", http.HTTPStatus.NO_CONTENT)

        return common_utils.error(
            http.HTTPStatus.NOT_FOUND,
            "ModelDeleteFailed",
            f"Failed to delete model '{model}'.",
        )

    @endpoints.route("/projects/<project_id>/models/jobs", methods=["POST"])
    @rasa_x_scoped("models.jobs.create", allow_api_token=True)
    @inject_rasa_x_user(allow_api_token=True)
    async def train_model(
        request: Request,
        project_id: Text,
        user: Dict,
        self_url: Text = rasa_x_config.self_url,
    ) -> response.HTTPResponse:
        stack_services = SettingsService.from_request(request).stack_services(
            project_id
        )
        environment = common_utils.deployment_environment_from_request(
            request, constants.RASA_WORKER_ENVIRONMENT
        )
        stack_service = stack_services[environment]

        job = _model_service(request).add_training_job(user[constants.USERNAME_KEY])
        job_id = job["id"]

        # TODO: We should try Sanic's url_for() method to construct this URL
        callback_url = (
            f"{self_url}/api/projects/{project_id}/models/jobs/{job_id}/result"
            f"?token={rasa_x_config.rasa_x_token}"
        )
        try:
            await stack_service.start_training_process(callback_url)

            return response.json(job, http.HTTPStatus.CREATED)
        except ClientError as e:
            updated_job = stack_service.handle_non_training_errors(request, job_id, e)

            return response.json(updated_job, http.HTTPStatus.INTERNAL_SERVER_ERROR)

    @endpoints.route("/projects/<project_id>/models/jobs/<job_id>", methods=["GET"])
    @rasa_x_scoped("models.jobs.create")
    async def get_training_job(
        request: Request, project_id: Text, job_id: Text
    ) -> response.HTTPResponse:
        """Retrieves a model training job.

        Args:
            request: The incoming request.
            project_id: ID of the project.
            job_id: The ID of the model training job.

        Returns:
            Response with the Model Training Job.
        """
        job = _model_service(request).get_training_job(job_id)

        if job is None:
            return common_utils.error(
                http.HTTPStatus.NOT_FOUND,
                "ModelTrainingJobNotFound",
                details="Could not find a job with the given ID.",
            )

        return response.json(job.as_dict(), http.HTTPStatus.OK)

    @endpoints.route(
        "/projects/<project_id>/models/jobs/<job_id>/result", methods=["POST"]
    )
    @rasa_x_scoped("models.jobs.create", allow_rasa_x_token=True)
    async def post_model_training_result(
        request: Request, project_id: Text, job_id: Text
    ) -> response.HTTPResponse:
        """Posts a result of a model training job.

        Args:
            request: The incoming request.
            project_id: ID of the project.
            job_id: The ID of the model training job.

        Returns:
           Response with the updated Model Training Job.
        """
        job = _model_service(request).get_training_job(job_id)

        if job is None:
            return common_utils.error(
                http.HTTPStatus.NOT_FOUND,
                "ModelTrainingJobNotFound",
                details="Could not find a job with the given ID.",
            )

        stack_services = SettingsService.from_request(request).stack_services(
            project_id
        )
        environment = common_utils.deployment_environment_from_request(
            request, constants.RASA_WORKER_ENVIRONMENT
        )
        stack_service = stack_services[environment]

        if request.content_type == "application/x-tar":
            model_name, updated_job = await stack_service.complete_training_process(
                request, job
            )
            if model_name:
                websocket_service.send_message(
                    websocket_service.Message(
                        websocket_service.MessageTopic.MODELS,
                        name="model_added",
                        data={"method": "trained", "model_name": model_name},
                        recipient=updated_job["initiated_by"],
                    )
                )

        else:
            updated_job = stack_service.handle_training_errors(request, job.id)

        return response.json(updated_job, http.HTTPStatus.OK)

    # noinspection PyUnusedLocal
    @endpoints.route(
        "/projects/<project_id>/models/<model>/tags/<tag>", methods=["PUT"]
    )
    @rasa_x_scoped("models.tags.update", allow_api_token=True)
    @inject_rasa_x_user(allow_api_token=True)
    async def tag_model(
        request: Request, project_id: Text, model: Text, tag: Text, user: Dict
    ) -> response.HTTPResponse:
        try:
            await _model_service(request).tag_model(project_id, model, tag)
            if tag == constants.RASA_PRODUCTION_ENVIRONMENT:
                websocket_service.send_message(
                    websocket_service.Message(
                        websocket_service.MessageTopic.MODELS,
                        name="model_promoted",
                        data={"model_name": model, "time": time.time()},
                        recipient=user[constants.USERNAME_KEY],
                    )
                )

                telemetry.track(telemetry.MODEL_PROMOTED_EVENT)

            return response.text("", http.HTTPStatus.NO_CONTENT)
        except ValueError as e:
            return common_utils.error(
                http.HTTPStatus.NOT_FOUND,
                "ModelTagError",
                f"Failed to tag model '{model}'.",
                details=e,
            )

    # noinspection PyUnusedLocal
    @endpoints.route(
        "/projects/<project_id>/models/<model>/tags/<tag>", methods=["DELETE"]
    )
    @rasa_x_scoped("models.tags.delete", allow_api_token=True)
    async def untag(request, project_id, model, tag) -> response.HTTPResponse:
        try:
            _model_service(request).delete_tag(project_id, model, tag)
            return response.text("", http.HTTPStatus.NO_CONTENT)
        except ValueError as e:
            return common_utils.error(
                http.HTTPStatus.NOT_FOUND,
                "TagDeletionFailed",
                "Failed to delete model tag",
                details=e,
            )

    @endpoints.route("/projects/<project_id>/settings", methods=["GET", "HEAD"])
    @rasa_x_scoped("models.settings.get", allow_api_token=True)
    @inject_rasa_x_user(allow_api_token=True)
    async def get_model_config(request, project_id, user=None) -> response.HTTPResponse:
        settings_service = SettingsService.from_request(request)
        stack_config = settings_service.get_config(user["team"], project_id)
        if not stack_config:
            return common_utils.error(
                http.HTTPStatus.NOT_FOUND, "SettingsFailed", "Could not find settings."
            )

        yaml_config = yaml_utils.dump_yaml(stack_config)

        return response.text(yaml_config)

    @endpoints.route("/projects/<project_id>/settings", methods=["PUT"])
    @rasa_x_scoped("models.settings.update")
    @inject_rasa_x_user()
    async def save_model_config(
        request, project_id, user=None
    ) -> response.HTTPResponse:
        settings_service = SettingsService.from_request(request)
        try:
            config_yaml = settings_service.inspect_and_save_yaml_config_from_request(
                request.body, user["team"], project_id
            )
            return response.text(config_yaml)
        except YAMLError as e:
            return common_utils.error(
                400, "InvalidConfig", f"Failed to read configuration file.  Error: {e}"
            )
        except config_utils.InvalidConfigError as e:
            return common_utils.error(
                http.HTTPStatus.UNPROCESSABLE_ENTITY, "ConfigMissingKeys", f"Error: {e}"
            )

    return endpoints
