from collections import Counter
from itertools import groupby

import logging
import asyncio

from rasax.community.legacy.core.events import ActionExecuted, SlotSet, UserUttered
from rasax.community.legacy.nlu.constants import ENTITY_ATTRIBUTE_TYPE
from rasax.community.legacy.core.constants import DEFAULT_INTENTS

from typing import Any, Dict, List, Optional, Set, Text, Tuple

import http
from sanic import Blueprint, response
from sanic.request import Request

from rasax.community import constants, telemetry

from rasax.community.api.decorators import (
    inject_rasa_x_user,
    rasa_x_scoped,
    validate_schema,
)
import rasax.community.config
from rasax.community.database.insights import ReportStatus
from rasax.community.services.domain_service import DomainService
from rasax.community.services.event_service import EventService
from rasax.community.services.insights.insight_calculator import (
    ClassBiasInsightCalculator,
    ConfusionInsightCalculator,
    MinimumExampleInsightCalculator,
    NLUInboxConfidenceInsightCalculator,
    WrongAnnotationInsightCalculator,
)
from rasax.community.services.insights.insight_service import InsightService
from rasax.community.services.integrated_version_control.git_service import GitService
from rasax.community.services.logs_service import LogsService
from rasax.community.services.nlg_service import NlgService
from rasax.community.services.settings_service import SettingsService
from rasax.community.services.story_service import StoryService
import rasax.community.utils.common
import rasax.community.config as rasa_x_config

logger = logging.getLogger(__name__)

# The largest number of annotated messages we care about
MAX_ANNOTATED_MESSAGES = 2995

# Translates insights warnings into scorecard categories
insight_key_map = {
    MinimumExampleInsightCalculator.__name__: "num_min_example_warnings",
    ConfusionInsightCalculator.__name__: "num_confused_intent_warnings",
    NLUInboxConfidenceInsightCalculator.__name__: "num_confidence_warnings",
    WrongAnnotationInsightCalculator.__name__: "num_wrong_annotation_warnings",
    ClassBiasInsightCalculator.__name__: "num_precision_recall_warnings",
}


def blueprint() -> Blueprint:
    """Declare endpoints for the scorecard.

    Returns:
        Blueprint with endpoints for the scorecard.
    """
    scorecard_endpoints = Blueprint("scorecard_endpoints")

    def _filter_by_min_occurrence(
        counter: Counter, *, min_occurrence: int
    ) -> Set[Text]:
        """Select items from the counter where the count is higher than a minimum."""
        return {item for item, total in counter.items() if total > min_occurrence}

    def _calculate_test_coverage(request: Request, project_id: Text) -> float:
        """Calculate the test coverage covered by test stories across the project.

        Returns:
            Fraction of domain elements covered in test stories. Between 0 and 1.
        """
        domain_service = DomainService.from_request(request)
        story_service = StoryService.from_request(request)
        test_stories = story_service.fetch_stories(fetch_test_stories=True)

        intents = domain_service.get_intents_from_domain(project_id) - set(
            DEFAULT_INTENTS
        )
        entities = domain_service.get_entities_from_domain(project_id)

        custom_actions = domain_service.get_actions_from_domain(project_id)
        responses = NlgService.from_request(request).fetch_all_response_names()
        actions = custom_actions.union(responses)
        slots = domain_service.get_slots_from_domain(project_id)

        intent_counts = Counter({i: 0 for i in intents})
        entity_counts = Counter({i: 0 for i in entities})
        slot_counts = Counter({i: 0 for i in slots})
        action_counts = Counter({i: 0 for i in actions})

        for story in test_stories.result:
            steps_list = story_service.get_story_steps(
                story.get("story"),
                domain_service.get_merged_domain(project_id),
                story.get("filename"),
                skip_validation=True,
            )
            for step in steps_list:
                for event in step.events:
                    if isinstance(event, ActionExecuted):
                        action_counts[event.action_name] += 1
                    if isinstance(event, UserUttered):
                        intent_counts[event.intent_name] += 1
                        for entity in event.entities:
                            entity_counts[entity[ENTITY_ATTRIBUTE_TYPE]] += 1
                    if isinstance(event, SlotSet):
                        slot_counts[event.key] += 1

        covered_intents = _filter_by_min_occurrence(intent_counts, min_occurrence=1)
        covered_entities = _filter_by_min_occurrence(entity_counts, min_occurrence=1)
        covered_actions = _filter_by_min_occurrence(action_counts, min_occurrence=1)
        covered_slots = _filter_by_min_occurrence(slot_counts, min_occurrence=1)

        number_of_covered_elements = (
            len(covered_intents)
            + len(covered_entities)
            + len(covered_actions)
            + len(covered_slots)
        )
        number_of_total_elements = (
            len(intents) + len(entities) + len(actions) + len(slots)
        )

        if number_of_total_elements == 0:
            return 0.0

        return round(100 * number_of_covered_elements / number_of_total_elements, 1)

    def _has_git_enabled(request: Request, project_id: Text) -> bool:
        """Check if git is enabled for the project."""
        with GitService.from_request(request, project_id=project_id) as git_service:
            git_repositories = git_service.get_repositories()
            return len(git_repositories) > 0

    def _connected_channels(request: Request) -> List[Text]:
        """Get all channels used in the current project."""
        return EventService.from_request(request).get_unique_input_channels()

    def _has_fallback(request: Request, team: Text, project_id: Text) -> bool:
        """Check if the current project uses a fallback classifier."""
        settings_service = SettingsService.from_request(request)
        stack_config = settings_service.get_config(team, project_id)

        if not stack_config:
            return False

        for component in stack_config.get("pipeline", []):
            if component.get("name") == "FallbackClassifier":
                return True
        return False

    async def _count_annotated_messages(request: Request) -> int:
        """Number of annotated messages in our logs."""
        fetched_logs = await LogsService.from_request(request).fetch_logs(
            limit=1, is_training_data=True, count_limit=MAX_ANNOTATED_MESSAGES,
        )
        return fetched_logs.count

    def _warnings_from_insights_report(report: Dict[Text, Any]) -> Dict[Text, int]:
        """Collect all warnings from an insights report and generate a statistic.

        Returns:
            A mapping of each warning to the number of occurrences in the report.
        """
        warnings = [
            warnings
            for intent in report["intent_evaluation_results"]
            for warnings in intent["intent_insights"]
        ]
        warnings.sort(key=lambda w: w["source"])

        result = {}
        warning_groups = {
            k: list(v) for k, v in groupby(warnings, lambda w: w["source"])
        }

        for insights_key, warning_name in insight_key_map.items():
            if insights_key in warning_groups:
                result[warning_name] = len(warning_groups[insights_key])
            else:
                result[warning_name] = 0

        return result

    def _latest_insights_report(
        request: Request, project_id: Text
    ) -> Optional[Dict[Text, Any]]:
        """Get the latest nlu insights report if it exists."""
        insight_service = InsightService.from_request(request)
        list_of_reports = insight_service.get_nlu_insight_reports(
            limit=1, report_status=ReportStatus.SUCCESS, sort_order="desc"
        )

        if (
            list_of_reports.count == 0
            or not list_of_reports.result[0]
            or "id" not in list_of_reports.result[0]
        ):
            logger.debug(
                "There is no up to date nlu insights report to use for "
                "the scorecard. Skipping this section."
            )
            return None

        latest_report_id = list_of_reports.result[0]["id"]
        reports = insight_service.get_nlu_insight_report_full_by_id(
            latest_report_id, project_id=project_id
        )

        if reports.count == 0:
            logger.error(
                "Failed to fetch insights report even though there should be one"
            )
            return None
        return reports.result

    def _count_warnings(request: Request, project_id: Text) -> Dict[Text, Any]:
        """Use intent insight results to count the number of warnings."""
        default_result: Dict[Text, Optional[int]] = {
            "num_min_example_warnings": None,
            "num_confused_intent_warnings": None,
            "num_confidence_warnings": None,
            "num_wrong_annotation_warnings": None,
            "num_precision_recall_warnings": None,
        }
        try:
            latest_report = _latest_insights_report(request, project_id)
            if not latest_report:
                return default_result
            else:
                return _warnings_from_insights_report(latest_report)
        except Exception:  # noqa: E722
            logger.exception("Error processing NLU insight report")
            return default_result

    def _count_tagged_conversations(request: Request) -> int:
        """Number of conversations that are tagged as well as a list of all tags."""
        event_service = EventService.from_request(request)
        return event_service.get_conversations_with_tags_count()

    async def _conversation_statistics(request: Request) -> Tuple[int, int]:
        """Counts number of real and reviewed conversations."""
        event_service = EventService.from_request(request)
        (
            all_conversations,
            rasa_conversations,
            unread_conversations,
        ) = await asyncio.gather(
            event_service.get_conversation_metadata_for_all_clients(limit=1),
            event_service.get_conversation_metadata_for_all_clients(
                limit=1, input_channels=[constants.DEFAULT_CHANNEL_NAME]
            ),
            event_service.get_conversation_metadata_for_all_clients(
                limit=1, review_status=constants.CONVERSATION_STATUS_UNREAD
            ),
        )

        real_conversations = all_conversations.count - rasa_conversations.count
        reviewed_conversations = all_conversations.count - unread_conversations.count

        return real_conversations, reviewed_conversations

    def _manual_scorecard(request: Request) -> Dict[Text, Any]:
        insight_service = InsightService.from_request(request)
        config = insight_service.get_scorecard_config()

        return {
            "CI": {
                "ci_runs_data_validation": config["ci_runs_data_validation"],
                "ci_trains_model": config["ci_trains_model"],
                "ci_runs_rasa_test": config["ci_runs_rasa_test"],
                "test_dir": rasa_x_config.default_test_stories_dir,
                "ci_builds_action_server": config["ci_builds_action_server"],
            },
            "CD": {
                "infrastructure_as_code": config["infrastructure_as_code"],
                "ci_deploys_action_server": config["ci_deploys_action_server"],
                "has_test_environment": config["has_test_environment"],
                "ci_runs_vulnerability_scans": config["ci_runs_vulnerability_scans"],
            },
            "success_kpis": {
                "automated_conversation_tags": [
                    tag.get("value") for tag in config["automated_conversation_tags"]
                ]
            },
            "training_data_health": {
                "connected_channels": _connected_channels(request)
            },
        }

    async def _auto_scorecard(request: Request, team: Text) -> Dict[Text, Any]:
        project = rasa_x_config.project_name

        real_conversations, reviewed_conversations = await _conversation_statistics(
            request
        )
        training_data_health = _count_warnings(request, project)

        training_data_health["num_real_conversations"] = real_conversations
        training_data_health[
            "num_annotated_messages"
        ] = await _count_annotated_messages(request)

        return {
            "CI": {
                "code_and_training_data_in_git": _has_git_enabled(request, project),
                "rasa_test_coverage": _calculate_test_coverage(request, project),
            },
            "CD": {},
            "training_data_health": training_data_health,
            "success_kpis": {
                "num_reviewed_conversations": reviewed_conversations,
                "num_tagged_conversations": _count_tagged_conversations(request),
                "has_fallback": _has_fallback(request, team, project),
            },
        }

    @scorecard_endpoints.route("/scorecard", methods=["GET"])
    @inject_rasa_x_user(allow_api_token=True)
    @rasa_x_scoped("insights.scorecard.get", allow_api_token=True)
    async def get_scorecard(
        request: Request, user: Dict[Text, Any]
    ) -> response.HTTPResponse:
        """Gets the full scorecard.

        Scorecard is based on stored configuration as well as some computed parts.

        Args:
            request: The incoming request.
            user: logged in Rasa X user

        Returns:
            Response that contains the scorecard in json format.
        """
        scorecard = {
            "version": 1,
            "scorecard": {
                "manual": _manual_scorecard(request),
                "auto": await _auto_scorecard(request, user["team"]),
            },
        }
        telemetry.track(telemetry.SCORECARD_RESULT_REQUESTED)
        return response.json(scorecard)

    @scorecard_endpoints.route("/scorecardConfig", methods=["HEAD", "GET"])
    @rasa_x_scoped("insights.config.get", allow_api_token=True)
    async def get_config(request: Request) -> response.HTTPResponse:
        """Gets the intent insight config.

        Args:
            request: The incoming request.

        Returns:
            Response that contains the config.
        """
        insight_service = InsightService.from_request(request)

        config = insight_service.get_scorecard_config()
        return response.json(config)

    @scorecard_endpoints.route("/scorecardConfig", methods=["PUT"])
    @rasa_x_scoped("insights.config.update", allow_api_token=True)
    @validate_schema("scorecard_insight_config")
    async def update_config(request: Request) -> response.HTTPResponse:
        """Updates the scorecard insight config.

        Args:
            request: The incoming request.

        Returns:
            Response that contains the updated configuration.
        """
        insight_service = InsightService.from_request(request)

        new_config = request.json
        try:
            insight_service.update_scorecard_config(new_config)
            return response.json(new_config)
        except ValueError as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.BAD_REQUEST, "ConfigUpdateFailed", details=e,
            )

    return scorecard_endpoints
