import logging
from typing import Text, Dict, Optional

from rasax.community.api.decorators import (
    rasa_x_scoped,
    inject_rasa_x_user,
)
from rasax.community.services.data_service import DataService
from sanic import Blueprint, response
from sanic.request import Request
from sanic.response import HTTPResponse

logger = logging.getLogger(__name__)


def blueprint():  # noqa: D103 # Missing docstring
    nlu_entities_endpoints = Blueprint("nlu_entities_endpoints")

    # noinspection PyUnusedLocal
    @nlu_entities_endpoints.route(
        "/projects/<project_id>/entities", methods=["GET", "HEAD"]
    )
    @rasa_x_scoped("entities.list")
    @inject_rasa_x_user()
    async def get_entities(
        request: Request, project_id: Text, user: Optional[Dict] = None
    ) -> HTTPResponse:
        """Fetches a list of unique entities present in training data."""
        entities = DataService.from_request(request).get_entities(project_id)
        return response.json(entities, headers={"X-Total-Count": len(entities)})

    @nlu_entities_endpoints.route(
        "/projects/<project_id>/entity_roles", methods=["GET"]
    )
    @rasa_x_scoped("entities.list")
    async def get_entity_roles(request: Request, project_id: Text) -> HTTPResponse:
        """Fetches a list of unique entity roles present in the training data."""
        roles = DataService.from_request(request).get_entity_roles(project_id)
        return response.json(roles, headers={"X-Total-Count": len(roles)})

    @nlu_entities_endpoints.route(
        "/projects/<project_id>/entity_groups", methods=["GET"]
    )
    @rasa_x_scoped("entities.list")
    async def get_entity_groups(request: Request, project_id: Text) -> HTTPResponse:
        """Fetches a list of unique entity groups present in the training data."""
        groups = DataService.from_request(request).get_entity_groups(project_id)
        return response.json(groups, headers={"X-Total-Count": len(groups)})

    return nlu_entities_endpoints
