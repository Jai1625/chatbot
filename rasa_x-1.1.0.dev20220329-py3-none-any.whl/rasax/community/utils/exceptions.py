import abc
import logging

from typing import List, Text


class SuppressAndLog(abc.ABC):
    """Inspired by contextlib.suppress.

    Context manager to suppress specified exceptions.

    If the exception is specified in the list it is suppressed and execution proceeds with the next
    statement following the with statement.

    The exception will be logged as an error.

         with suppress(FileNotFoundError):
             os.remove(somefile)
             # everything here will be skipped
         # Execution still resumes here if the file was already removed
    """

    @abc.abstractmethod
    def __init__(
        self, logger: logging.Logger, message: Text, *exceptions: List[type],
    ):
        """Creates context manager to suppress and log an exception.

        Args:
            logger: Logger to be user for logging.
            message: Text message in the logs.
            exceptions: List of exception types to suppress.
        """
        self._logger = logger
        self._message = message
        self._exceptions = exceptions

    def __enter__(self):
        pass

    @abc.abstractmethod
    def __log__(self, exception):
        pass

    @classmethod
    def __subclasshook__(cls, C):
        if cls is SuppressAndLog:
            if any("__log__" in B.__dict__ for B in C.__mro__):
                return True
        return NotImplemented

    def __exit__(self, exctype, excinst, exctb):
        is_failed = exctype is not None and issubclass(exctype, self._exceptions)
        if is_failed:
            self.__log__(excinst)
        return is_failed


class SuppressAndLogError(SuppressAndLog):
    """Inspired by contextlib.suppress.

    Context manager to suppress specified exceptions and log them as error messages.

    If the exception is specified in the list it is suppressed and execution proceeds with the next
    statement following the with statement.

    The exception will be logged as an error.

         with suppress(FileNotFoundError):
             os.remove(somefile)
             # everything here will be skipped
         # Execution still resumes here if the file was already removed
    """

    def __init__(self, logger: logging.Logger, message: Text, *exceptions: List[type]):
        """Creates context manager to suppress and log an exception.

        Args:
            logger: Logger to be user for logging.
            message: Text message in the logs.
            exceptions: List of exception types to suppress.
        """
        SuppressAndLog.__init__(self, logger, message, exceptions)

    def __log__(self, exception):
        self._logger.error(f"{self._message}: {exception}")


class SuppressAndLogDebug(SuppressAndLog):
    """Inspired by contextlib.suppress.

    Context manager to suppress specified exceptions and log them as debug messages.

    If the exception is specified in the list it is suppressed and execution proceeds with the next
    statement following the with statement.

    The exception will be logged as an error.

         with suppress(FileNotFoundError):
             os.remove(somefile)
             # everything here will be skipped
         # Execution still resumes here if the file was already removed
    """

    def __init__(self, logger: logging.Logger, message: Text, *exceptions: List[type]):
        """Creates context manager to suppress and log an exception.

        Args:
            logger: Logger to be user for logging.
            message: Text message in the logs.
            exceptions: List of exception types to suppress.
        """
        SuppressAndLog.__init__(self, logger, message, exceptions)

    def __log__(self, exception):
        self._logger.debug(f"{self._message}: {exception}")
