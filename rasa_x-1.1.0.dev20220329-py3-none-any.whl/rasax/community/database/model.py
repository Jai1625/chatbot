import json
from datetime import datetime
from enum import Enum
from typing import Any, Text, Dict, Union

import sqlalchemy as sa
from sqlalchemy.orm import relationship

from rasax.community.database.base import Base
from rasax.community.database import utils


class Model(Base):
    """Stores metadata about trained models."""

    __tablename__ = "model"

    id = sa.Column(sa.Integer, utils.create_sequence(__tablename__), primary_key=True)
    hash = sa.Column(sa.String, nullable=False)
    name = sa.Column(sa.String, nullable=False, unique=True)
    path = sa.Column(sa.String, nullable=False, unique=True)
    project_id = sa.Column(sa.String, sa.ForeignKey("project.project_id"))
    project = relationship("Project", back_populates="models")
    version = sa.Column(sa.String)
    # time when the training was performed as unix timestamp
    trained_at = sa.Column(sa.Float)
    tags = relationship(
        "ModelTag", cascade="all, delete-orphan", back_populates="model"
    )
    nlu_evaluations = relationship(
        "NluEvaluation", back_populates="model", cascade="all, delete-orphan"
    )

    def as_dict(self) -> Dict[Text, Any]:
        return {
            "hash": self.hash,
            "model": self.name,
            "path": self.path,
            "project": self.project_id,
            "trained_at": self.trained_at,
            "version": self.version,
            "tags": [t.tag for t in self.tags],
        }


class ModelTag(Base):
    """Stores tags which have been assigned to certain models."""

    __tablename__ = "model_tag"

    model_id = sa.Column(sa.Integer, sa.ForeignKey("model.id"), primary_key=True)
    tag = sa.Column(sa.String, primary_key=True)
    model = relationship("Model", back_populates="tags")


class NluEvaluation(Base):
    """Stores the results of NLU evaluations."""

    __tablename__ = "nlu_evaluation"

    id = sa.Column(sa.Integer, utils.create_sequence(__tablename__), primary_key=True)
    model_id = sa.Column(sa.String, sa.ForeignKey("model.name"))
    model = relationship("Model", back_populates="nlu_evaluations")
    report = sa.Column(sa.Text)
    precision = sa.Column(sa.Float)
    f1 = sa.Column(sa.Float)
    accuracy = sa.Column(sa.Float)
    timestamp = sa.Column(sa.Float)  # time of the evaluation as unix timestamp
    predictions = relationship(
        "NluEvaluationPrediction", cascade="all", back_populates="evaluation"
    )

    def as_dict(self) -> Dict[Text, Union[Text, Dict[Text, Any]]]:
        """Return a JSON-like representation of this `NluEvaluation` object.

        Returns:
            Object as a dictionary.
        """
        report = None

        if self.report is not None:
            try:
                report = json.loads(self.report)
            except json.decoder.JSONDecodeError:
                # Old reports are plain strings
                report = self.report

        return {
            "intent_evaluation": {
                "report": report,
                "f1_score": self.f1,
                "accuracy": self.accuracy,
                "precision": self.precision,
                "predictions": [p.as_dict() for p in self.predictions],
                "timestamp": self.timestamp,
            },
            "model": self.model_id,
        }


class NluEvaluationPrediction(Base):
    """Stores the predictions which were done as part of the NLU evaluation."""

    __tablename__ = "nlu_evaluation_prediction"

    id = sa.Column(sa.Integer, utils.create_sequence(__tablename__), primary_key=True)
    evaluation_id = sa.Column(sa.Integer, sa.ForeignKey("nlu_evaluation.id"))
    evaluation = relationship("NluEvaluation", back_populates="predictions")
    text = sa.Column(sa.String)
    intent = sa.Column(sa.String)
    predicted = sa.Column(sa.String)
    confidence = sa.Column(sa.Float)

    def as_dict(self) -> Dict[Text, Union[Text, float]]:
        return {
            "text": self.text,
            "intent": self.intent,
            "predicted": self.predicted,
            "confidence": self.confidence,
        }


class TrainingStatus(Enum):
    """Status of the training."""

    IN_PROGRESS = 0
    SUCCESS = 1
    FAILURE = 2


class ModelTrainingJob(Base):
    """Stores metadata about model training."""

    __tablename__ = "model_training_job"

    id = sa.Column(sa.Integer, utils.create_sequence("mtj"), primary_key=True)
    status = sa.Column(
        sa.Enum(TrainingStatus), default=TrainingStatus.IN_PROGRESS, nullable=False
    )
    started_at = sa.Column(sa.DateTime, default=datetime.utcnow, nullable=False)
    finished_at = sa.Column(sa.DateTime, nullable=True)
    initiated_by = sa.Column(sa.String, nullable=False)
    details = sa.Column(sa.Text, nullable=True)

    def as_dict(self) -> Dict[Text, Any]:
        """Converts the class into a dict."""
        finished_at = None
        if self.finished_at:
            finished_at = self.finished_at.timestamp()

        return {
            "id": self.id,
            "status": self.status.name.lower(),
            "started_at": self.started_at.timestamp(),
            "finished_at": finished_at,
            "initiated_by": self.initiated_by,
            "details": json.loads(self.details) if self.details else None,
        }
