"""Add Single Source of Truth tables.

Reason:
This new feature includes some new models, this migration
creates four of them:
* Business Logic Flow
* Business Logic Flow Element
* Example Conversation
* Example Conversation Item

Revision ID: 9e0d9393896a
Revises: 652500998f3e

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = "9e0d9393896a"
down_revision = "fd5123586aee"
branch_labels = None
depends_on = None

TBL_BUSINESS_LOGIC_FLOW = "business_logic_flow"
TBL_BUSINESS_LOGIC_FLOW_ELEMENT = "business_logic_flow_element"

TBL_EXAMPLE_CONVERSATION = "example_conversation"
TBL_EXAMPLE_CONVERSATION_ITEM = "example_conversation_item"


def upgrade():
    """Creates the tables."""
    op.create_table(
        TBL_BUSINESS_LOGIC_FLOW,
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )

    op.create_table(
        TBL_BUSINESS_LOGIC_FLOW_ELEMENT,
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("business_logic_flow_id", sa.Integer(), nullable=False),
        sa.Column("type", sa.String(255), nullable=False),
        sa.Column("element_id", sa.String(255), nullable=False),
        sa.Column("data", sa.Text(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ("business_logic_flow_id",),
            [f"{TBL_BUSINESS_LOGIC_FLOW}.id"],
            ondelete="CASCADE",
        ),
    )

    op.create_table(
        TBL_EXAMPLE_CONVERSATION,
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )

    op.create_table(
        TBL_EXAMPLE_CONVERSATION_ITEM,
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("example_conversation_id", sa.Integer(), nullable=False),
        sa.Column("type", sa.String(255), nullable=False),
        sa.Column("text", sa.Text(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ("example_conversation_id",),
            [f"{TBL_EXAMPLE_CONVERSATION}.id"],
            ondelete="CASCADE",
        ),
    )


def downgrade():
    """Drops the tables."""
    op.drop_table(TBL_BUSINESS_LOGIC_FLOW_ELEMENT)
    op.drop_table(TBL_BUSINESS_LOGIC_FLOW)

    op.drop_table(TBL_EXAMPLE_CONVERSATION_ITEM)
    op.drop_table(TBL_EXAMPLE_CONVERSATION)
