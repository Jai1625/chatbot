"""Ensure existing users have a default workspace.

Reason:
We need to create and assign default workspaces to already existing users.
New users will have a default workspace assigned via "UserService::create_user()" or
"UserService::create_saml_user()".

Revision ID: 1a0c7b2d9ad2
Revises: 586d4d0aeecf

"""
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "1a0c7b2d9ad2"
down_revision = "586d4d0aeecf"
branch_labels = None
depends_on = None

USERS_TABLE_NAME = "rasa_x_user"
WORKSPACES_TABLE_NAME = "workspace"
DEFAULT_WORKSPACE_ID_COL = "default_workspace_id"
WORKSPACE_NAME_TEMPLATE = "Default Workspace for {}"


def upgrade():
    """Makes sure all users have a default workspace."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    users_table = migration_utils.get_reflected_table(USERS_TABLE_NAME, session)
    workspace_table = migration_utils.get_reflected_table(
        WORKSPACES_TABLE_NAME, session
    )

    for user in session.query(users_table).all():
        if not user.default_workspace_id:
            workspace_name = WORKSPACE_NAME_TEMPLATE.format(user.username)
            insert_query = workspace_table.insert().values(name=workspace_name)
            workspace_id = session.execute(insert_query).inserted_primary_key
            if not workspace_id:
                raise ValueError(
                    f"Failed to create a default workspace for {user.username}"
                )
            update_query = (
                sa.update(users_table)
                .where(users_table.c.username == user.username)
                .values(default_workspace_id=workspace_id[0])
            )
            session.execute(update_query)


def downgrade():
    """Deletes all workspaces."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    workspace_table = migration_utils.get_reflected_table(
        WORKSPACES_TABLE_NAME, session
    )
    users_table = migration_utils.get_reflected_table(USERS_TABLE_NAME, session)

    delete = sa.delete(workspace_table)
    session.execute(delete)

    for user in session.query(users_table).all():
        update_query = (
            sa.update(users_table)
            .where(users_table.c.username == user.username)
            .values(default_workspace_id=None)
        )
        session.execute(update_query)
