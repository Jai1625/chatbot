"""Add assistant permissions to existing annotator and tester roles.

Reason:
The annotator and tester roles will get these permissions automatically when
starting on a fresh database, but for existing ones we need
to add them in this migration.


Revision ID: b135bb52d0a6
Revises: fa85875bdbf0

"""
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
from rasax.community.services.user_service import ANNOTATOR, TESTER


# revision identifiers, used by Alembic.
revision = "b135bb52d0a6"
down_revision = "fa85875bdbf0"
branch_labels = None
depends_on = None


def upgrade():
    """Add the permission groups to annotator and tester roles."""
    migration_utils.add_new_permission_to(ANNOTATOR, "blueprints.*")
    migration_utils.add_new_permission_to(TESTER, "blueprints.view.*")


def downgrade():
    """Remove the permission groups to annotator and tester roles."""
    migration_utils.delete_permission_from(ANNOTATOR, "blueprints.*")
    migration_utils.delete_permission_from(TESTER, "blueprints.view.*")
