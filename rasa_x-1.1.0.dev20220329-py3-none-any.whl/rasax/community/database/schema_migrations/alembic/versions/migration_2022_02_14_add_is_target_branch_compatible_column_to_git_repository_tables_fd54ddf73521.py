"""add is_target_branch_compatible column to GitRepository tables.

Reason:
We need to know if the connected Git repository branch contains incompatible data

Revision ID: fd54ddf73521
Revises: 0cc19d3de28a

"""
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils

# revision identifiers, used by Alembic.
revision = "fd54ddf73521"
down_revision = "0cc19d3de28a"
branch_labels = None
depends_on = None

TBL_GIT_REPOSITORY = "git_repository"

COL_IS_BRANCH_COMPATIBLE = "is_target_branch_compatible"


def upgrade():
    """Upgrade database."""
    is_branch_compatible_args = {
        "nullable": False,
        "server_default": sa.sql.expression.false(),
    }
    migration_utils.create_column(
        TBL_GIT_REPOSITORY,
        sa.Column(COL_IS_BRANCH_COMPATIBLE, sa.Boolean, **is_branch_compatible_args),
    )


def downgrade():
    """Downgrade database."""
    migration_utils.drop_column(TBL_GIT_REPOSITORY, COL_IS_BRANCH_COMPATIBLE)
