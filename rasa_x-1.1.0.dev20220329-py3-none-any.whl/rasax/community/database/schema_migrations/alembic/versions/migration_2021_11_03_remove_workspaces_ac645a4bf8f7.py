"""Remove workspaces.

Reason:
Remove the workspaces feature.

Revision ID: ac645a4bf8f7
Revises: d0e8d1bde9fb

"""
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
from rasax.community.services.user_service import ADMIN, ANNOTATOR
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "ac645a4bf8f7"
down_revision = "d0e8d1bde9fb"
branch_labels = None
depends_on = None

WORKSPACE_TABLE = "workspace"
MESSAGE_LOG_TABLE = "message_log"
USER_TABLE = "rasa_x_user"

DEFAULT_WORKSPACE_ID_COL = "default_workspace_id"
WORKSPACE_ID_COL = "workspace_id"

USER_FK_NAME = "fk_user_default_w_id"
DRAFT_FK_NAME = "fk_draft_workspace_id"

CONSTRAINT_NAME = "user_default_w_uq"

MESSAGE_LOG_WORKSPACE_ID_INDEX_NAME = "msg_log_workspace_id_idx"

WORKSPACE_NAME_TEMPLATE = "Default Workspace for {}"


def upgrade():
    """Remove workspaces permissions for annotator and admin."""
    migration_utils.delete_permission_from(ANNOTATOR, "workspaces.*")
    migration_utils.delete_permission_from(ADMIN, "workspaces.*")

    # remove the sequence for workspaces
    migration_utils.drop_sequence(WORKSPACE_TABLE)

    # remove default workspace from user table
    if migration_utils.get_column(USER_TABLE, DEFAULT_WORKSPACE_ID_COL):
        with op.batch_alter_table(USER_TABLE) as batch_op:
            batch_op.drop_constraint(CONSTRAINT_NAME)
            batch_op.drop_constraint(USER_FK_NAME)
            batch_op.drop_column(DEFAULT_WORKSPACE_ID_COL)

    # remove workspace id from message log table
    if migration_utils.get_column(MESSAGE_LOG_TABLE, WORKSPACE_ID_COL):
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.drop_index(MESSAGE_LOG_WORKSPACE_ID_INDEX_NAME)
            batch_op.drop_constraint(DRAFT_FK_NAME)
            batch_op.drop_column(WORKSPACE_ID_COL)

    op.drop_table(WORKSPACE_TABLE)


def downgrade():
    """Downgrade."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    op.create_table(
        WORKSPACE_TABLE,
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )

    if not migration_utils.get_column(USER_TABLE, DEFAULT_WORKSPACE_ID_COL):
        with op.batch_alter_table(USER_TABLE) as batch_op:
            batch_op.add_column(
                sa.Column(DEFAULT_WORKSPACE_ID_COL, sa.Integer(), nullable=True)
            )
            batch_op.create_foreign_key(
                USER_FK_NAME,
                WORKSPACE_TABLE,
                [DEFAULT_WORKSPACE_ID_COL],
                ["id"],
                ondelete="SET NULL",
            )
            batch_op.create_unique_constraint(
                CONSTRAINT_NAME, [DEFAULT_WORKSPACE_ID_COL]
            )

    migration_utils.add_new_permission_to(ANNOTATOR, "workspaces.*")
    migration_utils.add_new_permission_to(ADMIN, "workspaces.*")

    if not migration_utils.get_column(MESSAGE_LOG_TABLE, WORKSPACE_ID_COL):
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.add_column(
                sa.Column(WORKSPACE_ID_COL, sa.Integer(), nullable=True)
            )
            batch_op.create_foreign_key(
                DRAFT_FK_NAME,
                WORKSPACE_TABLE,
                [WORKSPACE_ID_COL],
                ["id"],
                ondelete="SET NULL",
            )
            batch_op.create_index(
                MESSAGE_LOG_WORKSPACE_ID_INDEX_NAME, [WORKSPACE_ID_COL]
            )

    # make sure that the index is partial
    if migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    ) or migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        op.drop_index(MESSAGE_LOG_WORKSPACE_ID_INDEX_NAME)
        index_text = f"{WORKSPACE_ID_COL} is not NULL"
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.create_index(
                MESSAGE_LOG_WORKSPACE_ID_INDEX_NAME,
                [WORKSPACE_ID_COL],
                postgresql_where=sa.text(index_text),
                sqlite_where=sa.text(index_text),
            )

    # add a squence for the workspaces table
    migration_utils.create_sequence(WORKSPACE_TABLE)

    users_table = migration_utils.get_reflected_table(USER_TABLE, session)
    workspace_table = migration_utils.get_reflected_table(WORKSPACE_TABLE, session)

    # make sure that all users have a default workspace
    for user in session.query(users_table).all():
        if not user.default_workspace_id:
            workspace_name = WORKSPACE_NAME_TEMPLATE.format(user.username)
            insert_query = workspace_table.insert().values(name=workspace_name)
            workspace_id = session.execute(insert_query).inserted_primary_key
            if not workspace_id:
                raise ValueError(
                    f"Failed to create a default workspace for {user.username}"
                )
            update_query = (
                sa.update(users_table)
                .where(users_table.c.username == user.username)
                .values(default_workspace_id=workspace_id[0])
            )
            session.execute(update_query)
