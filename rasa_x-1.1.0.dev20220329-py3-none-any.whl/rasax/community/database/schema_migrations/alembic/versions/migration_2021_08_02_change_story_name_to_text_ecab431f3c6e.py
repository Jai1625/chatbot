"""Change story name to text.

Reason:
`story.title` is currently stored as a string (VARCHAR 255), but
Rasa OSS supports arbitrary length names since it's in YAML.

Revision ID: ecab431f3c6e
Revises: 1a0c7b2d9ad2

"""
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "ecab431f3c6e"
down_revision = "1a0c7b2d9ad2"
branch_labels = None
depends_on = None

TABLE_NAME = "story"
COLUMN_NAME = "name"


def upgrade():
    """Upgrade the database."""
    migration_utils.modify_columns(
        TABLE_NAME,
        [
            migration_utils.ColumnTransformation(
                COLUMN_NAME, new_column_kwargs={"type_": sa.Text()},
            )
        ],
    )


def downgrade():
    """Downgrade the database."""
    migration_utils.modify_columns(
        TABLE_NAME,
        [
            migration_utils.ColumnTransformation(
                COLUMN_NAME,
                new_column_kwargs={"type_": sa.String(255)},
                modify_from_column_value=lambda x: x[0:255],
            )
        ],
    )
