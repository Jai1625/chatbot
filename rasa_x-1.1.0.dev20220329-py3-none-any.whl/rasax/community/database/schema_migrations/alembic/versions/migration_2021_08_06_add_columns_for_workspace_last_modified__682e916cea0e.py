"""Add columns for workspace last modified info.

Reason:
Add `last_modified_at` and `last_modifier_id` columns to the `workspace` table
so that this information can be updated whenever a workspace is modified, and then
displayed in the UI.

Revision ID: 682e916cea0e
Revises: ecab431f3c6e

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "682e916cea0e"
down_revision = "ecab431f3c6e"
branch_labels = None
depends_on = None

TABLE = "workspace"
CREATED_AT = "created_at"
LAST_MODIFIER_ID = "last_modifier_id"
LAST_MODIFIED_AT = "last_modified_at"
FK_NAME = "fk_last_modifier_username"


def upgrade():
    """Add the columns to the `workspace` table."""
    with op.batch_alter_table(TABLE) as batch_op:
        batch_op.add_column(sa.Column(CREATED_AT, sa.Float()))
        batch_op.add_column(sa.Column(LAST_MODIFIED_AT, sa.Float()))
        batch_op.add_column(sa.Column(LAST_MODIFIER_ID, sa.String(255)))
        batch_op.create_foreign_key(
            FK_NAME,
            "rasa_x_user",
            [LAST_MODIFIER_ID],
            ["username"],
            ondelete="SET NULL",
        )


def downgrade():
    """Remove the columns from the `workspace` table."""
    with op.batch_alter_table(TABLE) as batch_op:
        batch_op.drop_constraint(FK_NAME)
        batch_op.drop_column(LAST_MODIFIER_ID)
        batch_op.drop_column(LAST_MODIFIED_AT)
        batch_op.drop_column(CREATED_AT)
