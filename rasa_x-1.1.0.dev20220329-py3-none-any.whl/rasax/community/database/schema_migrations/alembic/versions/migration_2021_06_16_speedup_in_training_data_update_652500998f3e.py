"""Add index to improve bulk updating the `in_training_data` column.

Reason:
The bulk update for the `in_training_data` column
(see LogsService.bulk_update_in_training_data_column) led to significant performance
problems with enterprise-sized datasets. This migration adds an index to speed up
this bulk update.

Revision ID: 652500998f3e
Revises: d741ab0a01aa

"""
from alembic import op
import sqlalchemy as sa

from rasax.community.database.schema_migrations.alembic import utils as migration_utils


# revision identifiers, used by Alembic.
revision = "652500998f3e"
down_revision = "d741ab0a01aa"
branch_labels = None
depends_on = None

MESSAGE_LOG_TABLE = "message_log"
IN_TRAINING_DATA_COLUMN = "in_training_data"
IN_TRAINING_DATA_INDEX_NAME = "message_log_in_training_data_idx"


def upgrade():
    """Adds new indexes to speed up `in_training_data` bulk update."""
    if migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    ) or migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):

        index_text = f"{IN_TRAINING_DATA_COLUMN} is True"
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.create_index(
                IN_TRAINING_DATA_INDEX_NAME,
                [IN_TRAINING_DATA_COLUMN],
                postgresql_where=sa.text(index_text),
                sqlite_where=sa.text(index_text),
            )


def downgrade():
    """Drops indexes which were created to speed up `in_training_data` bulk update."""
    if migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    ) or migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        op.drop_index(IN_TRAINING_DATA_INDEX_NAME)
