"""Add message tags.

Reason:
Add table "message_log_to_tag_mapping" and renamed "ConversationTag" to "DataTag".
They allow Rasa X to store tags of arbitrary colored tags for both messages,
and Conversations (see revision 0b35090e53cf). They are using the same tag set.

Revision ID: 895af7dcae07
Revises: 47396643a5b4

"""
from alembic import op
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
from sqlalchemy import inspect
from sqlalchemy.dialects.sqlite.base import SQLiteDialect

revision = "895af7dcae07"
down_revision = "47396643a5b4"
branch_labels = None
depends_on = None

MESSAGE_LOG_TO_TAG_MAPPING = "message_log_to_tag_mapping"
CONVERSATION_TO_TAG_MAPPING = "conversation_to_tag_mapping"

DATA_TAG = "data_tag"
CONVERSATION_TAG = "conversation_tag"

DATA_TAG_ID = "data_tag_id"
MESSAGE_LOG_ID = "message_log_id"
TAG_ID = "tag_id"
CONVERSATION_ID = "conversation_id"

CTTM_DATA_TAG_ID_INDEX = "cttm_data_tag_id_index"
CTTM_TAG_ID_INDEX = "cttm_tag_id_index"

MTTM_DATA_TAG_ID_INDEX = "mttm_data_tag_id_index"
MTTM_MESSAGE_ID_INDEX = "mttm_message_id_index"
FK_CONVERSATION_TO_DATA_TAG_MAPPING = "fk_conv_to_data_tag_map"


def _drop_constraint_on_conversation_tags():
    context = op.get_context()

    if isinstance(context.dialect, SQLiteDialect):
        # For SQLite naming convention has to be used to drop the unnamed constraint
        naming_convention = {
            "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
        }
        with op.batch_alter_table(
            CONVERSATION_TO_TAG_MAPPING, naming_convention=naming_convention
        ) as batch_op:
            batch_op.drop_constraint(
                "fk_conversation_to_tag_mapping_tag_id_conversation_tag"
            )
    else:
        inspector = inspect(op.get_bind())
        for key in inspector.get_foreign_keys(CONVERSATION_TO_TAG_MAPPING):
            if CONVERSATION_TAG not in key["referred_table"]:
                continue
            with op.batch_alter_table(CONVERSATION_TO_TAG_MAPPING) as batch_op:
                batch_op.drop_constraint(key["name"])


def upgrade():
    """Perform upgrade of the DB schema."""
    _drop_constraint_on_conversation_tags()

    with op.batch_alter_table(CONVERSATION_TO_TAG_MAPPING) as batch_op:
        batch_op.drop_index(CTTM_TAG_ID_INDEX)
        batch_op.alter_column(TAG_ID, new_column_name=DATA_TAG_ID)

    # rename conversation tag to data tag
    op.rename_table(CONVERSATION_TAG, DATA_TAG)

    # change conversation tag column to data tag column in conversation to tag mapping
    with op.batch_alter_table(CONVERSATION_TO_TAG_MAPPING) as batch_op:
        batch_op.create_index(CTTM_DATA_TAG_ID_INDEX, [DATA_TAG_ID], unique=False)
        batch_op.create_foreign_key(
            FK_CONVERSATION_TO_DATA_TAG_MAPPING, DATA_TAG, [DATA_TAG_ID], ["id"]
        )

    op.create_table(
        MESSAGE_LOG_TO_TAG_MAPPING,
        sa.Column(MESSAGE_LOG_ID, sa.Integer(), nullable=False),
        sa.Column(DATA_TAG_ID, sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint([MESSAGE_LOG_ID], ["message_log.id"],),
        sa.ForeignKeyConstraint([DATA_TAG_ID], [f"{DATA_TAG}.id"],),
    )

    # use shorter suffix for this sequence to fit the 30-char limit
    migration_utils.create_sequence(MESSAGE_LOG_TO_TAG_MAPPING, suffix="seq")

    with op.batch_alter_table(MESSAGE_LOG_TO_TAG_MAPPING) as batch_op:
        batch_op.create_index(MTTM_MESSAGE_ID_INDEX, [MESSAGE_LOG_ID], unique=False)
        batch_op.create_index(MTTM_DATA_TAG_ID_INDEX, [DATA_TAG_ID], unique=False)


def downgrade():
    """Perform downgrade of the DB schema."""
    with op.batch_alter_table(CONVERSATION_TO_TAG_MAPPING) as batch_op:
        batch_op.drop_constraint(FK_CONVERSATION_TO_DATA_TAG_MAPPING)
        batch_op.drop_index(CTTM_DATA_TAG_ID_INDEX)
        batch_op.alter_column(DATA_TAG_ID, nullable=False, new_column_name=TAG_ID)

    with op.batch_alter_table(MESSAGE_LOG_TO_TAG_MAPPING) as batch_op:
        batch_op.drop_index(op.f(MTTM_MESSAGE_ID_INDEX))
        batch_op.drop_index(op.f(MTTM_DATA_TAG_ID_INDEX))

    op.rename_table(DATA_TAG, CONVERSATION_TAG)
    op.drop_table(MESSAGE_LOG_TO_TAG_MAPPING)

    with op.batch_alter_table(CONVERSATION_TO_TAG_MAPPING) as batch_op:
        batch_op.create_index(CTTM_TAG_ID_INDEX, [TAG_ID], unique=False)
        batch_op.create_foreign_key(CONVERSATION_TAG, [TAG_ID], ["id"])
