"""Add Blueprints demo objects.

Reason:
Add demo Flow with elements, Dialogue with items, and a Link.

Update: This has been superseded by a proper way of creating
Demo objects. Given that this migration only created
new data, and did not change any schema, it is now a no-op.

Revision ID: d0e8d1bde9fb
Revises: e9d525b27748

"""
# revision identifiers, used by Alembic.
revision = "d0e8d1bde9fb"
down_revision = "e9d525b27748"
branch_labels = None
depends_on = None


def upgrade():
    """Upgrade database."""
    pass


def downgrade():
    """Downgrade database."""
    pass
