"""Statistics on used slot names.

Reason:
Add a separate table for all slot names from observed SlotSet events in our
conversation events. Using this table, we can properly show all slot names
without needing to iterate over all events.

Revision ID: b85106c82c99
Revises: ecab431f3c6e

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import func

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "b85106c82c99"
down_revision = "682e916cea0e"
branch_labels = None
depends_on = None

CONVERSATIONS_TABLE_NAME = "conversation_event"
STATISTICS_TABLE_NAME = "conversation_slot_statistic"


def _migrate_events(session, events_table, statistics_table):

    query = session.query(
        events_table.c.slot_name, func.count(events_table.c.slot_name)
    ).group_by(events_table.c.slot_name)

    for row in query:
        slot_name = row[0]
        count = row[1]

        if slot_name is None:
            continue

        # conversation events are not attached to projects so we need to use default
        insert_query = statistics_table.insert().values(
            project_id="default", slot_name=slot_name, count=count
        )
        session.execute(insert_query)


def upgrade():
    """Create a slot name statistics table and populate with data from existing events."""
    op.create_table(
        STATISTICS_TABLE_NAME,
        sa.Column("project_id", sa.String(255), nullable=False),
        sa.Column("slot_name", sa.String(255), nullable=False),
        sa.Column("count", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(["project_id"], ["conversation_statistic.project_id"]),
        sa.PrimaryKeyConstraint("project_id", "slot_name"),
    )

    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    events_table = migration_utils.get_reflected_table(
        CONVERSATIONS_TABLE_NAME, session
    )
    statistics_table = migration_utils.get_reflected_table(
        STATISTICS_TABLE_NAME, session
    )

    if session.query(events_table).first():
        _migrate_events(session, events_table, statistics_table)


def downgrade():
    """Drop slot name statistics table."""
    op.drop_table(STATISTICS_TABLE_NAME)
