"""Fix model training job sequences.

Reason:
Fix missing sequence for Oracle by creating new one with shorter name and renaming the old sequence in Postgres to match it.

Revision ID: 1340c2b49828
Revises: 1d51a7397a51

"""
from alembic import op

import rasax.community.database.schema_migrations.alembic.utils as migration_utils

# revision identifiers, used by Alembic.
revision = "1340c2b49828"
down_revision = "1d51a7397a51"
branch_labels = None
depends_on = None

model_training_job_db_name = "model_training_job"
model_training_job_seq_name = "mtj"


def upgrade():
    """Upgrade database."""
    # Skip this migration on SQLite since it doesn't support sequences.
    if migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        return

    is_postgresql = migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    )

    is_oracle = migration_utils.using_dialect(
        migration_utils.ORACLE_DIALECT, op.get_bind()
    )

    if is_postgresql:
        op.execute(
            f"ALTER SEQUENCE {model_training_job_db_name}_id_seq RENAME TO {model_training_job_seq_name}_seq"
        )

    if is_oracle:
        seq = migration_utils.create_sequence(
            model_training_job_seq_name, suffix="_seq"
        )
        op.alter_column(
            model_training_job_db_name, "id", server_default=seq.next_value()
        )


def downgrade():
    """Downgrade database."""
    # Skip this migration on SQLite since it doesn't support sequences.
    if migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        return

    is_postgresql = migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    )

    is_oracle = migration_utils.using_dialect(
        migration_utils.ORACLE_DIALECT, op.get_bind()
    )

    if is_postgresql:
        op.execute(
            f"ALTER SEQUENCE {model_training_job_seq_name}_seq RENAME TO {model_training_job_db_name}_id_seq"
        )

    if is_oracle:
        migration_utils.drop_sequence(model_training_job_seq_name, suffix="_seq")
