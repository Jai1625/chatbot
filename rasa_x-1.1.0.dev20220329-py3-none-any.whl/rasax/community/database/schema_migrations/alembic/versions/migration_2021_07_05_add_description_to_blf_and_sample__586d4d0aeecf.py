"""Add `description` to Business Logic Flows and Sample Conversation tables.

Reason:
Both of these models will have a nullable `TEXT` column to store a description.

Revision ID: 586d4d0aeecf
Revises: 072f6bf4d5dc

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "586d4d0aeecf"
down_revision = "072f6bf4d5dc"
branch_labels = None
depends_on = None

BLF_TABLE = "business_logic_flow"
SC_TABLE = "example_conversation"
COLUMN = "description"


def upgrade():
    """Add `description` columns."""
    with op.batch_alter_table(BLF_TABLE) as batch_op:
        batch_op.add_column(sa.Column(COLUMN, sa.Text()))

    with op.batch_alter_table(SC_TABLE) as batch_op:
        batch_op.add_column(sa.Column(COLUMN, sa.Text()))


def downgrade():
    """Drop `description` columns."""
    with op.batch_alter_table(BLF_TABLE) as batch_op:
        batch_op.drop_column(COLUMN)

    with op.batch_alter_table(SC_TABLE) as batch_op:
        batch_op.drop_column(COLUMN)
