"""Set up cascading deletions by conversation_id.

Reason:
In order to speed up deletions by conversation_id we move the `cascade delete`
from the SQLAlchemy to the DB side.

Revision ID: 5ff5fa10d3c0
Revises: 97280f5b6803

"""
from alembic import op

from rasax.community.database.schema_migrations.alembic import utils as migration_utils
from sqlalchemy import inspect

# revision identifiers, used by Alembic.
revision = "5ff5fa10d3c0"
down_revision = "97280f5b6803"
branch_labels = None
depends_on = None

CONVERSATION_TABLE = "conversation"
CONVERSATION_EVENT_TABLE = "conversation_event"
MESSAGE_LOG_TABLE = "message_log"

CHANGES = [
    {
        "TABLE_NAME": CONVERSATION_EVENT_TABLE,
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "conv_ev_conv_id_fkey",
    },
    {
        "TABLE_NAME": MESSAGE_LOG_TABLE,
        "COLUMN_NAME": "event_id",
        "SOURCE_TABLE_NAME": CONVERSATION_EVENT_TABLE,
        "SOURCE_COLUMN_NAME": "id",
        "FOREIGN_KEY_NAME": "msg_log_event_id_fkey",
    },
    {
        "TABLE_NAME": MESSAGE_LOG_TABLE,
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "msg_log_conv_id_fkey",
    },
    {
        "TABLE_NAME": "conversation_policy_metadata",
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "conv_plc_meta_conv_id_fkey",
    },
    {
        "TABLE_NAME": "conversation_action_metadata",
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "conv_act_meta_conv_id_fkey",
    },
    {
        "TABLE_NAME": "conversation_intent_metadata",
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "conv_int_meta_conv_id_fkey",
    },
    {
        "TABLE_NAME": "conversation_entity_metadata",
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "conv_ent_meta_conv_id_fkey",
    },
    {
        "TABLE_NAME": "message_correction",
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "msg_cor_conv_id_fkey",
    },
    {
        "TABLE_NAME": "conversation_session",
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "conv_session_conv_id_fkey",
    },
    {
        "TABLE_NAME": "conversation_to_tag_mapping",
        "COLUMN_NAME": "conversation_id",
        "SOURCE_TABLE_NAME": CONVERSATION_TABLE,
        "SOURCE_COLUMN_NAME": "sender_id",
        "FOREIGN_KEY_NAME": "conv_to_tag_map_conv_id_fkey",
    },
]

MESSAGE_LOG_INDICES = [
    ("msglg_to_conv_id_fkey", ["conversation_id"]),
    ("msglg_to_evnt_id_fkey", ["event_id"]),
]

NAMING_CONVENTION = {
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
}


def _create_additional_index():
    for index in MESSAGE_LOG_INDICES:
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.create_index(index[0], index[1])


def _drop_additional_index():
    for index in MESSAGE_LOG_INDICES:
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.drop_index(index[0])


def upgrade():
    """Make sure foreign keys use cascade deletions."""
    inspector = inspect(op.get_bind())

    for change in CHANGES:
        for key in inspector.get_foreign_keys(change["TABLE_NAME"]):
            if (
                change["COLUMN_NAME"] not in key["constrained_columns"]
                or change["SOURCE_TABLE_NAME"] not in key["referred_table"]
                or change["SOURCE_COLUMN_NAME"] not in key["referred_columns"]
            ):
                continue

            if migration_utils.using_dialect(
                migration_utils.SQLITE_DIALECT, op.get_bind()
            ):
                # SQLite naming convention has to be used to drop the unnamed constraint
                with op.batch_alter_table(
                    change["TABLE_NAME"], naming_convention=NAMING_CONVENTION
                ) as batch_op:
                    if not key["name"]:
                        key["name"] = (
                            f"fk_{change['TABLE_NAME']}_"
                            f"{key['constrained_columns'][0]}_"
                            f"{key['referred_table']}"
                        )
                    batch_op.drop_constraint(key["name"], type_="foreignkey")
                    batch_op.create_foreign_key(
                        key["name"],
                        change["SOURCE_TABLE_NAME"],
                        [change["COLUMN_NAME"]],
                        [change["SOURCE_COLUMN_NAME"]],
                        ondelete="CASCADE",
                    )
            else:
                with op.batch_alter_table(change["TABLE_NAME"]) as batch_op:
                    batch_op.drop_constraint(key["name"])
                    batch_op.create_foreign_key(
                        change["FOREIGN_KEY_NAME"],
                        change["SOURCE_TABLE_NAME"],
                        [change["COLUMN_NAME"]],
                        [change["SOURCE_COLUMN_NAME"]],
                        ondelete="CASCADE",
                    )

    _create_additional_index()


def downgrade():
    """Perform downgrade of the DB schema."""
    _drop_additional_index()

    inspector = inspect(op.get_bind())

    for change in CHANGES:
        for key in inspector.get_foreign_keys(change["TABLE_NAME"]):
            if (
                change["COLUMN_NAME"] not in key["constrained_columns"]
                or change["SOURCE_TABLE_NAME"] not in key["referred_table"]
                or change["SOURCE_COLUMN_NAME"] not in key["referred_columns"]
            ):
                continue

            if migration_utils.using_dialect(
                migration_utils.SQLITE_DIALECT, op.get_bind()
            ):
                with op.batch_alter_table(
                    change["TABLE_NAME"], naming_convention=NAMING_CONVENTION
                ) as batch_op:
                    if not key["name"]:
                        key["name"] = (
                            f"fk_{change['TABLE_NAME']}_"
                            f"{key['constrained_columns'][0]}_"
                            f"{key['referred_table']}"
                        )
                    batch_op.drop_constraint(
                        key["name"], type_="foreignkey",
                    )
                    # create unnamed constraints without on delete cascade
                    batch_op.create_foreign_key(
                        key["name"],
                        change["SOURCE_TABLE_NAME"],
                        [change["COLUMN_NAME"]],
                        [change["SOURCE_COLUMN_NAME"]],
                    )

            else:
                with op.batch_alter_table(change["TABLE_NAME"]) as batch_op:
                    batch_op.drop_constraint(
                        change["FOREIGN_KEY_NAME"], type_="foreignkey",
                    )
                    # create unnamed constraints without on delete cascade
                    batch_op.create_foreign_key(
                        change["FOREIGN_KEY_NAME"],
                        change["SOURCE_TABLE_NAME"],
                        [change["COLUMN_NAME"]],
                        [change["SOURCE_COLUMN_NAME"]],
                    )
