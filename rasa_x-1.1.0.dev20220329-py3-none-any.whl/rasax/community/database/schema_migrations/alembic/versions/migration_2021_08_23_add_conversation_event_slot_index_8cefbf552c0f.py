"""Add conversation_event slot index.

Reason:
To speed up the queries for returning unique slot values
we need to create a composite index on `slot_name` and `slot_value`.
Note that on PostgreSQL and SQLite it will be a partial index excluding
any `NULL` values, this is not possible on Oracle.

Revision ID: 8cefbf552c0f
Revises: 826a0569715d

"""
from alembic import op
import sqlalchemy as sa

from rasax.community.database.schema_migrations.alembic import utils as migration_utils


# revision identifiers, used by Alembic.
revision = "8cefbf552c0f"
down_revision = "826a0569715d"
branch_labels = None
depends_on = None

INDEX = "conversation_slot_values_index"
TABLE = "conversation_event"

INDEX_COLUMNS = ["slot_name", sa.text("substr(slot_value, 1, 1024)")]
ORACLE_COLUMNS = ["slot_name", sa.text("to_char(substr(slot_value, 1, 1024))")]
PARTIAL_CLAUSE = sa.text("slot_name IS NOT NULL")


def upgrade():
    """Create an index that is tailored to the `EventService.unique_slot_values` query.

    On all database engines the index is a composite on `slot_name` and `slot_value`, but we only index the
    first 1024 characters of the `slot_value`.

    On SQLite and PostgreSQL it is a partial index filtering out any `NULL` slot names.
    Oracle doesn't support partial indexes, and on Oracle we need to cast `slot_value` with `to_char`.
    """
    columns = INDEX_COLUMNS
    if migration_utils.using_dialect(migration_utils.ORACLE_DIALECT, op.get_bind()):
        columns = ORACLE_COLUMNS

    with op.batch_alter_table(TABLE) as batch_op:
        batch_op.create_index(
            INDEX,
            columns,
            sqlite_where=PARTIAL_CLAUSE,
            postgresql_where=PARTIAL_CLAUSE,
        )


def downgrade():
    """Drop the index."""
    op.drop_index(INDEX)
