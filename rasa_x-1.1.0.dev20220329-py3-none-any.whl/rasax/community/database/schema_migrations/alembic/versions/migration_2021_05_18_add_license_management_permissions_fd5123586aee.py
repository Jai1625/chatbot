"""Add license management permissions.

Reason:
With the new Enterprise licensing system, the Rasa Enterprise license is now
stored inside the database. Two new endpoints were added for license
management, which require new permissions to be added to the `ADMIN` role.

Revision ID: fd5123586aee
Revises: 5ff5fa10d3c0

"""
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
from rasax.community.services.user_service import ADMIN


# revision identifiers, used by Alembic.
revision = "fd5123586aee"
down_revision = "41c0fb561081"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Add permissions for license management."""
    migration_utils.add_new_permission_to(ADMIN, "license.*")


def downgrade() -> None:
    """Remove permissions for license management."""
    migration_utils.delete_permission_from(ADMIN, "license.*")
