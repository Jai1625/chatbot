"""Statistic on used channel names.

Reason:
Add a separate table for all channel names used in any of our
conversation events. Using this table, we can properly show all channel names
without needing to iterate over all conversations.

Revision ID: 017cb274256f
Revises: b85106c82c99

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import Integer, String, column, table
from typing import Text

from rasax.community.database.schema_migrations.alembic import utils

# revision identifiers, used by Alembic.
revision = "017cb274256f"
down_revision = "b85106c82c99"
branch_labels = None
depends_on = None

STATISTICS_TABLE_NAME = "conversation_channel_statistic"


def _input_channel_query() -> Text:
    if utils.using_dialect("postgresql", op.get_bind()):
        value_of_input_channel_key = "data::json->>'input_channel'"
    elif utils.using_dialect("sqlite", op.get_bind()):
        value_of_input_channel_key = "json_extract(data, '$.input_channel')"
    elif utils.using_dialect("oracle", op.get_bind()):
        value_of_input_channel_key = "json_value(data, '$.input_channel')"
    else:
        raise utils.UnsupportedDatabaseError(op.get_bind().dialect.name)

    query = (
        f"SELECT "
        f"  {value_of_input_channel_key} as input_channel, "
        f"  COUNT({value_of_input_channel_key}) as count "
        f"FROM conversation_event "
        f"WHERE {value_of_input_channel_key} IS NOT NULL "
        f"GROUP BY {value_of_input_channel_key}"
    )
    return query


def _migrate_events(session):
    results = session.execute(_input_channel_query())

    channel_counts = [
        {"project_id": "default", "channel": row[0], "count": row[1]} for row in results
    ]

    channel_stats_table = table(
        STATISTICS_TABLE_NAME,
        column("project_id", String),
        column("channel", String),
        column("count", Integer),
    )

    op.bulk_insert(channel_stats_table, channel_counts)


def upgrade():
    """Create a channel name statistics table and populate with data from existing events."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    op.create_table(
        STATISTICS_TABLE_NAME,
        sa.Column("project_id", sa.String(255), nullable=False),
        sa.Column("channel", sa.String(255), nullable=False),
        sa.Column("count", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(["project_id"], ["conversation_statistic.project_id"]),
        sa.PrimaryKeyConstraint("project_id", "channel"),
    )

    _migrate_events(session)


def downgrade():
    """Drop channel name statistics table."""
    op.drop_table(STATISTICS_TABLE_NAME)
