"""Move `actions.get` permission to `domains.view` grouping.

Reason:
To be able to assign the `actions.get` grouping it has to be part of another grouping than `advanced`,
and the most  likely place for it is in `domains.view`.

Revision ID: 97280f5b6803
Revises: 164e48c773af

"""
from alembic import op
import sqlalchemy as sa
import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "97280f5b6803"
down_revision = "164e48c773af"
branch_labels = None
depends_on = None

NEW_PERMISSION = "domain.view.actions.get"
TABLE_PERMISSION = "permission"
LOOKUP_PERMISSIONS = [
    "domain.view.domain.get",
    "domain.view.domain.list",
]


def upgrade():
    """Add new `domain.view.actions.get` permission to roles with other `domain.view.{}` permissions."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    permission_tbl = migration_utils.get_reflected_table(TABLE_PERMISSION, session)
    query = (
        session.query(permission_tbl.c.role_id, permission_tbl.c.project)
        .filter(permission_tbl.c.permission.in_(LOOKUP_PERMISSIONS))
        .group_by(permission_tbl.c.role_id, permission_tbl.c.project)
    )

    for row in query:
        role_id = row[0]
        project = row[1]
        insert = sa.insert(permission_tbl).values(
            project=project, role_id=role_id, permission=NEW_PERMISSION
        )
        session.execute(insert)


def downgrade():
    """Remove `domain.view.actions.get` permission from any role."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    permission_tbl = migration_utils.get_reflected_table(TABLE_PERMISSION, session)
    delete = sa.delete(permission_tbl).where(
        permission_tbl.c.permission == NEW_PERMISSION
    )
    session.execute(delete)
