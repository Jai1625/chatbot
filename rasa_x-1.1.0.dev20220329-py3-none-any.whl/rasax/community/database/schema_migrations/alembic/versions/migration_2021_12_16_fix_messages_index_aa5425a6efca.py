"""Fix message_log text index.

Reason:
When `text` value is larger than 2712 characters we get the following error
`Values larger than 1/3 of a buffer page cannot be indexed`.

Dropping the index as it doesn't provide any performance gain as we use pattern matching queries.
A better solution for Postgres would be to create an index using the `gin` method with `pg_trgm` module.
More details:
https://github.com/RasaHQ/rasa-x/issues/6648#issuecomment-996176506

Revision ID: aa5425a6efca
Revises: 1340c2b49828

"""
from alembic import op

from rasax.community.database.schema_migrations.alembic import utils as migration_utils

# revision identifiers, used by Alembic.
revision = "aa5425a6efca"
down_revision = "1340c2b49828"
branch_labels = None
depends_on = None

INDEX = "message_log_idx_archived_text"
TABLE = "message_log"


def upgrade():
    """Drop the index."""
    if migration_utils.index_exists(TABLE, INDEX):
        op.drop_index(INDEX)


def downgrade():
    """Revert the index.

    Note that messages exceeding the maximum size need to be deleted for the downgrade to succeed.
    """
    is_sqlite = migration_utils.using_dialect(
        migration_utils.SQLITE_DIALECT, op.get_bind()
    )

    is_postgresql = migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    )

    if is_postgresql or is_sqlite:
        with op.batch_alter_table(TABLE) as batch_op:
            batch_op.create_index(INDEX, ["archived", "text"])
