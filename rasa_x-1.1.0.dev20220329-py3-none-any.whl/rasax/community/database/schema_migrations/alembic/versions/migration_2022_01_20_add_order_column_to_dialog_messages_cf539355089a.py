"""Add order column to dialog messages.

Reason:
We need to do this to enable us reorder dialogue messages.

Revision ID: cf539355089a
Revises: 66bc70f1b560

"""
from alembic import op
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "cf539355089a"
down_revision = "66bc70f1b560"
branch_labels = None
depends_on = None

TBL_EXAMPLE_CONVERSATION_ITEM = "example_conversation_item"
TBL_EXAMPLE_CONVERSATION = "example_conversation"
COL_ORDER = "order"


def _update_order_column(session) -> None:
    """Updates newly created order column."""
    example_conversation_table = migration_utils.get_reflected_table(
        TBL_EXAMPLE_CONVERSATION, session
    )
    example_conversation_item_table = migration_utils.get_reflected_table(
        TBL_EXAMPLE_CONVERSATION_ITEM, session
    )

    example_conversations = session.execute(
        example_conversation_table.select()
    ).fetchall()

    for example_conversation in example_conversations:
        order_number = 1
        session.query(example_conversation_item_table).order_by(
            example_conversation_item_table.c.id.desc()
        ).all()
        example_conversation_items = (
            session.query(example_conversation_item_table)
            .filter(
                example_conversation_item_table.c.example_conversation_id
                == example_conversation.id
            )
            .order_by(example_conversation_item_table.c.created_at.asc())
        )
        if example_conversation_items.count() > 0:
            for index, example_conversation_item in enumerate(
                example_conversation_items
            ):
                # ignore first row as it already has the right order number
                if index > 0:
                    update_query = (
                        sa.update(example_conversation_item_table)
                        .where(
                            example_conversation_item_table.c.id
                            == example_conversation_item.id
                        )
                        .values(order=order_number)
                    )
                    session.execute(update_query)
                    order_number += 1


def upgrade():
    """Creates column."""
    order_args = {"nullable": False, "server_default": "0"}
    migration_utils.create_column(
        TBL_EXAMPLE_CONVERSATION_ITEM, sa.Column(COL_ORDER, sa.Integer, **order_args)
    )

    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)
    _update_order_column(session)


def downgrade():
    """Drops column."""
    migration_utils.drop_column(TBL_EXAMPLE_CONVERSATION_ITEM, COL_ORDER)
