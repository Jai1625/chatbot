"""Add assistant permission to existing admin role.

Reason:
The admin role will get these permissions automatically when
starting on a fresh database, but for existing ones we need
to add it in this migration.

Revision ID: 072f6bf4d5dc
Revises: 9e0d9393896a

"""
import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "072f6bf4d5dc"
down_revision = "9e0d9393896a"
branch_labels = None
depends_on = None


def upgrade():
    """Add the permission group to the admin role."""
    migration_utils.add_new_permission_to("admin", "blueprints.*")


def downgrade():
    """Remove the permission group from the admin role."""
    migration_utils.delete_permission_from("admin", "blueprints.*")
