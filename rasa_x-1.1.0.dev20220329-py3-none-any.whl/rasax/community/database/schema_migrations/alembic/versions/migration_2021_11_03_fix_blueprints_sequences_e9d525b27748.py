"""Fix Blueprints sequences.

Reason:
Fix missing sequences for Oracle by creating new ones with a shorter name and use them for both PostgreSQL and Oracle.

Revision ID: e9d525b27748
Revises: 752ee6ed5d9f

"""
from alembic import op

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "e9d525b27748"
down_revision = "752ee6ed5d9f"
branch_labels = None
depends_on = None


def upgrade():
    """Upgrade database."""
    # Skip this migration no SQLite since it doesn't support sequences.
    if migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        return

    is_postgresql = migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    )

    # Add sequence for `business_logic_flow` table and change the `id`'s default value
    blf_seq = migration_utils.create_sequence("blf")
    op.alter_column("business_logic_flow", "id", server_default=blf_seq.next_value())
    # On postgresql drop the automatically created `business_logic_flow_id_seq` sequence.
    if is_postgresql:
        migration_utils.drop_sequence("business_logic_flow_id_seq", suffix="")

    # Add sequence for `business_logic_flow_element` table and change the `id`'s default value
    blf_element_seq = migration_utils.create_sequence("blf_element")
    op.alter_column(
        "business_logic_flow_element", "id", server_default=blf_element_seq.next_value()
    )
    # On postgresql drop the automatically created `business_logic_flow_element_id_seq` sequence.
    if is_postgresql:
        migration_utils.drop_sequence("business_logic_flow_element_id_seq", suffix="")

    # Add sequence for `example_conversation` table and change the `id`'s default value
    sc_seq = migration_utils.create_sequence("sc")
    op.alter_column("example_conversation", "id", server_default=sc_seq.next_value())
    # On postgresql drop the automatically created `business_logic_flow_element_id_seq` sequence.
    if is_postgresql:
        migration_utils.drop_sequence("example_conversation_id_seq", suffix="")

    # Add sequence for `example_conversation_item` table and change the `id`'s default value
    sc_item_seq = migration_utils.create_sequence("sc_item")
    op.alter_column(
        "example_conversation_item", "id", server_default=sc_item_seq.next_value()
    )
    # On postgresql drop the automatically created `business_logic_flow_element_id_seq` sequence.
    if is_postgresql:
        migration_utils.drop_sequence("example_conversation_item_id_seq", suffix="")

    # Add sequence for `assistant_link` table and change the `id`'s default value
    link_seq = migration_utils.create_sequence("link")
    op.alter_column("assistant_link", "id", server_default=link_seq.next_value())
    # On postgresql drop the automatically created `business_logic_flow_element_id_seq` sequence.
    if is_postgresql:
        migration_utils.drop_sequence("assistant_link_id_seq", suffix="")


def downgrade():
    """Downgrade database."""
    # Skip this migration no SQLite since it doesn't support sequences.
    if migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        return

    is_postgresql = migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    )

    # On postgresql re-create the old `business_logic_flow` sequence and change the `id`'s default value back
    if is_postgresql:
        old_blf_seq = migration_utils.create_sequence(
            "business_logic_flow_id_seq", suffix=""
        )
        op.alter_column(
            "business_logic_flow", "id", server_default=old_blf_seq.next_value()
        )
    # On postgresql and Oracle drop the newly created sequence
    migration_utils.drop_sequence("blf")

    # On postgresql re-create the old `business_logic_flow_element` sequence and change the `id`'s default value back
    if is_postgresql:
        old_blf_element_seq = migration_utils.create_sequence(
            "business_logic_flow_element_id_seq", suffix=""
        )
        op.alter_column(
            "business_logic_flow_element",
            "id",
            server_default=old_blf_element_seq.next_value(),
        )
    # On postgresql and Oracle drop the newly created sequence
    migration_utils.drop_sequence("blf_element")

    # On postgresql re-create the old `example_conversation` sequence and change the `id`'s default value back
    if is_postgresql:
        old_blf_element_seq = migration_utils.create_sequence(
            "example_conversation_id_seq", suffix=""
        )
        op.alter_column(
            "example_conversation",
            "id",
            server_default=old_blf_element_seq.next_value(),
        )
    # On postgresql and Oracle drop the newly created sequence
    migration_utils.drop_sequence("sc")

    # On postgresql re-create the old `example_conversation_item` sequence and change the `id`'s default value back
    if is_postgresql:
        old_blf_element_seq = migration_utils.create_sequence(
            "example_conversation_item_id_seq", suffix=""
        )
        op.alter_column(
            "example_conversation_item",
            "id",
            server_default=old_blf_element_seq.next_value(),
        )
    # On postgresql and Oracle drop the newly created sequence
    migration_utils.drop_sequence("sc_item")

    # On postgresql re-create the old `example_conversation_item` sequence and change the `id`'s default value back
    if is_postgresql:
        old_blf_element_seq = migration_utils.create_sequence(
            "assistant_link_id_seq", suffix=""
        )
        op.alter_column(
            "assistant_link", "id", server_default=old_blf_element_seq.next_value()
        )
    # On postgresql and Oracle drop the newly created sequence
    migration_utils.drop_sequence("link")
