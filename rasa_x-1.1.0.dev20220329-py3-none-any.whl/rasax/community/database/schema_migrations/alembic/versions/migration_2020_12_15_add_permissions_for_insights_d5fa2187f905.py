"""Add permissions to insights for different user roles.

Reason:
Intent insights feature requires a new set of permissions. Permissions to modify
intent insights are granted only for admins.

Revision ID: d5fa2187f905
Revises: 524fbfe6bac0

"""
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
from rasax.community.services.user_service import TESTER, ANNOTATOR, ADMIN


# revision identifiers, used by Alembic.
revision = "d5fa2187f905"
down_revision = "524fbfe6bac0"
branch_labels = None
depends_on = None


def upgrade():
    """Adds the new permissions."""
    # Everyone can read
    for role in [ADMIN, ANNOTATOR, TESTER]:
        migration_utils.add_new_permission_to(role, "insights.view.*")

    migration_utils.add_new_permission_to(ADMIN, "insights.modify.*")


def downgrade():
    """Removes the permissions."""
    for role in [ADMIN, ANNOTATOR, TESTER]:
        migration_utils.delete_permission_from(role, "insights.view.*")

    migration_utils.delete_permission_from(ADMIN, "insights.modify.*")
