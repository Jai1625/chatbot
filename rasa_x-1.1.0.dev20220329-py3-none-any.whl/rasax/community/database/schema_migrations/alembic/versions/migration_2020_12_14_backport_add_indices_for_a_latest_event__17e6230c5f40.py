"""Add migration for conversations performance fix in 0.31.x and 0.32.x.

Reason:
A performance fix (https://github.com/RasaHQ/rasa-x/pull/3803) for 0.31.x and 0.32.x
required a migration. This migration represents a separate branch in our graph of
migrations. To address this we need a migration to
merge both migration heads. While the migration after this (`e4ed14831f48`) will
perform the merge, this migration runs the outstanding migration for users who did not
use one of the fixed 0.31.x or 0.32.x versions and hence don't have this branch.

Revision ID: 17e6230c5f40
Revises: 43a803b8c1fd
"""
from alembic import op
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
import sqlalchemy as sa

# This is the same revision as 0.31.x and 0.32.x use for the migration which adds
# the indices
revision = "17e6230c5f40"
down_revision = "43a803b8c1fd"
branch_labels = None
depends_on = None

TABLE_NAME = "conversation"
LATEST_EVENT_TIME_ASC_INDEX_NAME = "latest_event_time_idx_asc"
LATEST_EVENT_TIME_DESC_INDEX_NAME = "latest_event_time_idx_desc"


def upgrade() -> None:
    """Runs migration to upgrade to this revision."""
    if not migration_utils.index_exists(TABLE_NAME, LATEST_EVENT_TIME_ASC_INDEX_NAME):
        with op.batch_alter_table(TABLE_NAME) as batch_op:
            batch_op.create_index(
                LATEST_EVENT_TIME_ASC_INDEX_NAME, [sa.text("latest_event_time ASC")]
            )

    if not migration_utils.index_exists(TABLE_NAME, LATEST_EVENT_TIME_DESC_INDEX_NAME):
        with op.batch_alter_table(TABLE_NAME) as batch_op:
            batch_op.create_index(
                LATEST_EVENT_TIME_DESC_INDEX_NAME, [sa.text("latest_event_time DESC")]
            )


def downgrade() -> None:
    """Runs migration to downgrade from this revision."""
    for index_name in [
        LATEST_EVENT_TIME_ASC_INDEX_NAME,
        LATEST_EVENT_TIME_DESC_INDEX_NAME,
    ]:
        if migration_utils.index_exists(index_name, TABLE_NAME):
            with op.batch_alter_table(TABLE_NAME) as batch_op:
                batch_op.drop_index(index_name)
