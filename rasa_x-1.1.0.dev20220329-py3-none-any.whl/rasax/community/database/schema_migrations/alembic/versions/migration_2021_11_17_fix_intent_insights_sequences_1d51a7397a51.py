"""Fix intent insights sequences.

Reason:
Fix missing sequences for Oracle by creating new ones with shorter name and renaming the old sequences in Postgres to match them.

The initial migration for creating the tables didn't create the sequences needed.
It worked in Postgres because it generated the sequences automatically and this isn't the case with Oracle.

More info:
https://github.com/RasaHQ/rasa-x/issues/6795
https://github.com/RasaHQ/rasa-x/pull/6862

Revision ID: 1d51a7397a51
Revises: ac645a4bf8f7

"""
from alembic import op

import rasax.community.database.schema_migrations.alembic.utils as migration_utils

# revision identifiers, used by Alembic.
revision = "1d51a7397a51"
down_revision = "ac645a4bf8f7"
branch_labels = None
depends_on = None

sequences_info = [
    {"table_name": "nlu_insight_report", "new_seq_name": "insight_report"},
    {"table_name": "intent_evaluation_result", "new_seq_name": "ie_result"},
    {"table_name": "intent_insight", "new_seq_name": "intent_insight"},
    {
        "table_name": "intent_insight_configuration",
        "new_seq_name": "intent_insight_conf",
    },
]


def upgrade():
    """Upgrade database."""
    # Skip this migration on SQLite since it doesn't support sequences.
    if migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        return

    is_postgresql = migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    )

    is_oracle = migration_utils.using_dialect(
        migration_utils.ORACLE_DIALECT, op.get_bind()
    )

    for info in sequences_info:
        if is_postgresql:
            op.execute(
                f"ALTER SEQUENCE {info['table_name']}_id_seq RENAME TO {info['new_seq_name']}_seq"
            )

        if is_oracle:
            seq = migration_utils.create_sequence(info["new_seq_name"])
            op.alter_column(info["table_name"], "id", server_default=seq.next_value())


def downgrade():
    """Downgrade database."""
    # Skip this migration on SQLite since it doesn't support sequences.
    if migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        return

    is_postgresql = migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    )

    is_oracle = migration_utils.using_dialect(
        migration_utils.ORACLE_DIALECT, op.get_bind()
    )

    for info in sequences_info:
        if is_postgresql:
            op.execute(
                f"ALTER SEQUENCE {info['new_seq_name']}_seq RENAME TO {info['table_name']}_id_seq"
            )

        if is_oracle:
            migration_utils.drop_sequence(info["new_seq_name"])
