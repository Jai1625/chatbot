"""Add `workspaces.list` permissions to user roles.

Reason:
On a fresh db, TESTER will get a permission to `workspaces.list` via `basic.*` during
the first init. For a non-empty database we need to make sure to add this permission
manually for TESTER and all custom roles. The same applies to all already existing roles.
Also we've missed to do the same for `dataTags.list`.
We also add `drafts.view` to the TESTER, so that they can see the list of drafts in the
workspaces and NLU inbox.



Revision ID: 898d55a5318e
Revises: 017cb274256f

"""
from alembic import op
import sqlalchemy as sa
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
from rasax.community.services.user_service import TESTER, ADMIN, ANNOTATOR

# revision identifiers, used by Alembic.
revision = "898d55a5318e"
down_revision = "017cb274256f"
branch_labels = None
depends_on = None

TABLE_PERMISSION = "permission"
NEW_PERMISSIONS = ["basic.view.workspaces.list", "basic.view.dataTags.list"]


def upgrade():
    """Add new permissions to user roles."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    permission_tbl = migration_utils.get_reflected_table(TABLE_PERMISSION, session)
    roles = session.query(permission_tbl.c.role_id).distinct().all()

    # make sure existing roles have these new permissions in an explicit form.
    for new_permission in NEW_PERMISSIONS:
        for role in roles:
            role = role[0]
            # these two have it via "basic.view.*"
            if role in [ADMIN, ANNOTATOR]:
                continue
            migration_utils.add_new_permission_to(role, new_permission)

    migration_utils.add_new_permission_to(TESTER, "nlu_training_data.view.drafts.list")


def downgrade():
    """Remove new permissions from user roles."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    # It's safe to remove permissions in an explicit form, bacause users who had them
    # prior to `upgrade` got them via "basic.view.*"
    for new_permission in NEW_PERMISSIONS:
        permission_tbl = migration_utils.get_reflected_table(TABLE_PERMISSION, session)
        delete = sa.delete(permission_tbl).where(
            permission_tbl.c.permission == new_permission
        )
        session.execute(delete)

    migration_utils.delete_permission_from(TESTER, "nlu_training_data.view.drafts.list")
