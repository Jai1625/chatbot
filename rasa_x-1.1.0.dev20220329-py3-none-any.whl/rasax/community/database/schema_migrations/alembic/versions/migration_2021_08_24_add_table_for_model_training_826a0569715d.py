"""Add table for model training.

Reason:
In order to make model training async,
we need a new model that stores data regarding training.
This migration creates it.

Revision ID: 826a0569715d
Revises: 898d55a5318e

"""
from alembic import op
import sqlalchemy as sa

from rasax.community.database.model import TrainingStatus


# revision identifiers, used by Alembic.
revision = "826a0569715d"
down_revision = "898d55a5318e"
branch_labels = None
depends_on = None

MODEL_TRAINING_TABLE = "model_training_job"


def upgrade():
    """Creates the table."""
    op.create_table(
        MODEL_TRAINING_TABLE,
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column(
            "status",
            sa.Enum(TrainingStatus),
            nullable=False,
            default=TrainingStatus.IN_PROGRESS,
        ),
        sa.Column("started_at", sa.DateTime(), nullable=False),
        sa.Column("finished_at", sa.DateTime(), nullable=True),
        sa.Column("initiated_by", sa.String(255), nullable=False),
        sa.Column("details", sa.Text(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade():
    """Drops the table."""
    op.drop_table(MODEL_TRAINING_TABLE)
