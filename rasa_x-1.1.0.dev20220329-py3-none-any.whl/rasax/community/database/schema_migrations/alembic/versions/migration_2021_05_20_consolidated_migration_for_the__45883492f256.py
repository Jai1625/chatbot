"""Consolidated migration for the Workspaces.

Reason:
Creates all necessary tables for the Workspaces feature.

Revision ID: 45883492f256
Revises: d9a565cab06c

"""
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
from rasax.community.services.user_service import ADMIN, ANNOTATOR
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "45883492f256"
down_revision = "5ff5fa10d3c0"
branch_labels = None
depends_on = None

WORKSPACE_TABLE = "workspace"
MESSAGE_LOG_TABLE = "message_log"
USER_TABLE = "rasa_x_user"

DEFAULT_WORKSPACE_ID_COL = "default_workspace_id"
WORKSPACE_ID_COL = "workspace_id"

USER_FK_NAME = "fk_user_default_w_id"
DRAFT_FK_NAME = "fk_draft_workspace_id"

CONSTRAINT_NAME = "user_default_w_uq"

MESSAGE_LOG_WORKSPACE_ID_INDEX_NAME = "msg_log_workspace_id_idx"


def upgrade():
    """Perform upgrade of the DB schema."""
    op.create_table(
        WORKSPACE_TABLE,
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )

    if not migration_utils.get_column(USER_TABLE, DEFAULT_WORKSPACE_ID_COL):
        with op.batch_alter_table(USER_TABLE) as batch_op:
            batch_op.add_column(
                sa.Column(DEFAULT_WORKSPACE_ID_COL, sa.Integer(), nullable=True)
            )
            batch_op.create_foreign_key(
                USER_FK_NAME,
                WORKSPACE_TABLE,
                [DEFAULT_WORKSPACE_ID_COL],
                ["id"],
                ondelete="SET NULL",
            )
            batch_op.create_unique_constraint(
                CONSTRAINT_NAME, [DEFAULT_WORKSPACE_ID_COL]
            )

    migration_utils.add_new_permission_to(ANNOTATOR, "workspaces.*")
    migration_utils.add_new_permission_to(ADMIN, "workspaces.*")

    if not migration_utils.get_column(MESSAGE_LOG_TABLE, WORKSPACE_ID_COL):
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.add_column(
                sa.Column(WORKSPACE_ID_COL, sa.Integer(), nullable=True)
            )
            batch_op.create_foreign_key(
                DRAFT_FK_NAME,
                WORKSPACE_TABLE,
                [WORKSPACE_ID_COL],
                ["id"],
                ondelete="SET NULL",
            )
            batch_op.create_index(
                MESSAGE_LOG_WORKSPACE_ID_INDEX_NAME, [WORKSPACE_ID_COL]
            )


def downgrade():
    """Perform downgrade of the DB schema."""
    migration_utils.delete_permission_from(ANNOTATOR, "workspaces.*")
    migration_utils.delete_permission_from(ADMIN, "workspaces.*")

    if migration_utils.get_column(USER_TABLE, DEFAULT_WORKSPACE_ID_COL):
        with op.batch_alter_table(USER_TABLE) as batch_op:
            batch_op.drop_constraint(CONSTRAINT_NAME)
            batch_op.drop_constraint(USER_FK_NAME)
            batch_op.drop_column(DEFAULT_WORKSPACE_ID_COL)

    if migration_utils.get_column(MESSAGE_LOG_TABLE, WORKSPACE_ID_COL):
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.drop_index(MESSAGE_LOG_WORKSPACE_ID_INDEX_NAME)
            batch_op.drop_constraint(DRAFT_FK_NAME)
            batch_op.drop_column(WORKSPACE_ID_COL)

    op.drop_table(WORKSPACE_TABLE)
