"""Make workspace_id index partial.

Reason:
We need the `message_log::workspace_id` index to be partial, so that NULL records
are not included into it. Since for the big datasets we expect most of message logs
not to be assigned to any workspace, it would speed up the lookup.

Revision ID: 30ec36905354
Revises: 45883492f256

"""
from rasax.community.database.schema_migrations.alembic import utils as migration_utils
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = "30ec36905354"
down_revision = "45883492f256"
branch_labels = None
depends_on = None

MESSAGE_LOG_TABLE = "message_log"
INDEX_NAME = "msg_log_workspace_id_idx"
WORKSPACE_ID_FIELD = "workspace_id"


def upgrade():
    """Change the index to be partial."""
    if migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    ) or migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        op.drop_index(INDEX_NAME)
        index_text = f"{WORKSPACE_ID_FIELD} is not NULL"
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.create_index(
                INDEX_NAME,
                [WORKSPACE_ID_FIELD],
                postgresql_where=sa.text(index_text),
                sqlite_where=sa.text(index_text),
            )


def downgrade():
    """Change the index to be non-partial."""
    if migration_utils.using_dialect(
        migration_utils.POSTGRES_DIALECT, op.get_bind()
    ) or migration_utils.using_dialect(migration_utils.SQLITE_DIALECT, op.get_bind()):
        op.drop_index(INDEX_NAME)
        with op.batch_alter_table(MESSAGE_LOG_TABLE) as batch_op:
            batch_op.create_index(
                INDEX_NAME, [WORKSPACE_ID_FIELD],
            )
