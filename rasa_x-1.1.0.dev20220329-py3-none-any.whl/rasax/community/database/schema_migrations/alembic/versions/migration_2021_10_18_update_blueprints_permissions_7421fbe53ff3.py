"""Update Blueprints permissions.

Reason:
We're migrating from `assistant.view` and `assistant.modify` permissions to
* `blueprints.list`
* `blueprints.get`
* `blueprints.create`
* `blueprints.update`
* `blueprints.delete`

Revision ID: 7421fbe53ff3
Revises: b135bb52d0a6
"""
from alembic import op
from sqlalchemy.orm import Session

import rasax.community.database.schema_migrations.alembic.utils as migration_utils

revision = "7421fbe53ff3"
down_revision = "b135bb52d0a6"
branch_labels = None
depends_on = None

PERMISSIONS_UP = {
    "assistant.*": ["blueprints.*"],
    "assistant.view.*": ["blueprints.view.*"],
    "assistant.view.assistant.view": [
        "blueprints.view.blueprints.list",
        "blueprints.view.blueprints.get",
    ],
    "assistant.modify.assistant.modify": [
        "blueprints.modify.blueprints.create",
        "blueprints.modify.blueprints.update",
        "blueprints.modify.blueprints.delete",
    ],
}

PERMISSIONS_DOWN = {
    "blueprints.*": "assistant.*",
    "blueprints.view.*": "assistant.view.*",
    "blueprints.view.blueprints.list": "assistant.view.assistant.view",
    "blueprints.view.blueprints.get": "assistant.view.assistant.view",
    "blueprints.modify.blueprints.create": "assistant.modify.assistant.modify",
    "blueprints.modify.blueprints.update": "assistant.modify.assistant.modify",
    "blueprints.modify.blueprints.delete": "assistant.modify.assistant.modify",
}


def upgrade():
    """Upgrade DB."""
    session = Session(bind=op.get_bind())
    permission_tbl = migration_utils.get_reflected_table("permission", session)

    query = session.query(permission_tbl.c.role_id, permission_tbl.c.permission).filter(
        permission_tbl.c.permission.ilike("assistant.%")
    )
    for (role_id, old_permission) in query:
        for new_permission in PERMISSIONS_UP.get(old_permission, []):
            migration_utils.add_new_permission_to(role_id, new_permission)
        migration_utils.delete_permission_from(role_id, old_permission)


def downgrade():
    """Downgrade DB."""
    session = Session(bind=op.get_bind())
    permission_tbl = migration_utils.get_reflected_table("permission", session)

    query = session.query(permission_tbl.c.role_id, permission_tbl.c.permission).filter(
        permission_tbl.c.permission.ilike("blueprints.%")
    )
    for (role_id, new_permission) in query:
        old_permission = PERMISSIONS_DOWN.get(new_permission)
        if old_permission is None:
            continue

        migration_utils.add_new_permission_to(
            role_id, old_permission, validate_permission=False
        )
        migration_utils.delete_permission_from(role_id, new_permission)
