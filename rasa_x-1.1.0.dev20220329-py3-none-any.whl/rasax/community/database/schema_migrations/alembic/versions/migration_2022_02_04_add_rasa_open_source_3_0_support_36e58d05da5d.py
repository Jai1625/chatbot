"""Add Rasa Open Source 3.0 support.

Reason:
Rasa Open Source 3.0 changes the format of the domain due to the changes related to
how slots are filled. This means that e.g. slot now contains so called `mappings`
which define how and when slot values are filled.

Domain previously:

```yaml
version: "2.0"
entities:
  - cuisine

slots:
  cuisine:
    type: text
    influence_conversation: false
    auto_fill: false

forms:
  restaurant_form:
    required_slots:
      cuisine:
      - type: from_entity
        entity: cuisine
```

Domain in Rasa Open Source 3.0:
```yaml
version: "3.0"
entities:
  - cuisine

slots:
  cuisine:
    type: text
    influence_conversation: false
    mappings:
    - type: from_entity
      entity: cuisine

forms:
  restaurant_form:
    required_slots:
      - cuisine

```

Revision ID: 36e58d05da5d
Revises: cf539355089a

"""
import json

import sqlalchemy as sa
import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "36e58d05da5d"
down_revision = "cf539355089a"
branch_labels = None
depends_on = None


def upgrade():
    migration_utils.drop_column("domain_slot", "auto_fill")
    migration_utils.create_column(
        "domain_slot",
        sa.Column("mappings", sa.Text, nullable=False, server_default=json.dumps([])),
    )


def downgrade():
    migration_utils.create_column(
        "domain_slot", sa.Column("auto_fill", sa.Boolean, default=True)
    )
    migration_utils.drop_column("domain_slot", "mappings")
