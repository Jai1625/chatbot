"""make conversation.latest_input_channel non-nullable

Reason:
    https://rasahq.atlassian.net/browse/IN-25


Revision ID: 0cc19d3de28a
Revises: 36e58d05da5d

"""
import sqlalchemy as sa
from alembic import op
from alembic.op import alter_column
from sqlalchemy.orm import Session

from rasax.community import constants
import rasax.community.database.schema_migrations.alembic.utils as migration_utils

revision = "0cc19d3de28a"
down_revision = "36e58d05da5d"
branch_labels = None
depends_on = None

TABLE_NAME = "conversation"
COLUMN_NAME = "latest_input_channel"


def upgrade():
    session = Session(bind=op.get_bind())
    t_conversation = migration_utils.get_reflected_table(TABLE_NAME, session)
    stmt = (
        sa.update(t_conversation)
        .where(t_conversation.c[COLUMN_NAME].is_(None))
        .values({COLUMN_NAME: constants.DEFAULT_CHANNEL_NAME})
    )
    session.execute(stmt)
    session.commit()

    with op.batch_alter_table(TABLE_NAME) as batch_op:
        batch_op.alter_column(COLUMN_NAME, nullable=False)


def downgrade():
    with op.batch_alter_table(TABLE_NAME) as batch_op:
        batch_op.alter_column(COLUMN_NAME, nullable=True)
