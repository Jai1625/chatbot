"""Add a sequence for workspace table.

Reason:
We need to manually create a sequence for a new table, since Oracle wouldn't do that.

Revision ID: d741ab0a01aa
Revises: 30ec36905354

"""
import rasax.community.database.schema_migrations.alembic.utils as migration_utils

# revision identifiers, used by Alembic.
revision = "d741ab0a01aa"
down_revision = "30ec36905354"
branch_labels = None
depends_on = None

WORKSPACE_TABLE = "workspace"


def upgrade():
    """Add a sequence to the workspace table."""
    migration_utils.create_sequence(WORKSPACE_TABLE)


def downgrade():
    """Drop a sequence from the workspace table."""
    migration_utils.drop_sequence(WORKSPACE_TABLE)
