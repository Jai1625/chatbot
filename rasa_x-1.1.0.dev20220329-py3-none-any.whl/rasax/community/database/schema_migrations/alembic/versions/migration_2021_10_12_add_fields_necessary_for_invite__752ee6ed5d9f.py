"""Add fields necessary for invite mechanism and full name field to User.

Reason:
To allow users to accept an invite code, we need to store that invite code when generated,
as well as keep track of when we want said code to expire. In anticipation of the upcoming
requirement for tracking a full name separately to the username, that field is also included
here.

Revision ID: 752ee6ed5d9f
Revises: d3c2e4c8fd8a

"""
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils

# revision identifiers, used by Alembic.
revision = "752ee6ed5d9f"
down_revision = "d3c2e4c8fd8a"
branch_labels = None
depends_on = None

TABLE_NAME = "rasa_x_user"


def upgrade():
    """Create columns."""
    migration_utils.create_column(
        TABLE_NAME, sa.Column("invite_code", sa.String(255), nullable=True),
    )

    migration_utils.create_column(
        TABLE_NAME, sa.Column("invite_expiry", sa.DateTime(), nullable=True,),
    )

    migration_utils.create_column(
        TABLE_NAME, sa.Column("fullname", sa.String(255), nullable=True,),
    )


def downgrade():
    """Drop columns."""
    for column_name in ["invite_code", "invite_expiry", "fullname"]:
        migration_utils.drop_column(TABLE_NAME, column_name)
