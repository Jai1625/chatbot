"""Add assistant_link table.

Reason:
To store links between business logic flows and sample conversations.

Revision ID: fa85875bdbf0
Revises: 8cefbf552c0f

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = "fa85875bdbf0"
down_revision = "8cefbf552c0f"
branch_labels = None
depends_on = None

TBL_ASSISTANT_LINK = "assistant_link"


def upgrade():
    """Create table."""
    op.create_table(
        TBL_ASSISTANT_LINK,
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("business_logic_flow_id", sa.Integer(), nullable=False),
        sa.Column("example_conversation_id", sa.Integer(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ("business_logic_flow_id",), ["business_logic_flow.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(
            ("example_conversation_id",),
            ["example_conversation.id"],
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint("business_logic_flow_id", "example_conversation_id"),
    )


def downgrade():
    """Drop table."""
    op.drop_table(TBL_ASSISTANT_LINK)
