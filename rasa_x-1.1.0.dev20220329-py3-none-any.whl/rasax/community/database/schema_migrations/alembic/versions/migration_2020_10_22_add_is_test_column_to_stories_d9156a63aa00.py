"""Add is_test column to stories

Reason:
Starting from 0.33.0, we will be storing test stories in the `story` table. To
differentiate between regular stories and training ones, we need an additional
boolean column.

Revision ID: d9156a63aa00
Revises: 9b0753451554

"""
import sqlalchemy as sa
import rasax.community.database.schema_migrations.alembic.utils as migration_utils

# revision identifiers, used by Alembic.
revision = "d9156a63aa00"
down_revision = "9b0753451554"
branch_labels = None
depends_on = None

TABLE = "story"
COLUMN = "is_test"


def upgrade():
    if not migration_utils.get_column(TABLE, COLUMN):
        migration_utils.create_column(
            TABLE, sa.Column(COLUMN, sa.Boolean(), default=False)
        )


def downgrade():
    if migration_utils.get_column(TABLE, COLUMN):
        migration_utils.drop_column(TABLE, COLUMN)
