"""Add demo columns to Blueprints tables.

Reason:
We need to keep track whether a `BusinessLogicFlow`,
`SampleConversation`, or `AssistantLink` is an automatically
created demo object.

Revision ID: 66bc70f1b560
Revises: aa5425a6efca

"""
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "66bc70f1b560"
down_revision = "aa5425a6efca"
branch_labels = None
depends_on = None

TBL_BUSINESS_LOGIC_FLOW = "business_logic_flow"
TBL_EXAMPLE_CONVERSATION = "example_conversation"
TBL_ASSISTANT_LINK = "assistant_link"

COL_IS_DEMO = "is_demo"
COL_DEMO_VERSION = "demo_version"


def upgrade():
    """Upgrade database."""
    is_demo_args = {"nullable": False, "server_default": sa.sql.expression.false()}
    demo_version_args = {"nullable": True}

    migration_utils.create_column(
        TBL_BUSINESS_LOGIC_FLOW, sa.Column(COL_IS_DEMO, sa.Boolean, **is_demo_args)
    )
    migration_utils.create_column(
        TBL_BUSINESS_LOGIC_FLOW,
        sa.Column(COL_DEMO_VERSION, sa.Integer, **demo_version_args),
    )

    migration_utils.create_column(
        TBL_EXAMPLE_CONVERSATION, sa.Column(COL_IS_DEMO, sa.Boolean, **is_demo_args)
    )
    migration_utils.create_column(
        TBL_EXAMPLE_CONVERSATION,
        sa.Column(COL_DEMO_VERSION, sa.Integer, **demo_version_args),
    )

    migration_utils.create_column(
        TBL_ASSISTANT_LINK, sa.Column(COL_IS_DEMO, sa.Boolean, **is_demo_args)
    )
    migration_utils.create_column(
        TBL_ASSISTANT_LINK, sa.Column(COL_DEMO_VERSION, sa.Integer, **demo_version_args)
    )


def downgrade():
    """Downgrade database."""
    migration_utils.drop_column(TBL_BUSINESS_LOGIC_FLOW, COL_IS_DEMO)
    migration_utils.drop_column(TBL_BUSINESS_LOGIC_FLOW, COL_DEMO_VERSION)

    migration_utils.drop_column(TBL_EXAMPLE_CONVERSATION, COL_IS_DEMO)
    migration_utils.drop_column(TBL_EXAMPLE_CONVERSATION, COL_DEMO_VERSION)

    migration_utils.drop_column(TBL_ASSISTANT_LINK, COL_IS_DEMO)
    migration_utils.drop_column(TBL_ASSISTANT_LINK, COL_DEMO_VERSION)
