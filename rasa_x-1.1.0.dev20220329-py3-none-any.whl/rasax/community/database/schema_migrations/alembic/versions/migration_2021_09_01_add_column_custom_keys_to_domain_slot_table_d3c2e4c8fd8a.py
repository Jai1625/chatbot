"""Add column 'custom_keys' to domain_slot table.

Reason:
The `slot` table receives an additional column `custom_keys` to store any custom keys used in a custom slot.

Revision ID: d3c2e4c8fd8a
Revises: 7421fbe53ff3

"""
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils

# revision identifiers, used by Alembic.
revision = "d3c2e4c8fd8a"
down_revision = "7421fbe53ff3"
branch_labels = None
depends_on = None


TABLE_NAME = "domain_slot"
COLUMN_TO_ADD = "custom_keys"


def upgrade():
    """Creates the column."""
    migration_utils.create_column(
        TABLE_NAME, sa.Column(COLUMN_TO_ADD, sa.Text(), nullable=True)
    )


def downgrade():
    """Drops the column."""
    migration_utils.drop_column(TABLE_NAME, COLUMN_TO_ADD)
