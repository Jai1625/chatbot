"""Drop LocalPassword table.

Reason:
As part of the Rasa X and Enterprise images unification, we removed the need for
the `password` table, as the information it stored was redundant.

Revision ID: 41c0fb561081
Revises: fd5123586aee

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "41c0fb561081"
down_revision = "652500998f3e"
branch_labels = None
depends_on = None


def upgrade():
    """Performs the schema upgrade."""
    op.drop_table("password")


def downgrade():
    """Performs the schema downgrade."""
    op.create_table(
        "password",
        sa.Column("password", sa.String(255), nullable=False),
        sa.PrimaryKeyConstraint("password"),
    )
