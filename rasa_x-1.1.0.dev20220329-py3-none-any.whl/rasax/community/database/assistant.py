import json
from typing import Any, Text, Dict, Union, List

import sqlalchemy as sa
from rasax.community.database import utils

from rasax.community.database.base import Base, Timestamps
from sqlalchemy.orm import relationship, validates

FLOW_ELEMENT_TYPES = [
    "node",
    "edge",
]
SAMPLE_CONVERSATION_ITEM_TYPES = [
    "user_message",
    "bot_message",
]


class BusinessLogicFlow(Base, Timestamps):
    """Represents a Business Logic Flow of the assistant."""

    __tablename__ = "business_logic_flow"

    id = sa.Column(sa.Integer, utils.create_sequence("blf"), primary_key=True)
    name = sa.Column(sa.String, nullable=False, unique=True)
    description = sa.Column(sa.Text)
    is_demo = sa.Column(
        sa.Boolean,
        nullable=False,
        server_default=sa.sql.expression.false(),
        default=False,
    )
    demo_version = sa.Column(sa.Integer)
    elements = relationship(
        "BusinessLogicFlowElement", cascade="all, delete-orphan", back_populates="flow"
    )
    links = relationship(
        "AssistantLink", cascade="all, delete-orphan", back_populates="flow"
    )

    @validates("name")
    def validate_not_empty(self, key: Text, value: Any) -> Any:
        """Validate that columns have a value.

        If the column contains string values, ensure that it's not an empty string.
        """
        if value is None or value == "":
            raise ValueError(f"empty {key} is invalid")
        return value

    def as_dict(
        self, include_elements: bool = False
    ) -> Dict[Text, Union[Text, List[Dict[Text, Any]]]]:
        """Converts the class into a dict."""
        flow = {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "created_at": self.created_at.timestamp(),
            "updated_at": self.updated_at.timestamp(),
            "is_demo": self.is_demo,
        }

        if include_elements:
            flow["elements"] = [json.loads(e.data) for e in self.elements]

        return flow


class BusinessLogicFlowElement(Base, Timestamps):
    """Represents a Business Logic Flow Element of the assistant."""

    __tablename__ = "business_logic_flow_element"

    id = sa.Column(sa.Integer, utils.create_sequence("blf_element"), primary_key=True)
    type = sa.Column(sa.String, nullable=False)
    element_id = sa.Column(sa.String, nullable=False)
    data = sa.Column(sa.Text, nullable=False)
    business_logic_flow_id = sa.Column(
        sa.Integer, sa.ForeignKey("business_logic_flow.id")
    )
    flow = relationship("BusinessLogicFlow", back_populates="elements")

    @validates("element_id")
    def validate_not_empty_element_id(self, _: Text, value: Text) -> Text:
        """Validate that element_id is not missing or an empty string."""
        if value is None or value == "":
            raise ValueError("empty element id is invalid")
        return value

    @validates("type")
    def validate_type(self, _: Text, value: Text) -> Text:
        """Validate that the type only consists of valid values."""
        if value not in FLOW_ELEMENT_TYPES:
            raise ValueError("invalid element_type value")
        return value

    def update_with_data(self, new_data: Dict[Text, Any]):
        """Extract values from new data and assign to fields.

        Args:
            new_data: Dictionary for values and which is assigned to `data`.
        """
        self.type = new_data.get("data").get("element_type")
        self.element_id = new_data.get("id")
        self.data = json.dumps(new_data)


class SampleConversation(Base, Timestamps):
    """Represents a Sample Conversation of the assistant."""

    __tablename__ = "example_conversation"

    id = sa.Column(sa.Integer, utils.create_sequence("sc"), primary_key=True)
    name = sa.Column(sa.String, nullable=False, unique=True)
    description = sa.Column(sa.Text)
    is_demo = sa.Column(
        sa.Boolean,
        nullable=False,
        server_default=sa.sql.expression.false(),
        default=False,
    )
    demo_version = sa.Column(sa.Integer)
    items = relationship(
        "SampleConversationItem",
        cascade="all, delete-orphan",
        back_populates="conversation",
        order_by=lambda: SampleConversationItem.order.asc(),
    )
    links = relationship(
        "AssistantLink", cascade="all, delete-orphan", back_populates="conversation"
    )

    @validates("name")
    def validate_not_empty(self, key: Text, value: Any) -> Any:
        """Validate that columns have a value.

        If the column contains string values, ensure that it's not an empty string.
        """
        if value is None or value == "":
            raise ValueError(f"empty {key} is invalid")
        return value

    def as_dict(self, include_items: bool = False) -> Dict[Text, Text]:
        """Converts the class into a dict."""
        conversation = {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "created_at": self.created_at.timestamp(),
            "updated_at": self.updated_at.timestamp(),
            "is_demo": self.is_demo,
        }

        if include_items:
            conversation["items"] = [item.as_dict() for item in self.items]

        return conversation


class SampleConversationItem(Base, Timestamps):
    """Represents a Sample Conversation Item of the assistant."""

    __tablename__ = "example_conversation_item"

    id = sa.Column(sa.Integer, utils.create_sequence("sc_item"), primary_key=True)
    type = sa.Column(sa.String, nullable=False)
    text = sa.Column(sa.Text, nullable=False)
    example_conversation_id = sa.Column(
        sa.Integer, sa.ForeignKey("example_conversation.id")
    )
    order = sa.Column(sa.Integer, nullable=False, server_default="0")
    conversation = relationship("SampleConversation", back_populates="items")

    @validates("text")
    def validate_not_empty(self, key: Text, value: Any) -> Any:
        """Validates that columns have a value.

        If the column contains string values, ensure that it's not an empty string.
        """
        if value is None or value == "":
            raise ValueError(f"empty {key} is invalid")
        return value

    @validates("type")
    def validate_type(self, _: Text, value: Text) -> Text:
        """Validates the given type is supported."""
        if value not in SAMPLE_CONVERSATION_ITEM_TYPES:
            raise ValueError("type is unsupported")
        return value

    def as_dict(self) -> Dict[Text, Text]:
        """Converts the class into a dict."""
        return {
            "id": self.id,
            "type": self.type,
            "text": self.text,
            "order": self.order,
            "created_at": self.created_at.timestamp(),
            "updated_at": self.updated_at.timestamp(),
        }


class AssistantLink(Base, Timestamps):
    """Represents an assistant link between a business logic flow and a sample conversation."""

    __tablename__ = "assistant_link"

    id = sa.Column(sa.Integer, utils.create_sequence("link"), primary_key=True)
    business_logic_flow_id = sa.Column(
        sa.Integer, sa.ForeignKey("business_logic_flow.id")
    )
    example_conversation_id = sa.Column(
        sa.Integer, sa.ForeignKey("example_conversation.id")
    )
    is_demo = sa.Column(
        sa.Boolean,
        nullable=False,
        server_default=sa.sql.expression.false(),
        default=False,
    )
    demo_version = sa.Column(sa.Integer)
    flow = relationship("BusinessLogicFlow", back_populates="links")
    conversation = relationship("SampleConversation", back_populates="links")

    def as_dict(self, embed_linked_objects: bool = False) -> Dict[Text, Any]:
        """Converts the class into a dict.

        Args:
            embed_linked_objects: Whether to embed linked objects. Renders their ids when `False`.
        """
        link = {
            "id": self.id,
            "created_at": self.created_at.timestamp(),
            "updated_at": self.updated_at.timestamp(),
            "is_demo": self.is_demo,
        }

        if embed_linked_objects:
            link["business_logic_flow"] = self.flow.as_dict(include_elements=False)
            link["sample_conversation"] = self.conversation.as_dict(include_items=False)
        else:
            link["business_logic_flow_id"] = self.business_logic_flow_id
            link["sample_conversation_id"] = self.example_conversation_id

        return link
