from datetime import datetime

from sqlalchemy.ext.declarative import declarative_base, DeclarativeMeta
import sqlalchemy as sa

Base: DeclarativeMeta = declarative_base()


class Timestamps:
    """Mixin class for timestamps.

    This will make handling `created_at` and `updated_at` timestamp columns
    easier when we use them on multiple database models.
    """

    created_at = sa.Column(sa.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = sa.Column(
        sa.DateTime, default=datetime.utcnow, nullable=False, onupdate=datetime.utcnow
    )
