# this file imports all SQL tables at module level - this avoids
# reference to non-existing tables in SQL relations

# noinspection PyUnresolvedReferences
from rasax.community.database.admin import (  # noqa: F401
    Project,
    User,
    PlatformFeature,
    Role,
    Environment,
    Permission,
    ChatToken,
    SingleUseToken,
    ConfigValue,
    GitRepository,
)

# noinspection PyUnresolvedReferences
from rasax.community.database.conversation import (  # noqa: F401
    Conversation,
    ConversationActionMetadata,
    ConversationEntityMetadata,
    ConversationEvent,
    ConversationIntentMetadata,
    ConversationMessageCorrection,
    ConversationPolicyMetadata,
    MessageLog,
    MessageLogEntityMetadata,
)

# noinspection PyUnresolvedReferences
from rasax.community.database.analytics import (  # noqa: F401
    ConversationActionStatistic,
    ConversationEntityStatistic,
    ConversationIntentStatistic,
    ConversationSlotNameStatistic,
    ConversationChannelStatistic,
    ConversationPolicyStatistic,
    ConversationStatistic,
    ConversationSession,
    AnalyticsCache,
)

# noinspection PyUnresolvedReferences
from rasax.community.database.data import (  # noqa: F401
    TrainingData,
    Response,
    Story,
    EntitySynonymValue,
    EntitySynonym,
)

# noinspection PyUnresolvedReferences
from rasax.community.database.domain import (  # noqa: F401
    Domain,
    DomainAction,
    DomainEntity,
    DomainIntent,
    DomainSlot,
)

# noinspection PyUnresolvedReferences
from rasax.community.database.intent import (  # noqa: F401
    Intent,
    TemporaryIntentExample,
)

# noinspection PyUnresolvedReferences
from rasax.community.database.insights import (  # noqa: F401
    NLUInsightReport,
    IntentEvaluationResult,
    IntentInsight,
)

# noinspection PyUnresolvedReferences
from rasax.community.database.model import (  # noqa: F401
    Model,
    ModelTag,
    NluEvaluation,
    NluEvaluationPrediction,
    ModelTrainingJob,
)

# noinspection PyUnresolvedReferences
from rasax.community.database.assistant import (  # noqa: F401
    BusinessLogicFlow,
    BusinessLogicFlowElement,
    SampleConversation,
    SampleConversationItem,
    AssistantLink,
)
