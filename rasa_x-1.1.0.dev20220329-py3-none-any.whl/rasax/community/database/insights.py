import json
from enum import Enum

import sqlalchemy as sa
from typing import Any, List, Optional, Text, Dict, Union
from sqlalchemy.orm import relationship

from rasax.community.database.base import Base
from rasax.community.database import utils


class ReportStatus(Enum):
    """Status of the insight calculation."""

    IN_PROGRESS = 0
    SUCCESS = 1
    FAILURE = 2


class NLUInsightReport(Base):
    """Stores NLU insights report."""

    __tablename__ = "nlu_insight_report"

    id = sa.Column(
        sa.Integer, utils.create_sequence("insight_report"), primary_key=True
    )
    started_at = sa.Column(sa.DateTime)
    finished_at = sa.Column(sa.DateTime)
    evaluation_payload = sa.Column(sa.Text)
    status = sa.Column(sa.Enum(ReportStatus), default=ReportStatus.IN_PROGRESS)

    intent_evaluation_results = relationship(
        "IntentEvaluationResult", cascade="all", back_populates="nlu_insight_report",
    )

    def as_dict(
        self, with_intent_evaluation_results: bool = True
    ) -> Dict[Text, Union[Text, int, Dict[Text, Any]]]:
        """Converts the class into a dict."""
        result = {
            "id": self.id,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "status": self.status.name.lower(),
        }
        if with_intent_evaluation_results:
            result["intent_evaluation_results"] = [
                r.as_dict() for r in self.intent_evaluation_results
            ]
        return result


class IntentEvaluationResult(Base):
    """Stores the results of an intent's evaluation and the insights for that intent."""

    __tablename__ = "intent_evaluation_result"

    id = sa.Column(sa.Integer, utils.create_sequence("ie_result"), primary_key=True)
    nlu_insight_report_id = sa.Column(
        sa.Integer, sa.ForeignKey("nlu_insight_report.id")
    )
    nlu_insight_report = relationship(
        "NLUInsightReport", back_populates="intent_evaluation_results"
    )
    intent_name = sa.Column(sa.String)
    f1_score = sa.Column(sa.Float)
    precision = sa.Column(sa.Float)
    recall = sa.Column(sa.Float)
    number_of_training_examples = sa.Column(sa.Integer, default=0)
    intent_insights = relationship(
        "IntentInsight", cascade="all", back_populates="intent_evaluation_result"
    )

    def as_dict(self) -> Dict[Text, Union[int, float, List[Dict[Text, Any]]]]:
        """Converts the class into a dict."""
        return {
            "intent_name": self.intent_name,
            "f1_score": self.f1_score,
            "precision": self.precision,
            "recall": self.recall,
            "number_of_training_examples": self.number_of_training_examples,
            "intent_insights": [i.as_dict() for i in self.intent_insights],
        }


class IntentInsight(Base):
    """Stores a single intent insights for one intent."""

    __tablename__ = "intent_insight"

    id = sa.Column(
        sa.Integer, utils.create_sequence("intent_insight"), primary_key=True
    )
    intent_evaluation_result_id = sa.Column(
        sa.Integer, sa.ForeignKey("intent_evaluation_result.id")
    )
    intent_evaluation_result = relationship(
        "IntentEvaluationResult", back_populates="intent_insights"
    )
    source = sa.Column(sa.String)
    details = sa.Column(sa.Text)

    def as_dict(self) -> Dict[Text, Optional[Union[Text, int, Dict[Text, Any]]]]:
        """Converts the class into a dict."""
        return {
            "source": self.source,
            "details": json.loads(self.details) if self.details else None,
        }


class IntentInsightConfiguration(Base):
    """Stores the configuration for calculation NLU insights."""

    __tablename__ = "intent_insight_configuration"

    id = sa.Column(
        sa.Integer, utils.create_sequence("intent_insight_conf"), primary_key=True
    )
    schedule = sa.Column(sa.String)
    cross_validation_folds = sa.Column(sa.Integer)
    calculator_configuration = sa.Column(sa.Text)
