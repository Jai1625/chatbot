import json
from typing import Dict, Any, Text, Set, Union, List, Type

import sqlalchemy as sa
from sqlalchemy import and_
from sqlalchemy.orm import object_session, relationship

import rasax.community.constants as constants
from rasax.community.database import utils
from rasax.community.database.base import Base
from rasax.community.database.data import is_trainable_extractor


class Conversation(Base):
    """Stores the user's conversation and its metadata."""

    __tablename__ = "conversation"

    sender_id = sa.Column(sa.String, primary_key=True)
    number_user_messages = sa.Column(sa.Integer, default=0)
    latest_input_channel = sa.Column(sa.String, nullable=False)
    latest_event_time = sa.Column(sa.Float)  # latest event time as unix timestamp
    in_training_data = sa.Column(sa.Boolean, default=True)
    review_status = sa.Column(
        sa.String, default=constants.CONVERSATION_STATUS_UNREAD, nullable=False
    )

    minimum_action_confidence = sa.Column(sa.Float)
    maximum_action_confidence = sa.Column(sa.Float)
    minimum_intent_confidence = sa.Column(sa.Float)
    maximum_intent_confidence = sa.Column(sa.Float)

    evaluation = sa.Column(sa.Text)
    interactive = sa.Column(sa.Boolean, default=False)
    created_by = sa.Column(sa.String, nullable=True, index=True)

    message_logs = relationship(
        "MessageLog",
        back_populates="conversation",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    events = relationship(
        "ConversationEvent",
        cascade="all, delete-orphan",
        back_populates="conversation",
        passive_deletes=True,
        order_by=lambda: ConversationEvent.timestamp.asc(),
    )

    unique_policies = relationship(
        "ConversationPolicyMetadata",
        cascade="all, delete-orphan",
        passive_deletes=True,
        back_populates="conversation",
    )
    unique_actions = relationship(
        "ConversationActionMetadata",
        cascade="all, delete-orphan",
        passive_deletes=True,
        back_populates="conversation",
    )
    unique_intents = relationship(
        "ConversationIntentMetadata",
        cascade="all, delete-orphan",
        passive_deletes=True,
        back_populates="conversation",
    )
    unique_entities = relationship(
        "ConversationEntityMetadata",
        cascade="all, delete-orphan",
        passive_deletes=True,
        back_populates="conversation",
    )

    corrected_messages = relationship(
        "ConversationMessageCorrection",
        cascade="all, delete-orphan",
        passive_deletes=True,
        back_populates="conversation",
    )

    tags = relationship(
        "DataTag",
        secondary="conversation_to_tag_mapping",
        backref="conversations",
        passive_deletes=True,
    )

    sessions = relationship(
        "ConversationSession", cascade="all, delete-orphan", passive_deletes=True,
    )

    def _tags_set(self) -> Set[int]:
        return {t.id for t in self.tags}

    @property
    def has_flagged_messages(self) -> bool:
        """Check if the Conversation has flagged messages."""
        result = (
            object_session(self)
            .query(Conversation)
            .filter(
                and_(
                    Conversation.events.any(
                        and_(
                            ConversationEvent.conversation_id == self.sender_id,
                            ConversationEvent.is_flagged,
                        )
                    )
                )
            )
            .first()
        )
        return result is not None

    def as_dict(self) -> Dict[Text, Any]:
        """Return the Conversation as dictionary."""
        from rasax.community.services.event_service import EventService

        result = {
            "sender_id": self.sender_id,
            "sender_name": EventService.get_sender_name(self),  # displayed in the UI
            "latest_event_time": self.latest_event_time,
            "latest_input_channel": self.latest_input_channel,
            "intents": [i.intent for i in self.unique_intents],
            "actions": [a.action for a in self.unique_actions],
            "minimum_action_confidence": self.minimum_action_confidence,
            "maximum_action_confidence": self.maximum_action_confidence,
            "minimum_intent_confidence": self.minimum_intent_confidence,
            "maximum_intent_confidence": self.maximum_intent_confidence,
            "in_training_data": self.in_training_data,
            "review_status": self.review_status,
            "policies": [p.policy for p in self.unique_policies],
            "n_user_messages": self.number_user_messages,
            "has_flagged_messages": self.has_flagged_messages,
            "corrected_messages": [
                {"message_timestamp": c.message_timestamp, "intent": c.intent}
                for c in self.corrected_messages
            ],
            "interactive": self.interactive,
            "tags": list(self._tags_set()),
            "created_by": self.created_by,
        }

        return result


class DataTag(Base):
    """Stores data tags for conversations, messages (and more in the future)."""

    __tablename__ = "data_tag"

    id = sa.Column(sa.Integer, utils.create_sequence(__tablename__), primary_key=True)
    value = sa.Column(sa.String, nullable=False, index=True)
    color = sa.Column(sa.String, nullable=False)

    def as_dict(self) -> Dict[Text, Union[Text, int, List[Text]]]:
        """Return a JSON-like representation of this `DataTag` object.

        Returns:
            `DataTag` represented using a dictionary.
        """
        return {
            "id": self.id,
            "value": self.value,
            "color": self.color,
        }


# Stores mapping between conversation and data tag
conversation_to_tag_mapping = sa.Table(
    "conversation_to_tag_mapping",
    Base.metadata,
    sa.Column(
        "conversation_id",
        sa.String,
        sa.ForeignKey("conversation.sender_id"),
        nullable=False,
        index=True,
    ),
    sa.Column(
        "data_tag_id",
        sa.Integer,
        utils.create_sequence("conversation_to_tag_mapping"),
        sa.ForeignKey("data_tag.id"),
        nullable=False,
        index=True,
    ),
)


# Stores mapping between MessageLog and data tag
message_log_to_tag_mapping = sa.Table(
    "message_log_to_tag_mapping",
    Base.metadata,
    sa.Column(
        "message_log_id",
        sa.Integer,
        sa.ForeignKey("message_log.id"),
        nullable=False,
        index=True,
    ),
    sa.Column(
        "data_tag_id",
        sa.Integer,
        utils.create_sequence("message_log_to_tag_mapping"),
        sa.ForeignKey("data_tag.id"),
        nullable=False,
        index=True,
    ),
)


class ConversationEvent(Base):
    """Stores a single event which happened during a conversation."""

    __tablename__ = "conversation_event"

    id = sa.Column(sa.Integer, utils.create_sequence(__tablename__), primary_key=True)
    conversation_id = sa.Column(
        sa.String, sa.ForeignKey("conversation.sender_id"), index=True, nullable=False
    )
    conversation = relationship("Conversation", back_populates="events")

    type_name = sa.Column(sa.String, nullable=False)
    timestamp = sa.Column(
        sa.Float, index=True, nullable=False
    )  # time of the event as unix timestamp
    intent_name = sa.Column(sa.String)
    action_name = sa.Column(sa.String)
    slot_name = sa.Column(sa.String)
    slot_value = sa.Column(sa.Text)
    policy = sa.Column(sa.String)
    is_flagged = sa.Column(sa.Boolean, default=False, nullable=False)
    data = sa.Column(sa.Text)
    message_log = relationship(
        "MessageLog",
        back_populates="event",
        cascade="all, delete-orphan",
        uselist=False,
    )
    evaluation = sa.Column(sa.Text)
    rasa_environment = sa.Column(sa.String, default=constants.DEFAULT_RASA_ENVIRONMENT)

    @staticmethod
    def from_dict(event: Dict) -> Type["ConversationEvent"]:
        return ConversationEvent(
            conversation_id=event.get("sender_id"),
            type_name=event.get("event"),
            timestamp=event.get("timestamp"),
            intent_name=event.get("parse_data", {}).get("intent", {}).get("name"),
            action_name=event.get("name"),
            data=json.dumps(event),
            policy=event.get("policy"),
        )

    @property
    def data_dict(self) -> Dict:
        """Return the data json string, decoded."""
        return json.loads(self.data)

    def as_rasa_dict(self) -> Dict[Text, Any]:
        """Return a JSON-like representation of the internal Rasa (framework)
        event referenced by this `ConversationEvent`. Attach some information
        specific to Rasa X as part of the Rasa event metadata.
        Returns:
            A JSON-like representation of the Rasa event referenced by this
                database entity.
        """
        d = json.loads(self.data)

        # Add some metadata specific to Rasa X (namespaced with "rasa_x_")
        metadata = d.get("metadata", {})
        metadata.update({"rasa_x_flagged": self.is_flagged, "rasa_x_id": self.id})
        d["metadata"] = metadata

        return d


class MessageLog(Base):
    """Stores the intent classification results of the user messages.

    Indexed columns:
    - `id` (Revision: `2a216ed121dd`)
    - `hash` (Revision: `af3596f6982f`)
    - `(archived, in_training_data)` (Revision: `af3596f6982f`)
    - `conversation_id` (Revision: `0733e149c4f1`)
    - `event_id` (Revision: `0733e149c4f1`)
    - `in_training_data` (Revision: `652500998f3e`)
    """

    __tablename__ = "message_log"

    id = sa.Column(sa.Integer, utils.create_sequence(__tablename__), primary_key=True)
    hash = sa.Column(sa.String, index=True)
    model = sa.Column(sa.String)
    archived = sa.Column(sa.Boolean, default=False)
    time = sa.Column(sa.Float)  # time of the log as unix timestamp
    text = sa.Column(sa.Text)
    intent = sa.Column(sa.String)
    confidence = sa.Column(sa.Float)
    intent_ranking = sa.Column(sa.Text)
    entities = sa.Column(sa.Text)
    in_training_data = sa.Column(sa.Boolean, default=False)

    event_id = sa.Column(sa.Integer, sa.ForeignKey("conversation_event.id"))
    event = relationship(
        "ConversationEvent", uselist=False, back_populates="message_log"
    )

    tags = relationship(
        "DataTag", secondary="message_log_to_tag_mapping", backref="message_logs",
    )

    conversation_id = sa.Column(sa.String, sa.ForeignKey("conversation.sender_id"))
    conversation = relationship("Conversation", back_populates="message_logs")

    unique_entities = relationship(
        "MessageLogEntityMetadata",
        cascade="all, delete-orphan",
        back_populates="message_log",
    )

    def _tags_set(self) -> Set[int]:
        return {t.id for t in self.tags}

    def _entities_list(self) -> List[Dict[Text, Any]]:
        entity_dicts = json.loads(self.entities)
        for entity_dict in entity_dicts:
            entity_dict["trainable"] = is_trainable_extractor(
                entity_dict.get("extractor")
            )

        return entity_dicts

    def as_dict(self, include_tags_set: bool = True) -> Dict[Text, Any]:
        """Returns a Dict representations of the `MessageLog`.

        Args:
            include_tags_set: Whether to include the `MessageLog`'s data tags in the
                result.

        Returns:
            `MessageLog` represented using a dictionary.
        """
        result = {
            "id": self.id,
            "time": self.time,
            "model": self.model,
            "hash": self.hash,
            "conversation_id": self.conversation_id,
            "event_id": self.event_id,
            "user_input": {
                "text": self.text,
                "intent": {"name": self.intent, "confidence": self.confidence},
                "intent_ranking": json.loads(self.intent_ranking),
                "entities": self._entities_list(),
            },
        }

        if include_tags_set:
            result["tags"] = list(self._tags_set())

        return result


class MessageLogEntityMetadata(Base):
    """Stores the distinct set of used entities in a message log."""

    __tablename__ = "message_log_entity_metadata"

    message_log_id = sa.Column(
        sa.Integer, sa.ForeignKey("message_log.id"), primary_key=True
    )

    entity = sa.Column(sa.String, primary_key=True)
    message_log = relationship("MessageLog", back_populates="unique_entities")


class ConversationPolicyMetadata(Base):
    """Stores the distinct set of used policies in a conversation."""

    __tablename__ = "conversation_policy_metadata"

    conversation_id = sa.Column(
        sa.String, sa.ForeignKey("conversation.sender_id"), primary_key=True
    )
    policy = sa.Column(sa.String, primary_key=True)
    conversation = relationship("Conversation", back_populates="unique_policies")


class ConversationActionMetadata(Base):
    """Stores the distinct set of used actions in a conversation."""

    __tablename__ = "conversation_action_metadata"

    conversation_id = sa.Column(
        sa.String, sa.ForeignKey("conversation.sender_id"), primary_key=True
    )
    action = sa.Column(sa.String, primary_key=True)
    conversation = relationship("Conversation", back_populates="unique_actions")


class ConversationIntentMetadata(Base):
    """Stores the distinct set of used intents in a conversation."""

    __tablename__ = "conversation_intent_metadata"

    conversation_id = sa.Column(
        sa.String, sa.ForeignKey("conversation.sender_id"), primary_key=True
    )

    intent = sa.Column(sa.String, primary_key=True)
    conversation = relationship("Conversation", back_populates="unique_intents")


class ConversationEntityMetadata(Base):
    """Stores the distinct set of used entities in a conversation."""

    __tablename__ = "conversation_entity_metadata"

    conversation_id = sa.Column(
        sa.String, sa.ForeignKey("conversation.sender_id"), primary_key=True
    )

    entity = sa.Column(sa.String, primary_key=True)
    conversation = relationship("Conversation", back_populates="unique_entities")


class ConversationMessageCorrection(Base):
    """Stores post hoc corrections of intents in a conversation."""

    __tablename__ = "message_correction"

    conversation_id = sa.Column(
        sa.String, sa.ForeignKey("conversation.sender_id"), primary_key=True
    )

    # time of the message correction as unix timestamp
    message_timestamp = sa.Column(sa.Float, primary_key=True)
    intent = sa.Column(sa.String)
    conversation = relationship("Conversation", back_populates="corrected_messages")
