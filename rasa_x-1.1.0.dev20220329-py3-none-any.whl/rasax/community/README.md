### Legacy Module

**Reference Version:** Rasa 3.0.6 (Commit hash: `778f4ce3f97`)
**Status:** Deprecated
**Removal Date:** June 2022

Description:

Module is a copy of previously used `rasa.shared` module inside Rasa OSS. The module is currently deprecated.

All previous references to `rasa.shared` should now point to `rasax.community.legacy`. New references to the module should be avoided, and changes to behaviour preferably done as part of an *Enterprise* specific module.
