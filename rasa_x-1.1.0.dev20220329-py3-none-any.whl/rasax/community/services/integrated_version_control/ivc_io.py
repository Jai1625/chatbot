import dataclasses
import json
import os
import re
from enum import Enum
from typing import Text, Optional, Set
from pathlib import Path

import rasax.community.data
from rasax.community.data import FileFormat, ProjectDataVersionError
import rasax.community.utils.io as io_utils
import rasax.community.legacy.data
import rasax.community.legacy.utils.io
import rasax.community.config as rasa_x_config
import rasax.community.utils.yaml as yaml_utils
from rasax.community.utils.io import DEFAULT_ENCODING
from rasax.community.legacy.core.training_data.story_reader.yaml_story_reader import (
    YAMLStoryReader,
)

from rasax.community.services.integrated_version_control.exceptions import (
    IncompatibleProjectError,
    IncompatibleYAMLDataError,
    IncompatibleMarkdownDataError,
    IncompatibleNLUJSONDataError,
)


@dataclasses.dataclass
class ProjectFiles:
    domain: Text
    configuration: Text
    data_dir: Text
    test_stories_dir: Text
    stories: Set[Text] = dataclasses.field(default_factory=lambda: set())
    test_stories: Set[Text] = dataclasses.field(default_factory=lambda: set())
    nlu: Set[Text] = dataclasses.field(default_factory=lambda: set())
    incompatible_yaml_files: Set[Text] = dataclasses.field(
        default_factory=lambda: set()
    )
    incompatible_nlu_json_files: Set[Text] = dataclasses.field(
        default_factory=lambda: set()
    )
    incompatible_md_files: Set[Text] = dataclasses.field(default_factory=lambda: set())
    unknown: Set[Text] = dataclasses.field(default_factory=lambda: set())


class ProjectFileType(Enum):
    NLU = "nlu"
    STORY = "story"
    TEST_STORY = "test_story"
    UNKNOWN = "unknown"


def assert_valid_project_layout_from_project_files(
    project_files: ProjectFiles,
) -> None:
    """Assert that the connected repository contains a valid Rasa Open Source project.

    Args:
        project_files: `ProjectFiles` tuple of the paths of files in project

    Raises:
        ProjectLayoutError: If project isn't valid.
    """
    if len(project_files.incompatible_yaml_files) > 0:
        raise IncompatibleYAMLDataError()

    if len(project_files.incompatible_md_files) > 0:
        raise IncompatibleMarkdownDataError()
    if len(project_files.incompatible_nlu_json_files) > 0:
        raise IncompatibleNLUJSONDataError()


def assert_valid_project_layout(
    path: Path,
    domain_path: Optional[Text] = None,
    configuration_path: Optional[Text] = None,
    data_directory_path: Optional[Text] = None,
    test_stories_directory_path: Optional[Text] = None,
) -> None:
    """Assert that the connected repository contains a valid Rasa Open Source project.

    Args:
        path: The path to the directory which should be validated.
        domain_path: the (optional) path to the domain. Defaults to `domain.yml`.
        configuration_path:
          the (optional) path to the domain. Defaults to `config.yml`.
        data_directory_path:
          the (optional) path to the data directory. Defaults to `data`.
        test_stories_directory_path:
          the (optional) path to the test stories. Defaults to `tests`.
    """
    project_files = find_project_files(
        path,
        domain_path,
        configuration_path,
        data_directory_path,
        test_stories_directory_path,
    )
    assert_valid_project_layout_from_project_files(project_files)


def _get_file_project_type(path: Text) -> ProjectFileType:
    if rasax.community.legacy.data.is_likely_yaml_file(path):
        if rasax.community.legacy.data.is_nlu_file(path):
            return ProjectFileType.NLU

        if YAMLStoryReader.is_test_stories_file(path):
            return ProjectFileType.TEST_STORY

        if YAMLStoryReader.is_stories_file(path):
            return ProjectFileType.STORY

    return ProjectFileType.UNKNOWN


def find_project_files(
    path: Path,
    domain_path: Optional[Text] = None,
    configuration_path: Optional[Text] = None,
    data_directory_path: Optional[Text] = None,
    test_stories_directory_path: Optional[Text] = None,
) -> ProjectFiles:
    """Traverse path and find project files.

    Check if domain file, configuration file, and data directory does not exist in
    expected paths.
    Then traverse the data directory and sort files into stories, test stories, nlu,
    incompatible, or unknown.
    If a file is marked as incompatible, this is currently only used to mark files of
    outdated format, so YML files that are not of the current version, or old
    markdown or json formats.

    Args:
        path: the path to the project directory.
        domain_path: the (optional) path to the domain. Defaults to `domain.yml`.
        configuration_path:
          the (optional) path to the domain. Defaults to `config.yml`.
        data_directory_path:
          the (optional) path to the data directory. Defaults to `data`.
        test_stories_directory_path:
          the (optional) path to the test stories. Defaults to `tests`.

    Returns:
        Tuple `ProjectFiles` containing the found file paths

    Raises:
        ProjectLayoutError if domain file, configuration file, and data directory does
        not exist in expected paths.
    """
    project_files = ProjectFiles(
        domain=domain_path or os.path.join(path, rasa_x_config.default_domain_path),
        configuration=configuration_path
        or os.path.join(path, rasa_x_config.default_config_path),
        data_dir=data_directory_path or os.path.join(path, rasa_x_config.data_dir),
        test_stories_dir=test_stories_directory_path
        or os.path.join(path, rasa_x_config.default_test_stories_dir),
    )

    if not Path(project_files.domain).exists():
        raise IncompatibleProjectError(
            f"Domain should be present in the following path: '{project_files.domain}'"
        )

    if not Path(project_files.configuration).is_file():
        raise IncompatibleProjectError(
            f"Model configuration should be present in the following path: '{project_files.configuration}'"
        )
    if not Path(project_files.data_dir).is_dir():
        raise IncompatibleProjectError(
            f"Data directory should be present in the following path: '{project_files.data_dir}'"
        )

    data_directory_files = io_utils.list_directory(project_files.data_dir)
    if Path(project_files.test_stories_dir).exists():
        tests_directory_files = io_utils.list_directory(project_files.test_stories_dir)
        data_directory_files.extend(tests_directory_files)
    for file_path in data_directory_files:
        if Path(file_path).is_file():
            try:
                file_content = io_utils.read_file(file_path)
                file_type = _get_file_project_type(file_path)
                if file_type == file_type.UNKNOWN:
                    if _is_rasa_markdown(file_path):
                        project_files.incompatible_md_files.add(file_path)
                    elif _is_nlu_json(file_path):
                        project_files.incompatible_nlu_json_files.add(file_path)
                    else:
                        project_files.unknown.add(file_path)
                else:
                    parsed_yaml = yaml_utils.read_yaml(file_content)
                    rasax.community.data.validate_project_data_version(parsed_yaml)
                    if file_type == file_type.NLU:
                        project_files.nlu.add(file_path)
                    if file_type == file_type.STORY:
                        project_files.stories.add(file_path)
                    if file_type == file_type.TEST_STORY:
                        project_files.test_stories.add(file_path)
            except ProjectDataVersionError:
                project_files.incompatible_yaml_files.add(file_path)

    return project_files


def _is_rasa_markdown(file_path: Text) -> bool:
    if Path(file_path).suffix.lower() == FileFormat.MARKDOWN.value:
        content = rasax.community.legacy.utils.io.read_file(
            file_path, rasax.community.legacy.utils.io.DEFAULT_ENCODING
        )

        return _is_rasa_nlu_markdown(content) or _is_rasa_story_markdown(content)

    return False


def _is_rasa_story_markdown(content: Text) -> bool:
    return re.match(r"##\s*.*\n\*[^:]*.*\n\s*-.*", content) is not None


def _is_rasa_nlu_markdown(content: Text) -> bool:
    return any(
        re.match(pattern, content)
        for pattern in [f"## {s}:" for s in ["intent", "synonym", "regex", "lookup"]]
    )


def _is_nlu_json(file_path: Text) -> bool:
    if Path(file_path).suffix.lower() == FileFormat.JSON.value:
        try:
            with open(file_path, encoding=DEFAULT_ENCODING) as fh:
                content = json.load(fh)
                return "rasa_nlu_data" in content
        except Exception:
            return False

    return False
