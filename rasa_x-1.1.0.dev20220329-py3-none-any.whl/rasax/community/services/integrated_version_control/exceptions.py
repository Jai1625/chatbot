import dataclasses
from typing import Text


class GitError(Exception):
    """Base exception for all Git errors."""


class GitConcurrentOperationException(GitError):
    """Exception that is raised when there's another Git operation in progress."""


class GitCommitError(GitError):
    """Exception in case an error happens when trying to push changes."""


class GitBranchCreationError(GitError):
    """Exception in case an error happens when trying to create a new branch."""


class CredentialsError(GitError):
    """Exception raised in case there are no read and write permissions for the Git repository."""


class GitHTTPSCredentialsError(CredentialsError):
    """Exception raised in case an error occurred when trying to fetch or push
    from a remote repository, due to invalid credentials being specified for
    an HTTPS connection."""


class IncompatibleProjectError(GitError):
    """Exception if the connected repository doesn't have the required layout.

    Raised if domain, config or data directory don't exist.
    """

    reason: Text = "InvalidProjectLayout"
    message: Text = "The repository does not have the expected project layout."


@dataclasses.dataclass
class IncompatibleMarkdownDataError(IncompatibleProjectError):
    """Exception if the connected repository contains Markdown project data."""

    reason: Text = "InvalidProjectLayoutLegacyMarkdown"
    message: Text = (
        "Invalid Markdown project data. "
        "There is incompatible Markdown project data present in this branch. "
        "Please make sure your project data uses Rasa YAML version 3."
    )


@dataclasses.dataclass
class IncompatibleNLUJSONDataError(IncompatibleProjectError):
    """Exception if the connected repository contains NLU JSON project data."""

    reason: Text = "InvalidProjectLayoutLegacyJSON"
    message: Text = (
        "Invalid NLU JSON project data. "
        "There is incompatible NLU JSON project data present in this branch. "
        "Please make sure your project data uses Rasa YAML version 3."
    )


class IncompatibleYAMLDataError(IncompatibleProjectError):
    """Exception if the connected repository contains YAML project data."""

    reason: Text = "InvalidProjectLayoutLegacyYAML"
    message: Text = (
        "Invalid YAML project data. "
        "There is incompatible YAML project data present in this branch. "
        "Please make sure your project data uses Rasa YAML version 3."
    )


class GitRemoteBranchNotFoundError(GitError):
    """Exception raised in case the git branch doesn't exist."""
