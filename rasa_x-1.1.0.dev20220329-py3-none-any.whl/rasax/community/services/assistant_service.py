import json
from datetime import datetime
from typing import Text, List, Dict, Any, Optional, Union, Tuple

from sanic.request import Request
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload

import rasax.community.utils.common as common_utils
from rasax.community.database.assistant import (
    BusinessLogicFlow,
    BusinessLogicFlowElement,
    SampleConversation,
    SampleConversationItem,
    AssistantLink,
)
from rasax.community.database.service import DbService
from rasax.community.services.config_service import ConfigService, ConfigKey


CURRENT_DEMO_VERSION = 1
CURRENT_DEMO_VERSION_CONFIG_KEY = ConfigKey.BLUEPRINTS_CREATED_DEMO_OBJECTS_V1


class AssistantService(DbService):
    """A service used to work with assistant-related models."""

    @staticmethod
    def from_request(request: Request, **kwargs) -> "AssistantService":
        """Construct `InsightService` from an incoming HTTP request.

        Args:
            request: Incoming HTTP request.
            **kwargs: Other key-value args, not used.

        Returns:
            Constructed `InsightService` object.
        """
        return AssistantService(request.ctx.db_session)

    def fetch_flows(
        self,
        limit: int = 30,
        offset: int = 0,
        search: Optional[Text] = None,
        exclude_linked_conversation_id: Optional[int] = None,
        exclude_demos: Optional[bool] = False,
    ) -> common_utils.QueryResult:
        """Fetches Business Logic Flows.

        Args:
            limit:  limit to use for the query, defaults to 30
            offset: offset to use for the query, defaults to 0
            search: only return `BusinessLogicFlow`s that contain this text, defaults to None
            exclude_linked_conversation_id: An ID of a Sample Conversation to exclude flows that are linked to it
            exclude_demos: exclude demo Flows.

        Returns:
            QueryResult with `BusinessLogicFlow`s matching the query.
        """
        query = self.query(BusinessLogicFlow).order_by(
            BusinessLogicFlow.updated_at.desc()
        )

        if search:
            query = query.filter(BusinessLogicFlow.name.ilike(f"%{search}%"))

        if exclude_linked_conversation_id:
            exclude_flow_ids = [
                t[0]
                for t in self.query(AssistantLink.business_logic_flow_id).filter(
                    AssistantLink.example_conversation_id
                    == exclude_linked_conversation_id
                )
            ]
            query = query.filter(BusinessLogicFlow.id.notin_(exclude_flow_ids))

        if exclude_demos:
            query = query.filter(BusinessLogicFlow.is_demo.is_(False))

        count = query.count()
        query = query.limit(limit).offset(offset)

        result = [flow.as_dict() for flow in query.all()]
        return common_utils.QueryResult(result, count)

    def get_flow(self, flow_id: Any) -> Optional[BusinessLogicFlow]:
        """Gets Business Logic Flow by id.

        Args:
            flow_id: ID of the Business Logic Flow.

        Return:
            BusinessLogicFlow or `None` if none could be found with the given ID.
        """
        try:
            lookup_id = int(flow_id)
            return self.query(BusinessLogicFlow).get(lookup_id)
        except (ValueError, TypeError):
            return None

    def create_flow(
        self,
        name: Text,
        elements: List[Dict[Text, Any]],
        description: Text = None,
        created_at: datetime = None,
        updated_at: datetime = None,
        is_demo: bool = None,
        demo_version: int = None,
    ) -> BusinessLogicFlow:
        """Creates a new Business Logic Flow.

        Args:
            name:         a unique name.
            elements:     a list of flowchart steps and arrows as dicts.
            description:  optional value for further describing the business logic flow.
            created_at:   optional value when it was created, if missing uses `datetime.utcnow()`
            updated_at:   optional value when it was updated, if missing uses `datetime.utcnow()`
            is_demo:      optional value whether it is a demo flow.
            demo_version: optional value for the demo version.

        Raises:
            DuplicateBusinessLogicFlowException: When a business logic flow with the same name already exists.

        Returns:
            Created `BusinessLogicFlow`.
        """
        try:
            flow = BusinessLogicFlow(
                name=name,
                description=description,
                created_at=created_at,
                updated_at=updated_at,
                is_demo=is_demo,
                demo_version=demo_version,
            )
            flow.elements = self._parse_flow_elements(elements)
            self.add(flow)

            self.flush()
            return flow
        except IntegrityError:
            self.rollback()
            raise DuplicateBusinessLogicFlowException()

    def update_flow(self, flow_id: Any, data: Dict[Text, Any],) -> BusinessLogicFlow:
        """Patch updates a Business Logic Flow.

        This method only updates the flow values when they're present in the data dictionary.
        When a key is present with a `None` value then this field will be set to `None`.

        Args:
            flow_id:     ID of the Business Logic Flow.
            data:    the data to update to potentially containing a name, description, and elements

        Raises:
            ValueError: when a flow with the given ID cannot be found.
            BusinessLogicFlowParseException: when the given elements cannot be parsed.

        Returns:
            Updated `BusinessLogicFlow`.
        """
        flow = self.get_flow(flow_id)

        if flow is None:
            raise ValueError()

        try:
            if "name" in data:
                flow.name = data["name"]
            if "description" in data:
                flow.description = data["description"]
            if "elements" in data:
                self._merge_elements(flow, data["elements"])

            self.flush()
            self.session.refresh(flow)
            return flow
        except IntegrityError:
            self.session.rollback()
            raise DuplicateBusinessLogicFlowException()

    def delete_flow(self, flow_id: Any) -> None:
        """Deletes a Business Logic Flow if it exists.

        Args:
            flow_id: ID of the Business Logic Flow.

        Raises:
            ValueError: when a flow with the given ID cannot be found.
        """
        flow = self.get_flow(flow_id)

        if flow is None:
            raise ValueError()

        self.delete(flow)
        self.flush()

    def fetch_sample_conversations(
        self,
        limit: int = 30,
        offset: int = 0,
        search: Optional[Text] = None,
        exclude_linked_flow_id: Optional[int] = None,
        exclude_demos: Optional[bool] = False,
    ) -> common_utils.QueryResult:
        """Fetches Sample Conversations.

        Args:
            limit:  limit to use for the query, defaults to 30
            offset: offset to use for the query, defaults to 0
            search: only return SampleConversations that contain this text
            exclude_linked_flow_id: An ID of a Flow to exclude sample converastions that are linked to it
            exclude_demos: exclude demo Sample Conversations.

        Returns:
            QueryResult with `SampleConversation`s matching the query.
        """
        query = self.query(SampleConversation).order_by(
            SampleConversation.updated_at.desc()
        )

        if search:
            query = query.filter(SampleConversation.name.ilike(f"%{search}%"))

        if exclude_linked_flow_id:
            exclude_conversation_ids = [
                t[0]
                for t in self.query(AssistantLink.example_conversation_id).filter(
                    AssistantLink.business_logic_flow_id == exclude_linked_flow_id
                )
            ]
            query = query.filter(SampleConversation.id.notin_(exclude_conversation_ids))

        if exclude_demos:
            query = query.filter(SampleConversation.is_demo.is_(False))

        count = query.count()
        query = query.limit(limit).offset(offset)

        result = [conv.as_dict() for conv in query.all()]
        return common_utils.QueryResult(result, count)

    def get_sample_conversation(
        self, sample_conversation_id: Any
    ) -> Optional[SampleConversation]:
        """Gets Sample Conversation by id.

        Args:
            sample_conversation_id: ID of the Sample Conversation.

        Return:
            SampleConversation or `None` if none could be found with the given ID.
        """
        try:
            lookup_id = int(sample_conversation_id)
            return self.query(SampleConversation).get(lookup_id)
        except (ValueError, TypeError):
            return None

    def create_sample_conversation(
        self,
        name: Text,
        description: Text = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
        is_demo: bool = None,
        demo_version: int = None,
    ) -> SampleConversation:
        """Creates a sample conversation.

        Args:
            name:         The name of the conversation.
            description:  optional value for further describing the sample conversation.
            created_at:   optional value when it was created, if missing uses `datetime.utcnow()`
            updated_at:   optional value when it was updated, if missing uses `datetime.utcnow()`
            is_demo:      optional value whether it is a demo flow.
            demo_version: optional value for the demo version.

        Returns:
            Created `SampleConversation`
        """
        try:
            sample_conversation = SampleConversation(
                name=name,
                description=description,
                created_at=created_at,
                updated_at=updated_at,
                is_demo=is_demo,
                demo_version=demo_version,
            )
            self.session.add(sample_conversation)
            self.session.flush()
            return sample_conversation
        except IntegrityError:
            self.session.rollback()
            raise DuplicateSampleConversationException()

    def clone_sample_conversation(
        self,
        source_id: int,
        name: Text,
        description: Text = None,
        clone_links: bool = False,
    ) -> SampleConversation:
        """Clones an existing sample conversation.

        Args:
            source_id:   ID of the source sample conversation to clone from.
            clone_links: whether to clone the links of the source sample conversation.
            name:        name of the new sample conversation.
            description: optional value for further describing the sample conversation.

        Raises:
            DuplicateSampleConversationException: when the given name is not unique.

        Returns:
            Cloned `SampleConversation`
        """
        source = self.session.query(SampleConversation).get(source_id)
        if not source:
            raise SampleConversationNotFound

        conversation = self.create_sample_conversation(name, description)

        for item in source.items:
            self.create_sample_conversation_message(
                item.type, item.text, conversation.id
            )

        if clone_links:
            self.bulk_create_links(
                [
                    {
                        "business_logic_flow_id": link.business_logic_flow_id,
                        "sample_conversation_id": conversation.id,
                    }
                    for link in source.links
                ]
            )

        return conversation

    def update_sample_conversation(
        self, sample_conversation_id: Any, name: Text, description: Text,
    ) -> SampleConversation:
        """Updates a Sample Conversation.

        Args:
            sample_conversation_id: ID of the Business Logic Flow.
            name:                   a unique name.
            description:            a string for further describing the business logic flow.

        Raises:
            ValueError: when a sample conversation with the given ID cannot be found.

        Returns:
            Updated `SampleConversation`.
        """
        conversation = self.get_sample_conversation(sample_conversation_id)

        if conversation is None:
            raise ValueError()

        try:
            conversation.name = name
            conversation.description = description

            self.flush()
            return conversation
        except IntegrityError:
            self.session.rollback()
            raise DuplicateSampleConversationException()

    def create_sample_conversation_message(
        self,
        type_: Text,
        text: Text,
        sample_conversation_id: Any,
        order: Optional[int] = None,
    ) -> SampleConversationItem:
        """Creates message to an existing sample conversation.

        Args:
            type_: The type of the message (`user_message` or `bot_message`).
            text: The text of the message.
            order: The order number of the message.
            sample_conversation_id: The ID of the sample conversation this message is part of.

        Returns:
            The created `SampleConversationItem`.

        Raises:
            `ValueError` when one or more given values are invalid or missing.
        """
        conversation = self.get_sample_conversation(sample_conversation_id)
        if conversation is None:
            raise ValueError("sample conversation does not exist")

        conversation_message_count = (
            self.session.query(SampleConversationItem)
            .filter_by(example_conversation_id=sample_conversation_id)
            .count()
        )

        if order is not None and order < 0:
            order = 0

        if order is None or order >= conversation_message_count:
            order = conversation_message_count
        else:
            # move subsequent messages by 1
            messages_to_update = self.session.query(SampleConversationItem).filter(
                SampleConversationItem.example_conversation_id
                == sample_conversation_id,
                SampleConversationItem.order >= order,
            )

            for message in messages_to_update:
                message.order += 1

        message = SampleConversationItem(
            type=type_, text=text, conversation=conversation, order=order,
        )
        self.session.add(message)
        self.session.flush()
        conversation.updated_at = message.updated_at

        return message

    def delete_sample_conversation(self, sample_conversation_id: Any) -> None:
        """Deletes a Sample Conversation if it exists.

        Args:
            sample_conversation_id: ID of the Sample Conversation.

        Raises:
            ValueError: when a sample conversation with the given ID cannot be found.
        """
        conversation = self.get_sample_conversation(sample_conversation_id)

        if conversation is None:
            raise ValueError()

        self.delete(conversation)
        self.flush()

    def delete_sample_conversation_message(
        self, sample_conversation_item_id: Any
    ) -> None:
        """Deletes a Sample Conversation Message if it exists.

        Args:
            sample_conversation_item_id: ID of the Sample Conversation Item.

        Raises:
            ValueError: when a sample conversation item with the given ID cannot be found.
        """
        try:
            lookup_id = int(sample_conversation_item_id)
            item = self.query(SampleConversationItem).get(lookup_id)

            if item is None:
                raise ValueError()

            self.delete(item)
            self.flush()
        except TypeError:
            raise ValueError()

    def update_sample_conversation_message(
        self,
        sample_conversation_id: Any,
        sample_conversation_item_id: Any,
        type_: Optional[Text] = None,
        text: Optional[Text] = None,
        order: Optional[int] = None,
    ) -> SampleConversationItem:
        """Updates a Sample Conversation Message if it exists.

        type_: The type of the message (`user_message` or `bot_message`).
        text: The text of the message.
        order: The order number of the message.
        sample_conversation_id: The ID of the sample conversation this message is part of.
        sample_conversation_item_id: ID of the Sample Conversation Item.

        Raises:
            ValueError: when a sample conversation item with the given ID cannot be found.

        Returns:
            Updated `SampleConversationItem`.
        """
        try:
            lookup_id = int(sample_conversation_item_id)
            item = self.query(SampleConversationItem).get(lookup_id)

            if item is None:
                raise ValueError(
                    "Could not find a sample conversation item with the given ID."
                )

            conversation = self.get_sample_conversation(sample_conversation_id)

            if conversation is None:
                raise ValueError("sample conversation does not exist")

            if type_:
                item.type = type_
            if text:
                item.text = text

            if order is not None and item.order != order:
                if order < 0:
                    order = 0

                conversation_message_count = (
                    self.session.query(SampleConversationItem)
                    .filter_by(example_conversation_id=sample_conversation_id)
                    .count()
                )
                # set order to the message size if order is larger
                if order >= conversation_message_count:
                    order = conversation_message_count - 1
                # moving a message up
                if item.order < order:
                    conversation_messages_to_update = self.session.query(
                        SampleConversationItem
                    ).filter(
                        SampleConversationItem.example_conversation_id
                        == sample_conversation_id,
                        SampleConversationItem.order <= order,
                        SampleConversationItem.order > item.order,
                    )
                    for conversation_message in conversation_messages_to_update:
                        conversation_message.order -= 1

                # moving a message down
                else:
                    conversation_messages_to_update = self.session.query(
                        SampleConversationItem
                    ).filter(
                        SampleConversationItem.example_conversation_id
                        == sample_conversation_id,
                        SampleConversationItem.order >= order,
                        SampleConversationItem.order < item.order,
                    )
                    for conversation_message in conversation_messages_to_update:
                        conversation_message.order += 1

                item.order = order

            self.flush()
            conversation.updated_at = item.updated_at
            return item
        except TypeError:
            raise ValueError()

    def fetch_links(
        self,
        business_logic_flow_id: Optional[int] = None,
        sample_conversation_id: Optional[int] = None,
        limit: int = 30,
        offset: int = 0,
    ) -> common_utils.QueryResult:
        """Fetches Assistant Links.

        Args:
            business_logic_flow_id: the business logic flow id to filter links for.
            sample_conversation_id: the sample conversation id to filter links for.
            limit:                  limit to use for the query, defaults to 30
            offset:                 offset to use for the query, defaults to 0

        Raises:
            ValueError: when trying to filter for both `business_logic_flow_id` and `sample_conversation_id`.

        Returns:
            QueryResult with `AssistantLink`s matching the query.
        """
        if business_logic_flow_id and sample_conversation_id:
            raise ValueError(
                "Can only filter for `business_logic_flow_id` or `sample_conversation_id`, not both."
            )

        query = self.query(AssistantLink).order_by(AssistantLink.updated_at.desc())

        if business_logic_flow_id:
            query = query.filter_by(business_logic_flow_id=business_logic_flow_id)

        if sample_conversation_id:
            query = query.filter_by(example_conversation_id=sample_conversation_id)

        count = query.count()
        query = query.options(
            selectinload(AssistantLink.flow), selectinload(AssistantLink.conversation)
        )
        query = query.limit(limit).offset(offset)
        result = [link.as_dict(embed_linked_objects=True) for link in query.all()]

        return common_utils.QueryResult(result, count)

    def bulk_create_links(
        self, data: List[Dict[Text, int]], handle_transaction: bool = True
    ) -> List[Dict[Text, Any]]:
        """Bulk create assistant links.

        Args:
            data:               A list of dictionaries containing business logic flow and sample conversation ids.
            handle_transaction: Should database transactions be handled automatically? Defaults to `True`.

        Raises:
            BulkCreateException: when assistant link is duplicate or linked objects don't exist.

        Returns:
            List of created assistant links as a dictionary.
        """
        created_links = []
        create_errors = []

        for link_data in data:
            flow_id = link_data["business_logic_flow_id"]
            conversation_id = link_data["sample_conversation_id"]

            link, errors = self._bulk_create_single_link(flow_id, conversation_id)
            if link:
                created_links.append(link)
            else:
                create_errors.extend(errors)

        if create_errors:
            if handle_transaction:
                self.session.rollback()
            raise BulkCreateException(create_errors)

        if handle_transaction:
            self.session.commit()
        else:
            self.session.flush()

        ids = [link.id for link in created_links]
        links = (
            self.session.query(AssistantLink)
            .options(
                selectinload(AssistantLink.flow),
                selectinload(AssistantLink.conversation),
            )
            .filter(AssistantLink.id.in_(ids))
        )
        return [link.as_dict(embed_linked_objects=True) for link in links]

    def delete_link(self, link_id: Any) -> None:
        """Delete an assistant link.

        Args:
            link_id: The ID of the link to be deleted.

        Raises:
            ValueError: when no link can be found with the given ID.
        """
        try:
            lookup_id = int(link_id)
            link = self.query(AssistantLink).get(lookup_id)

            if link is None:
                raise ValueError

            self.delete(link)
            self.flush()
        except (ValueError, TypeError):
            raise ValueError("Assistant Link with given ID does not exist")

    def update_demo_objects(self):
        """Updates Blueprints demo objects when outdated."""
        config_service = ConfigService(self.session)
        config_service.initialize_configuration()
        current_version_created = config_service.get_value(
            CURRENT_DEMO_VERSION_CONFIG_KEY, expected_type=bool, read_env=False
        )

        if current_version_created:
            return

        self.delete_demo_objects()

        flow = self.create_flow(**self._create_demo_flow_kwargs())
        conversation = self.create_sample_conversation(
            **self._create_demo_conversation_kwargs()
        )
        for kwargs in self._create_demo_conversation_messages_kwargs():
            self.create_sample_conversation_message(
                sample_conversation_id=conversation.id, **kwargs
            )
        link = AssistantLink(
            flow=flow,
            conversation=conversation,
            is_demo=True,
            demo_version=CURRENT_DEMO_VERSION,
        )
        self.session.add(link)

        config_service.set_value(CURRENT_DEMO_VERSION_CONFIG_KEY, True)

    def delete_demo_objects(self):
        """Delete all Blueprints objects with `is_demo` set to `True`."""
        self.session.query(AssistantLink).filter_by(is_demo=True).delete()
        self.session.query(BusinessLogicFlow).filter_by(is_demo=True).delete()
        self.session.query(SampleConversation).filter_by(is_demo=True).delete()
        self.session.flush()

    @staticmethod
    def _parse_flow_elements(
        elements: List[Dict[Text, Any]]
    ) -> List[BusinessLogicFlowElement]:
        """Parses flow elements and returns initialized `BusinessLogicFlowElement` objects."""
        flow_elements = []

        for element in elements:
            flow_element = BusinessLogicFlowElement()
            try:
                flow_element.update_with_data(element)
            except ValueError as e:
                raise BusinessLogicFlowParseException(str(e))
            flow_elements.append(flow_element)

        return flow_elements

    def _merge_elements(
        self, flow: BusinessLogicFlow, elements: List[Dict[Text, Any]]
    ) -> None:
        """Parses flow elements and merges them with elements of an existing business logic flow."""
        parsed_elements = self._parse_flow_elements(elements)

        def _find_by_element_id(
            flow_elements: List[BusinessLogicFlowElement], element_id: Text
        ) -> Union[None, BusinessLogicFlowElement]:
            for element in flow_elements:
                if element.element_id == element_id:
                    return element
            return None

        existing_element_ids = {e.element_id for e in flow.elements}
        input_element_ids = {e.element_id for e in parsed_elements}
        element_ids_to_delete = existing_element_ids - input_element_ids
        for delete_id in element_ids_to_delete:
            existing_element = _find_by_element_id(flow.elements, delete_id)
            self.delete(existing_element)

        for input_element in parsed_elements:
            existing_element = _find_by_element_id(
                flow.elements, input_element.element_id
            )
            if existing_element is None:
                flow.elements.append(input_element)
            else:
                existing_element.update_with_data(json.loads(input_element.data))

    def _bulk_create_single_link(
        self, flow_id: int, conversation_id: int
    ) -> Tuple[Optional[AssistantLink], List[Text]]:
        errors = []

        flow = self.get_flow(flow_id)
        conversation = self.get_sample_conversation(conversation_id)

        error_prefix = f"Cannot create link with Business Logic Flow id {flow_id} and Sample Conversation id {conversation_id}"
        if flow is None:
            errors.append(f"{error_prefix} - Business Logic Flow does not exist.")
        if conversation is None:
            errors.append(f"{error_prefix} - Sample Conversation does not exist.")

        existing_count = (
            self.session.query(AssistantLink)
            .filter_by(
                business_logic_flow_id=flow_id, example_conversation_id=conversation_id,
            )
            .count()
        )
        if existing_count > 0:
            errors.append(f"{error_prefix} - Assistant Link already exists.")

        if errors:
            return None, errors

        link = AssistantLink(
            business_logic_flow_id=flow.id, example_conversation_id=conversation.id,
        )
        self.session.add(link)

        return link, errors

    @staticmethod
    def _create_demo_flow_kwargs() -> Dict[Text, Any]:
        return {
            "name": "Upgrade cell plan",
            "description": "This is a Demo created by Rasa",
            "is_demo": True,
            "demo_version": CURRENT_DEMO_VERSION,
            "elements": [
                {
                    "source": "9af605ca-5825-4433-9d71-8aab9422e090",
                    "sourceHandle": "3",
                    "target": "9878023d-53a1-479d-adf4-2a90e927d68d",
                    "targetHandle": "1",
                    "type": "editable",
                    "id": "2fac767b-c3c1-45ca-92ed-3b061597ca3d",
                    "data": {
                        "id": "2fac767b-c3c1-45ca-92ed-3b061597ca3d",
                        "value": "",
                        "element_type": "edge",
                    },
                },
                {
                    "id": "e695086d-f8ae-44ff-bbd3-7bbefd19debd",
                    "type": "editable",
                    "data": {
                        "id": "e695086d-f8ae-44ff-bbd3-7bbefd19debd",
                        "value": "Is customer logged in?",
                        "color": {
                            "hexValue": "#FFD036",
                            "name": "Gold",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Gold",
                            },
                        },
                        "element_type": "node",
                        "shape": "diamond",
                        "size": {"width": 135, "height": 135},
                    },
                    "position": {"x": 232, "y": 518},
                },
                {
                    "source": "edc76e91-d643-429e-8df9-94aebcacf26e",
                    "sourceHandle": "3",
                    "target": "da5ca2a0-4ff3-43d1-b963-bee2ba71c5df",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "6e30af11-aa6a-4dc8-ae0c-53bfab63e31e",
                    "data": {
                        "id": "6e30af11-aa6a-4dc8-ae0c-53bfab63e31e",
                        "value": "Success",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "edc76e91-d643-429e-8df9-94aebcacf26e",
                    "sourceHandle": "1",
                    "target": "3842b0fd-6e0f-4fe9-ae79-c5c260d2dfed",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "881fd853-6d1e-4723-9e46-ede648d341bd",
                    "data": {
                        "id": "881fd853-6d1e-4723-9e46-ede648d341bd",
                        "value": "Fail",
                        "element_type": "edge",
                    },
                },
                {
                    "id": "9af605ca-5825-4433-9d71-8aab9422e090",
                    "type": "editable",
                    "data": {
                        "id": "9af605ca-5825-4433-9d71-8aab9422e090",
                        "value": "Jump to agree to T&C flow",
                        "color": {
                            "hexValue": "#2C3951",
                            "name": "Dark gray",
                            "complement": {
                                "hexValue": "#FFFFFF",
                                "name": "Complement to Dark gray",
                            },
                        },
                        "element_type": "node",
                        "shape": "circle",
                        "size": {"height": 124, "width": 126},
                    },
                    "position": {"x": 236, "y": 1386},
                },
                {
                    "id": "6b393af1-8146-411e-9db9-8072aabb920c",
                    "type": "editable",
                    "data": {
                        "id": "6b393af1-8146-411e-9db9-8072aabb920c",
                        "value": "Entry point: Select a plan",
                        "color": {
                            "hexValue": "#2C3951",
                            "name": "Dark gray",
                            "complement": {
                                "hexValue": "#FFFFFF",
                                "name": "Complement to Dark gray",
                            },
                        },
                        "element_type": "node",
                        "shape": "circle",
                        "size": {"height": 118, "width": 121},
                    },
                    "position": {"x": 239, "y": 125},
                },
                {
                    "id": "edc76e91-d643-429e-8df9-94aebcacf26e",
                    "type": "editable",
                    "data": {
                        "id": "edc76e91-d643-429e-8df9-94aebcacf26e",
                        "value": "Submit order",
                        "color": {
                            "hexValue": "#FFD036",
                            "name": "Gold",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Gold",
                            },
                        },
                        "element_type": "node",
                        "shape": "diamond",
                        "size": {"width": 135, "height": 135},
                    },
                    "position": {"x": 1077, "y": 469},
                },
                {
                    "id": "da5ca2a0-4ff3-43d1-b963-bee2ba71c5df",
                    "type": "editable",
                    "data": {
                        "id": "da5ca2a0-4ff3-43d1-b963-bee2ba71c5df",
                        "value": "Upgrade completed",
                        "color": {
                            "hexValue": "#2C3951",
                            "name": "Dark gray",
                            "complement": {
                                "hexValue": "#FFFFFF",
                                "name": "Complement to Dark gray",
                            },
                        },
                        "element_type": "node",
                        "shape": "circle",
                        "size": {"height": 130, "width": 126},
                    },
                    "position": {"x": 1218, "y": 752},
                },
                {
                    "id": "3842b0fd-6e0f-4fe9-ae79-c5c260d2dfed",
                    "type": "editable",
                    "data": {
                        "id": "3842b0fd-6e0f-4fe9-ae79-c5c260d2dfed",
                        "value": "Transfer to human",
                        "color": {
                            "hexValue": "#2C3951",
                            "name": "Dark gray",
                            "complement": {
                                "hexValue": "#FFFFFF",
                                "name": "Complement to Dark gray",
                            },
                        },
                        "element_type": "node",
                        "shape": "circle",
                        "size": {"height": 128, "width": 127},
                    },
                    "position": {"x": 940, "y": 753},
                },
                {
                    "source": "9878023d-53a1-479d-adf4-2a90e927d68d",
                    "sourceHandle": "4",
                    "target": "691c260f-171c-4eae-a257-86f038ceb2dc",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "d8b87c86-3e66-440b-9a5a-b34580bbb299",
                    "data": {
                        "id": "d8b87c86-3e66-440b-9a5a-b34580bbb299",
                        "value": "",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "4828824f-3251-4650-b324-752216355050",
                    "sourceHandle": "4",
                    "target": "afcd4ad8-38cb-44b9-8d5e-c0c3c19fe293",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "d0252131-b54b-43da-a46e-0ea90b07eb5f",
                    "data": {
                        "id": "d0252131-b54b-43da-a46e-0ea90b07eb5f",
                        "value": "",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "6b393af1-8146-411e-9db9-8072aabb920c",
                    "sourceHandle": "4",
                    "target": "a7f73396-ae2d-4260-bf6c-7e3f646b9218",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "a03cdd16-fc79-4685-b41c-eaa8b2fc333e",
                    "data": {
                        "id": "a03cdd16-fc79-4685-b41c-eaa8b2fc333e",
                        "value": "",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "a7f73396-ae2d-4260-bf6c-7e3f646b9218",
                    "sourceHandle": "4",
                    "target": "e695086d-f8ae-44ff-bbd3-7bbefd19debd",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "b185e296-eb93-4b4b-9f2d-f5c049041ff3",
                    "data": {
                        "id": "b185e296-eb93-4b4b-9f2d-f5c049041ff3",
                        "value": "",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "5830408e-2fbe-4054-a872-9e7ef045ecbe",
                    "sourceHandle": "4",
                    "target": "a8ade497-66f2-454b-81d9-6a29945f802b",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "7e59ea8c-62a2-47dd-8d56-69398f579722",
                    "data": {
                        "id": "7e59ea8c-62a2-47dd-8d56-69398f579722",
                        "value": "",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "0fd9c8ea-7e3d-4dd0-9c79-0552bd3a5f47",
                    "sourceHandle": "4",
                    "target": "9af605ca-5825-4433-9d71-8aab9422e090",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "60084a7a-d306-4899-82d5-abf17728ba31",
                    "data": {
                        "id": "60084a7a-d306-4899-82d5-abf17728ba31",
                        "value": "",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "e695086d-f8ae-44ff-bbd3-7bbefd19debd",
                    "sourceHandle": "4",
                    "target": "5830408e-2fbe-4054-a872-9e7ef045ecbe",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "49f093e3-18aa-4347-91f2-e0174ab59bcf",
                    "data": {
                        "id": "49f093e3-18aa-4347-91f2-e0174ab59bcf",
                        "value": "Yes",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "e695086d-f8ae-44ff-bbd3-7bbefd19debd",
                    "sourceHandle": "1",
                    "target": "fc439f24-d61d-4692-a8b5-e265a8c101c9",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "3eaae6cf-ddb6-4846-ba40-0b0939fa766b",
                    "data": {
                        "id": "3eaae6cf-ddb6-4846-ba40-0b0939fa766b",
                        "value": "No",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "fc439f24-d61d-4692-a8b5-e265a8c101c9",
                    "sourceHandle": "4",
                    "target": "5830408e-2fbe-4054-a872-9e7ef045ecbe",
                    "targetHandle": "1",
                    "type": "editable",
                    "id": "9f054220-68c1-4bc0-8b5c-a039d3e9b381",
                    "data": {
                        "id": "9f054220-68c1-4bc0-8b5c-a039d3e9b381",
                        "value": "Logged in",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "a8ade497-66f2-454b-81d9-6a29945f802b",
                    "sourceHandle": "4",
                    "target": "0fd9c8ea-7e3d-4dd0-9c79-0552bd3a5f47",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "498d6447-b935-41dc-a8b9-37f7cc0a1670",
                    "data": {
                        "id": "498d6447-b935-41dc-a8b9-37f7cc0a1670",
                        "value": "Plan selected",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "691c260f-171c-4eae-a257-86f038ceb2dc",
                    "sourceHandle": "1",
                    "target": "4828824f-3251-4650-b324-752216355050",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "d04c90c3-2c61-4ae6-b141-fa28bc09f5ff",
                    "data": {
                        "id": "d04c90c3-2c61-4ae6-b141-fa28bc09f5ff",
                        "value": "No",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "4828824f-3251-4650-b324-752216355050",
                    "sourceHandle": "3",
                    "target": "691c260f-171c-4eae-a257-86f038ceb2dc",
                    "targetHandle": "4",
                    "type": "editable",
                    "id": "b995c526-8e23-41e3-b20e-8cebc82b27b8",
                    "data": {
                        "id": "b995c526-8e23-41e3-b20e-8cebc82b27b8",
                        "value": "No",
                        "element_type": "edge",
                    },
                },
                {
                    "source": "691c260f-171c-4eae-a257-86f038ceb2dc",
                    "sourceHandle": "3",
                    "target": "edc76e91-d643-429e-8df9-94aebcacf26e",
                    "targetHandle": "2",
                    "type": "editable",
                    "id": "478ea822-20ce-4be7-9a03-928ab17ad18f",
                    "data": {
                        "id": "478ea822-20ce-4be7-9a03-928ab17ad18f",
                        "value": "Yes",
                        "element_type": "edge",
                    },
                },
                {
                    "id": "9878023d-53a1-479d-adf4-2a90e927d68d",
                    "type": "editable",
                    "data": {
                        "id": "9878023d-53a1-479d-adf4-2a90e927d68d",
                        "value": "Entry point: Agree to T&C",
                        "color": {
                            "hexValue": "#2C3951",
                            "name": "Dark gray",
                            "complement": {
                                "hexValue": "#FFFFFF",
                                "name": "Complement to Dark gray",
                            },
                        },
                        "element_type": "node",
                        "shape": "circle",
                        "size": {"height": 120, "width": 125},
                    },
                    "position": {"x": 868, "y": 125},
                },
                {
                    "id": "afcd4ad8-38cb-44b9-8d5e-c0c3c19fe293",
                    "type": "editable",
                    "data": {
                        "id": "afcd4ad8-38cb-44b9-8d5e-c0c3c19fe293",
                        "value": "End",
                        "color": {
                            "hexValue": "#2C3951",
                            "name": "Dark gray",
                            "complement": {
                                "hexValue": "#FFFFFF",
                                "name": "Complement to Dark gray",
                            },
                        },
                        "element_type": "node",
                        "shape": "circle",
                        "size": {"height": 125, "width": 129},
                    },
                    "position": {"x": 682, "y": 750},
                },
                {
                    "id": "691c260f-171c-4eae-a257-86f038ceb2dc",
                    "type": "editable",
                    "data": {
                        "id": "691c260f-171c-4eae-a257-86f038ceb2dc",
                        "value": "Ask customer to agree to T&C",
                        "color": {
                            "hexValue": "#94C6FF",
                            "name": "Cornflower",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Cornflower",
                            },
                        },
                        "element_type": "node",
                        "shape": "rounded",
                        "size": {"height": 95, "width": 183},
                    },
                    "position": {"x": 839, "y": 332},
                },
                {
                    "id": "a7f73396-ae2d-4260-bf6c-7e3f646b9218",
                    "type": "editable",
                    "data": {
                        "id": "a7f73396-ae2d-4260-bf6c-7e3f646b9218",
                        "value": "Customer wants to upgrade cell phone plan.",
                        "color": {
                            "hexValue": "#87E5E2",
                            "name": "Cyan",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Cyan",
                            },
                        },
                        "element_type": "node",
                        "shape": "rounded",
                        "size": {"height": 95, "width": 183},
                    },
                    "position": {"x": 208, "y": 331},
                },
                {
                    "id": "fc439f24-d61d-4692-a8b5-e265a8c101c9",
                    "type": "editable",
                    "data": {
                        "id": "fc439f24-d61d-4692-a8b5-e265a8c101c9",
                        "value": "Log in flow (Website)",
                        "color": {
                            "hexValue": "#CED5E7",
                            "name": "Mid gray",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Mid gray",
                            },
                        },
                        "element_type": "node",
                        "shape": "rectangle",
                        "size": {"height": 91, "width": 181},
                    },
                    "position": {"x": -84, "y": 671},
                },
                {
                    "id": "a8ade497-66f2-454b-81d9-6a29945f802b",
                    "type": "editable",
                    "data": {
                        "id": "a8ade497-66f2-454b-81d9-6a29945f802b",
                        "value": "Compare plan page (Website)",
                        "color": {
                            "hexValue": "#CED5E7",
                            "name": "Mid gray",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Mid gray",
                            },
                        },
                        "element_type": "node",
                        "shape": "rectangle",
                        "size": {"height": 93, "width": 182},
                    },
                    "position": {"x": 208, "y": 976},
                },
                {
                    "id": "0fd9c8ea-7e3d-4dd0-9c79-0552bd3a5f47",
                    "type": "editable",
                    "data": {
                        "id": "0fd9c8ea-7e3d-4dd0-9c79-0552bd3a5f47",
                        "value": "Ask customer to confirm the selected <plan_name> and <price>",
                        "color": {
                            "hexValue": "#94C6FF",
                            "name": "Cornflower",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Cornflower",
                            },
                        },
                        "element_type": "node",
                        "shape": "rounded",
                        "size": {"height": 97, "width": 188},
                    },
                    "position": {"x": 205, "y": 1200},
                },
                {
                    "id": "5830408e-2fbe-4054-a872-9e7ef045ecbe",
                    "type": "editable",
                    "data": {
                        "id": "5830408e-2fbe-4054-a872-9e7ef045ecbe",
                        "value": "Ask customer to select a plan",
                        "color": {
                            "hexValue": "#94C6FF",
                            "name": "Cornflower",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Cornflower",
                            },
                        },
                        "element_type": "node",
                        "shape": "rounded",
                        "size": {"height": 98, "width": 182},
                    },
                    "position": {"x": 208, "y": 783},
                },
                {
                    "id": "4828824f-3251-4650-b324-752216355050",
                    "type": "editable",
                    "data": {
                        "id": "4828824f-3251-4650-b324-752216355050",
                        "value": "Confirm customer wants to cancel order",
                        "color": {
                            "hexValue": "#94C6FF",
                            "name": "Cornflower",
                            "complement": {
                                "hexValue": "#252D40",
                                "name": "Complement to Cornflower",
                            },
                        },
                        "element_type": "node",
                        "shape": "rounded",
                        "size": {"height": 93, "width": 183},
                    },
                    "position": {"x": 655, "y": 495},
                },
            ],
        }

    @staticmethod
    def _create_demo_conversation_kwargs() -> Dict[Text, Any]:
        return {
            "name": "Select a plan",
            "description": "A customer is talking to the bot while selecting a plan on the website. Bot captures data from the website.",
            "is_demo": True,
            "demo_version": CURRENT_DEMO_VERSION,
        }

    @staticmethod
    def _create_demo_conversation_messages_kwargs() -> List[Dict[Text, Any]]:
        return [
            {"type_": "user_message", "text": "I want to upgrade my cell phone plan.",},
            {
                "type_": "bot_message",
                "text": "Sure thing! Please log in first. www.rasa-telecommunications.com/login",
            },
            {
                "type_": "bot_message",
                "text": "Now, you can select the new plan here:  www.rasa-telecommunications.com/plan",
            },
            {
                "type_": "bot_message",
                "text": "Great choice! I\u2019m confirming you want  to upgrade to Rasa Phone XL plan. It will be \u20ac29/month.",
            },
            {"type_": "bot_message", "text": "Is the above information correct?",},
            {"type_": "user_message", "text": "Yes!",},
            {
                "type_": "bot_message",
                "text": "Awesome! Do you agree to  our Terms & Conditions <link> ?",
            },
            {"type_": "user_message", "text": "Yes, I agree.",},
            {
                "type_": "bot_message",
                "text": "Thank you for your purchase.  Your order was successfully processed.",
            },
            {
                "type_": "bot_message",
                "text": "Your new plan will start from next week.",
            },
            {"type_": "bot_message", "text": "Anything else I can help you with?",},
            {"type_": "user_message", "text": "All fine. Bye!",},
            {"type_": "bot_message", "text": "Great! Have a lovely day.",},
        ]


class DuplicateBusinessLogicFlowException(Exception):
    """Exception for a business logic flow with a duplicate name."""

    pass


class BusinessLogicFlowParseException(Exception):
    """Exception when parsing invalid business logic flow elements."""

    pass


class DuplicateSampleConversationException(Exception):
    """Exception for a sample conversation with a duplicate name."""

    pass


class SampleConversationNotFound(Exception):
    """Exception for when a sample conversation cannot be found."""

    pass


class BulkCreateException(Exception):
    """Exception for when a bulk create operation failed with potentially multiple error messages."""

    def __init__(self, errors: List[Text]) -> None:
        """Initialize bulk create exception.

        Args:
            errors: List of error messages.
        """
        super().__init__("Bulk create operation failed.")
        self.errors = errors
