from datetime import datetime, timedelta
import logging
from pathlib import Path

from croniter import croniter
import sqlalchemy
import json
from typing import Optional, Text, Dict, Any, List

from rasax.community.services.config_service import (
    ConfigKey,
    ConfigService,
    InvalidConfigValue,
    MissingConfigValue,
)
import rasax.community.utils.io
from rasax.community.services.insights.insight_calculator import (
    INTENT_REPORT_SUMMARY_KEYS,
)
from sanic.request import Request
from sqlalchemy.orm import Session

from rasax.community.services.insights import insight_calculator
from rasax.community import config as rasa_x_config
import rasax.community.constants as constants
from rasax.community.services.data_service import DataService
from rasax.community.services.tags_service import TagsService
import rasax.community.utils.common as common_utils
import rasax.community.database.utils
from rasax.community.database import (
    NLUInsightReport,
    IntentEvaluationResult,
    IntentInsight,
)
from rasax.community.database.service import DbService
from rasax.community.services.settings_service import (
    SettingsService,
    RasaXEnvironmentError,
)

from rasax.community.database.insights import (
    IntentInsightConfiguration,
    ReportStatus,
)

logger = logging.getLogger(__name__)


DEFAULT_INTENT_INSIGHT_CONFIG = {
    "schedule": "0 2 * * *",
    "cross_validation_folds": 4,
    "calculator_configuration": insight_calculator.serializable_default_config(),
}

DEFAULT_SCORECARD_INSIGHT_CONFIG = {
    "ci_runs_data_validation": False,
    "ci_trains_model": False,
    "ci_runs_rasa_test": False,
    "ci_builds_action_server": False,
    "ci_deploys_action_server": False,
    "infrastructure_as_code": False,
    "ci_runs_vulnerability_scans": False,
    "has_test_environment": False,
    "automated_conversation_tags": [],
}


CROSS_VAL_BACKGROUND_JOB_ID = "nlu-cross-validation"
MIN_TIME_IN_MINUTES_BETWEEN_CALCULATIONS = 30


class InsightCalculationInProgressException(Exception):
    """Exception raised when insight calculation is in progress."""

    def __init__(self) -> None:
        """Creates a new InsightCalculationInProgressException."""
        super().__init__(
            "Insight calculation is currently in progress. "
            "Wait for it to finish before creating a new one."
        )


class NLUInsightReportAlreadyFinishedException(Exception):
    """Exception raised when trying to finish and already finished report."""

    def __init__(self) -> None:
        """Creates a new NLUInsightReportAlreadyFinishedException."""
        super().__init__("This NLUInsightReport has already been finished.")


class RasaEvaluationResultsNotAvailable(Exception):
    """Raised if the cross-validation results are not yet available.

    This can either happen if Rasa Open Source is not yet finished with the evaluation
    or an error happened during the cross-validation.
    """

    def __init__(self) -> None:
        """Creates exception."""
        super().__init__(
            "Rasa Open Source evaluation results are not yet available. "
            "This is either because Rasa Open Source hasn't finished "
            "calculating the results yet or an error happened during "
            "calculating the cross-validation results."
        )


class InsightService(DbService):
    """A service used to work with insight calculations."""

    @staticmethod
    def from_request(request: Request, **kwargs: Any,) -> "InsightService":
        """Construct `InsightService` from an incoming HTTP request.

        Args:
            request: Incoming HTTP request.
            **kwargs: Other key-value args, not used.

        Returns:
            Constructed `InsightService` object.
        """
        return InsightService(request.ctx.db_session)

    def __init__(self, session: Session) -> None:
        """Constructor of `InsightService`.

        Args:
            session: Current DB session.
        """
        super().__init__(session)
        self.data_service = DataService(session)
        self._config_service = ConfigService(session)

    def create_nlu_insight_report(
        self, started_at_override: datetime = None
    ) -> NLUInsightReport:
        """Adds a new NLU insight report to the database.

        Args:
            started_at_override: Optional started_at time to create the report with.

        Returns:
            Created NLU insight.

        Raises:
            InsightCalculationRunningException: if an insight calculation is in progress
                and the new one cannot be created.
        """
        current = (
            self.query(NLUInsightReport)
            .filter(NLUInsightReport.finished_at == sqlalchemy.null())
            .order_by(NLUInsightReport.id.desc())
            .first()
        )

        if current:
            allow_retry = datetime.utcnow() - current.started_at > timedelta(
                minutes=MIN_TIME_IN_MINUTES_BETWEEN_CALCULATIONS
            )
            if allow_retry:
                logger.debug(
                    f"Found ongoing insight calculation with ID "
                    f"'{current.id}'. Allowing to start a new insight "
                    f"calculation as Rasa Open Source hasn't sent result in "
                    f"the last {MIN_TIME_IN_MINUTES_BETWEEN_CALCULATIONS} "
                    f"minutes."
                )
                self.finish_nlu_insight_report(
                    current.id,
                    {
                        "status": "failure",
                        "details": "New insight calculation was started before results "
                        "for this one were received.",
                    },
                )
            else:
                raise InsightCalculationInProgressException()

        nlu_insight_report = NLUInsightReport(
            started_at=started_at_override if started_at_override else datetime.utcnow()
        )
        self.add(nlu_insight_report)
        self.flush()

        return nlu_insight_report

    async def start_nlu_insight_report_process(
        self, token: Text
    ) -> Optional[Dict[Text, Any]]:
        """Creates a new NLU insight report and starts the evaluation process.

        If running in local mode, the evaluation will try to be read from file
        and the insights report will be created immediately.
        If running in server mode, a request will be sent to the Rasa API to start the
        evaluation. Once the results are returned via a callback, the report will be
        created.

        Args:
            token: A valid token to be used when calling the callback URL.

        Raises:
            InsightCalculationRunningException: if an insight calculation is in progress
                and the new one cannot be created.
            RasaXEnvironmentError: If no Rasa Open Source deployment is available which
                could execute the cross-validation (server mode only).
        """
        if rasa_x_config.LOCAL_MODE:
            return self._start_nlu_insight_report_process_local()
        else:
            return await self._start_nlu_insight_report_process_server(token)

    async def _start_nlu_insight_report_process_server(
        self, token: Text
    ) -> Optional[Dict[Text, Any]]:
        nlu_insight_report = self.create_nlu_insight_report()
        settings_service = SettingsService(self.session)
        stack_services = settings_service.stack_services()
        stack_service = stack_services.get(
            constants.RASA_WORKER_ENVIRONMENT,
            stack_services.get(constants.DEFAULT_RASA_ENVIRONMENT),
        )

        if stack_service:
            await stack_service.start_crossvalidating_nlu(
                nlu_insight_report.id,
                token,
                cross_validation_folds=self.get_cross_validation_folds(),
            )
        else:
            raise RasaXEnvironmentError(
                "No Rasa Open Source deployment was found which could execute the "
                "cross-validation."
            )

        return nlu_insight_report.as_dict(with_intent_evaluation_results=False)

    def _start_nlu_insight_report_process_local(self):
        evaluation_timestamp = self._get_timestamp_of_evaluation_files()
        if not evaluation_timestamp:
            logger.warning("No local evaluation result files found.")
            return None

        latest_nlu_report = self._get_latest_nlu_insight_report()
        if latest_nlu_report and evaluation_timestamp <= latest_nlu_report.finished_at:
            logger.warning("No new evaluation results.")
            return None

        evaluation_results = self._load_evaluation_from_files()
        nlu_insight_report = self.create_nlu_insight_report(evaluation_timestamp)
        return self.finish_nlu_insight_report(
            nlu_insight_report.id, evaluation_results, evaluation_timestamp
        )

    def _get_timestamp_of_evaluation_files(self) -> Optional[datetime]:
        from rasax.community.local import LOCAL_RESULTS_DIR

        path = Path(LOCAL_RESULTS_DIR) / "intent_report.json"
        if path.exists():
            return rasax.community.utils.io.get_file_last_modified_date(path)
        else:
            return None

    def _load_evaluation_from_files(self,) -> Dict[Text, Any]:
        from rasax.community.local import LOCAL_RESULTS_DIR

        path = Path(LOCAL_RESULTS_DIR)
        evaluation_results = {}
        for result_type in ("intent", "response_selection"):
            result_key = f"{result_type}_evaluation"
            evaluation_results[result_key] = {}

            for result_subtype in ("report", "errors"):
                file_path = path / f"{result_type}_{result_subtype}.json"
                try:
                    data = rasax.community.utils.io.read_json_file(file_path)
                except ValueError:
                    logger.warning(f"{file_path} not found.")
                    data = [] if result_subtype == "errors" else {}
                evaluation_results[result_key][result_subtype] = data

        return evaluation_results

    def _create_intent_insight(
        self, intent_evaluation_result_id: int, data: Dict[Text, Any]
    ) -> IntentInsight:
        intent_insight = IntentInsight(
            intent_evaluation_result_id=intent_evaluation_result_id,
            source=data["source"],
            details=json.dumps(data["details"]),
        )
        self.add(intent_insight)
        return intent_insight

    def finish_nlu_insight_report(
        self,
        nlu_insight_report_id: int,
        data: Dict[Text, Any],
        finished_at_override: datetime = None,
    ) -> Dict[Text, Any]:
        """Adds the insight calculations to the insight report using evaluation data.

        Args:
            nlu_insight_report_id: ID of `NLUInsightReport` to be updated.
            data: Insight evaluation data or exception details.
            finished_at_override: Optional finished_at time to create the report with.

        Returns:
            Updated NLU insight report.

        Raises:
            NLUInsightReportAlreadyFinishedException: If the report has already
             been finished
            ValueError: If a report is not found for the given ID
        """
        nlu_insight_report = self._get_nlu_insight_report_by_id_query(
            nlu_insight_report_id
        )

        if not nlu_insight_report:
            raise ValueError(
                f"Insight report with id {nlu_insight_report_id} not found"
            )

        if nlu_insight_report.finished_at is not None:
            raise NLUInsightReportAlreadyFinishedException()

        # Wrap everything in a big `try ... except` block to avoid not marking the
        # report as finished in case an error happens now. This would otherwise lead
        # to an infinitely pending evaluation.
        try:
            self._update_report_using_cross_validation_results(nlu_insight_report, data)
            nlu_insight_report.status = ReportStatus.SUCCESS
        except Exception as e:
            nlu_insight_report.status = ReportStatus.FAILURE
            logger.warning(
                f"Intent Insight Calculation failed due to error. Details:\n{e}"
            )
        finally:
            nlu_insight_report.finished_at = (
                finished_at_override if finished_at_override else datetime.utcnow()
            )

        self.add(nlu_insight_report)
        return nlu_insight_report.as_dict(with_intent_evaluation_results=False)

    def _update_report_using_cross_validation_results(
        self, report: NLUInsightReport, data: Dict[Text, Any]
    ) -> None:
        report.evaluation_payload = json.dumps(data)

        if data.get("status") == "failure":
            raise ValueError(
                f"Evaluation response contained an exception. "
                f"Skipping the insight calculation, finishing the report "
                f"and saving the error details. The full error payload is:\n"
                f"{json.dumps(data)}"
            )

        report.intent_evaluation_results = self._evaluations_with_insights(data)

    def _evaluations_with_insights(
        self, rasa_evaluation_result: Dict[Text, Any]
    ) -> List[IntentEvaluationResult]:
        (
            intent_insights,
            retrieval_intent_insights,
        ) = insight_calculator.calculate_insights(
            self.session,
            rasa_evaluation_results=rasa_evaluation_result,
            calculator_config=self._get_calculator_configuration(),
        )

        intent_evaluations = self._intent_evaluations(
            rasa_evaluation_result, "intent_evaluation", intent_insights
        )

        retrieval_evaluations = self._intent_evaluations(
            rasa_evaluation_result,
            "response_selection_evaluation",
            retrieval_intent_insights,
        )

        return intent_evaluations + retrieval_evaluations

    def _intent_evaluations(
        self,
        rasa_evaluation_result: Dict[Text, Any],
        evaluation_key: Text,
        insights: Dict[Text, List[IntentInsight]],
    ) -> List[IntentEvaluationResult]:
        report = rasa_evaluation_result.get(evaluation_key, {}).get("report", {})
        return [
            IntentEvaluationResult(
                intent_name=intent_name,
                f1_score=intent_report["f1-score"],
                precision=intent_report["precision"],
                recall=intent_report["recall"],
                number_of_training_examples=intent_report["support"],
                intent_insights=insights.get(intent_name, []),
            )
            for intent_name, intent_report in report.items()
            if intent_name not in INTENT_REPORT_SUMMARY_KEYS
        ]

    def get_nlu_insight_report_full_by_id(
        self,
        insight_report_id: int,
        project_id: Text,
        text_query: Optional[Text] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort_by: Optional[Text] = None,
        sort_order: Optional[Text] = None,
    ) -> common_utils.QueryResult:
        """Returns `NLUInsightReport` with evaluation results and insights.

        The parameters query, limit, offset, sort_by and sort_order apply to
        the IntentEvaluationResults that are associated with the report

        Args:
            insight_report_id: ID of the insight report.
            project_id: ID of the project.
            text_query: Text query to filter intents.
            limit: Maximum number of intents to be retrieved.
            offset: Excludes the first ``offset`` intents from the result.
            sort_by: Field to which sort results by.
            sort_order: Order in which results should be returned in, ascending or
                descending.

        Returns:
            `IntentEvaluationResult`s with total number of intents found.

        Raises:
            ValueError: If an invalid sort column is given.
        """
        insight_report = self.get_nlu_insight_report_by_id(insight_report_id)

        if not insight_report:
            return common_utils.QueryResult([], 0)

        query = self.query(IntentEvaluationResult).filter(
            IntentEvaluationResult.nlu_insight_report_id == insight_report["id"]
        )

        if text_query:
            query = query.filter(
                IntentEvaluationResult.intent_name.ilike(f"%{text_query}%")
            )

        sort_column = IntentEvaluationResult.__table__.columns.get(sort_by or "id")
        if sort_column is None:
            raise ValueError(f"Invalid column '{sort_by}' for IntentEvaluationResult.")

        query = query.order_by(
            sort_column.desc() if sort_order == "desc" else sort_column.asc()
        )

        count = query.count()

        if limit:
            query = query.limit(limit)
        if offset:
            query = query.offset(offset)

        insight_report["intent_evaluation_results"] = [
            intent.as_dict() for intent in query.all()
        ]
        return common_utils.QueryResult(insight_report, count)

    def get_nlu_insight_report_by_id(
        self, nlu_insight_report_id: int
    ) -> Optional[Dict[Text, Any]]:
        """Gets `NLUInsightReport` by ID.

        Args:
            nlu_insight_report_id: ID of the insight report.

        Return:
            Report without the intents results or insights.
        """
        report = self._get_nlu_insight_report_by_id_query(nlu_insight_report_id)
        if report:
            return report.as_dict(with_intent_evaluation_results=False)
        else:
            return None

    def _get_nlu_insight_report_by_id_query(
        self, nlu_insight_report_id: int
    ) -> Optional[NLUInsightReport]:
        return (
            self.query(NLUInsightReport)
            .filter(NLUInsightReport.id == nlu_insight_report_id)
            .one_or_none()
        )

    def get_rasa_open_source_evaluation_result_for_report(
        self, report_id: int
    ) -> Dict[Text, Any]:
        """Gets the Rasa Open Source evaluation payload for the report.

        Args:
            report_id: The ID of the report for which the evaluation was created.

        Returns:
            Rasa Open Source evaluation results. Report is in the same format as the
            Rasa Open Source endpoint `POST /model/test/intents` provides.

        Raises:
            ValueError: If no report with this ID exists.
            InsightCalculationInProgressException: If evaluation is still in progress
                and we haven't obtained the cross-validation results yet.
        """
        report = self._get_nlu_insight_report_by_id_query(report_id)
        if not report:
            raise ValueError(f"No evaluation report for ID '{report_id}' found.")

        if not report.evaluation_payload:
            raise RasaEvaluationResultsNotAvailable()

        return json.loads(report.evaluation_payload)

    def _get_latest_nlu_insight_report(self) -> Optional[NLUInsightReport]:
        return (
            self.query(NLUInsightReport)
            .filter(NLUInsightReport.finished_at != sqlalchemy.null())
            .order_by(NLUInsightReport.finished_at.desc())
            .first()
        )

    def get_nlu_insight_reports(
        self,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort_order: Optional[Text] = None,
        report_status: Optional[ReportStatus] = None,
    ) -> common_utils.QueryResult:
        """Gets `NLUInsightReports`.

        Args:
            limit: Maximum number of reports to be retrieved.
            offset: Excludes the first `offset` reports from the result.
            sort_order: Order in which results should be returned in, ascending or
                descending by `id`.
            report_status: If not `None`, return only reports matching the status.

        Return:
            All paginated reports and the total number of reports.
        """
        query = self.query(NLUInsightReport).order_by(
            NLUInsightReport.id.desc()
            if sort_order == "desc"
            else NLUInsightReport.id.asc()
        )

        if report_status:
            query = query.filter(NLUInsightReport.status == report_status)

        if limit:
            query = query.limit(limit)
        if offset:
            query = query.offset(offset)

        results = [
            report.as_dict(with_intent_evaluation_results=False)
            for report in query.all()
        ]

        return common_utils.QueryResult(results, len(results))

    def update_config(self, config: Dict[Text, Any]) -> None:
        """Updates the intent insight config.

        Args:
            config: The new config.

        Raises:
            ValueError: If config items are invalid.
        """
        current_config = self.query(IntentInsightConfiguration).one_or_none()
        if not current_config:
            current_config = IntentInsightConfiguration()

        schedule = config.get("schedule")
        if schedule and not croniter.is_valid(schedule):
            raise ValueError("Incorrect cron format")
        current_config.schedule = schedule

        self._update_cross_validation_schedule(schedule)

        current_config.cross_validation_folds = config.get("cross_validation_folds")

        calculator_config = config.get("calculator_configuration")
        insight_calculator.validate_calculator_config(calculator_config)
        current_config.calculator_configuration = json.dumps(calculator_config)

        self.add(current_config)

    @staticmethod
    def _update_cross_validation_schedule(new_schedule: Optional[Text]) -> None:
        if rasa_x_config.LOCAL_MODE:
            # Users have to provide the cross validations result on disk in local mode
            return

        import rasax.community.scheduler  # Local import to avoid cyclic import

        if new_schedule:
            rasax.community.scheduler.reschedule_job(
                CROSS_VAL_BACKGROUND_JOB_ID, new_schedule=new_schedule
            )
        else:
            rasax.community.scheduler.cancel_job(CROSS_VAL_BACKGROUND_JOB_ID)

    def get_config(self) -> Dict[Text, Any]:
        """Gets the current intent insight config."""
        config = self.query(IntentInsightConfiguration).one_or_none()
        if not config:
            return DEFAULT_INTENT_INSIGHT_CONFIG

        return {
            "schedule": config.schedule,
            "cross_validation_folds": config.cross_validation_folds,
            "calculator_configuration": json.loads(config.calculator_configuration),
        }

    def _get_calculator_configuration(self) -> Dict[Text, Any]:
        return self.get_config()["calculator_configuration"]

    def get_cross_validation_schedule(self) -> Optional[Text]:
        """Returns the crontab which determines runtimes for the cross-validation."""
        return self.get_config()["schedule"]

    def get_cross_validation_folds(self) -> int:
        """Returns the number of folds for the cross-validation."""
        return self.get_config()["cross_validation_folds"]

    @staticmethod
    def run_scheduled_calculation() -> None:
        """Triggers the regular cross-validation runs.

        The result from the cross-validation is used to calculate the intent insights.
        """
        with rasax.community.database.utils.session_scope() as session:
            service = InsightService(session)
            common_utils.run_in_loop(
                service.start_nlu_insight_report_process(rasa_x_config.rasa_x_token)
            )

    def clean_scorecard_config_tags(self, config: Dict[Text, Any]) -> Dict[Text, Any]:
        """Clean tags normalised into a scorecard config.

        If any tags no longer exist, remove them.
        """
        with rasax.community.database.utils.session_scope() as session:
            tags_service = TagsService(session)
            existing_tags = {tag.get("id") for tag in tags_service.get_all_data_tags()}

            config["automated_conversation_tags"] = [
                tag
                for tag in config["automated_conversation_tags"]
                if tag.get("id") in existing_tags
            ]
            return config

    def update_scorecard_config(self, config: Dict[Text, Any]) -> None:
        """Updates the scorecard config.

        Args:
            config: The new config.

        Raises:
            ValueError: If config items are invalid.
        """
        try:
            # makes sure all keys are present
            full_config = DEFAULT_SCORECARD_INSIGHT_CONFIG.copy()
            full_config.update(config)
            full_config = self.clean_scorecard_config_tags(full_config)
            self._config_service.set_value(
                ConfigKey.SCORECARD_CONFIGURATION, full_config
            )
        except InvalidConfigValue:
            logger.warning(
                "Failed to set scorecard configuration. Passed "
                "configuration is not valid JSON."
            )

    def get_scorecard_config(self) -> Dict[Text, Any]:
        """Gets the current intent insight config."""
        try:
            stored_config = self._config_service.get_value(
                ConfigKey.SCORECARD_CONFIGURATION, expected_type=dict
            )
            # make sure all configuration keys are present. if they are not set,
            # default values will be used
            full_config = DEFAULT_SCORECARD_INSIGHT_CONFIG.copy()
            full_config.update(stored_config)
            full_config = self.clean_scorecard_config_tags(full_config)
            return full_config
        except (InvalidConfigValue, MissingConfigValue):
            return DEFAULT_SCORECARD_INSIGHT_CONFIG
