import asyncio
import dataclasses
import datetime
import glob
import logging
import os
import shutil
import tarfile

import tarsafe
import tempfile
import ctypes
from multiprocessing import context
from pathlib import Path
from typing import Optional, Text, Dict, Any, List, Union, TYPE_CHECKING

from aiohttp import ClientConnectorError
from packaging import version
from sanic.request import Request, File
from sqlalchemy import and_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

import rasax.community.config as rasa_x_config
import rasax.community.constants as constants
import rasax.community.utils.cli as cli_utils
import rasax.community.utils.common as common_utils
import rasax.community.utils.http as http_utils
import rasax.community.utils.io as io_utils
import rasax.community.utils.yaml as yaml_utils
from rasax.community.database.model import (
    Model,
    ModelTag,
    ModelTrainingJob,
    TrainingStatus,
)
from rasax.community.database.service import DbService

if TYPE_CHECKING:
    from multiprocessing.sharedctypes import _Value


logger = logging.getLogger(__name__)

RASA_2_METADATA_FILE = "fingerprint.json"
RASA_3_METADATA_FILE = "metadata.json"

# We use this to not serve any models to Rasa Open Source until we successfully
# validated (e.g. minimum compatible version) the models.
were_models_discovered: Optional["_Value"] = None


def initialize_global_state(mp_context: context.BaseContext) -> None:
    """Initialize the global state of the module.

    Args:
        mp_context: The current multiprocessing context.
    """
    global were_models_discovered
    were_models_discovered = mp_context.Value(ctypes.c_bool, False)


def _model_discovery_completed() -> bool:
    """Determines whether or not the model discovery has been completed.

    Returns:
        `True` if Rasa X is configured to not wait for the model discovery, or if
        model discovery has finished, `False` otherwise.
    """
    if not rasa_x_config.wait_for_model_discovery:
        logger.debug("Skip waiting for model discovery.")
        return True

    if were_models_discovered and were_models_discovered.value:
        logger.debug("Model discovery completed.")
        return True

    logger.debug("Model discovery not completed.")
    return False


@dataclasses.dataclass
class ModelMetadata:
    """Metadata about a Rasa Open Source model on disk."""

    model_version: Text
    trained_at: datetime.datetime
    model_file_hash: Text

    @property
    def trained_at_as_string(self) -> Optional[Text]:
        """Returns the model training time as string."""
        return self.trained_at.strftime("%Y%m%d-%H%M%S")


class ModelService(DbService):
    """Handles the interaction with Rasa Open Source models."""

    def __init__(
        self,
        model_directory: Text,
        session: Session,
        environment: Text = constants.DEFAULT_RASA_ENVIRONMENT,
    ) -> None:
        """Creates service.

        Args:
            model_directory: The location on disk where new model packages are stored.
            session: The current database session.
            environment: The Rasa Open Source deployment environment which is used
                to check whether a model is compatible with the deployed Rasa Open
                Source services.
        """
        self.model_directory = model_directory
        self.environment = environment
        super().__init__(session)

    async def mark_latest_as_production(
        self, project: Text = rasa_x_config.project_name
    ):
        """Mark latest model as using production environment."""
        if self.model_for_tag(project, constants.RASA_PRODUCTION_ENVIRONMENT):
            # don't tag a model as production if there is already another tagged model
            return

        latest = self.latest_model(project)

        if latest:
            try:
                await self.tag_model(
                    latest.project_id,
                    latest.name,
                    constants.RASA_PRODUCTION_ENVIRONMENT,
                )
            except ValueError:
                logger.debug(
                    "Latest model could not be tagged since it is not compatible."
                )

    def latest_model(self, project: Text) -> Optional[Model]:
        """Return the latest model."""
        return (
            self.query(Model)
            .filter(Model.project_id == project)
            .order_by(Model.trained_at.desc())
            .first()
        )

    async def discover_models(
        self, max_retries: int = 10, sleep_in_seconds: int = 2
    ) -> None:
        """Synchronize model metadata with models stored on disk.

        Args:
            max_retries: In server mode, try repeatedly in case the Rasa server is not
                yet up.
            sleep_in_seconds:  In server mode, wait a specific time between the retries.

        """

        async def _run_loop(_max_retries, _sleep_in_seconds):
            # runs model discovery in loop for `max_retries` attempts
            while _max_retries:
                try:
                    logger.debug("ModelService._discover_models awaiting start.")
                    await self._discover_models()
                    logger.debug("ModelService._discover_models awaiting end.")
                    return
                except ClientConnectorError:
                    _max_retries -= 1
                    logger.debug(
                        f"ModelService._discover_models attempt#{max_retries - _max_retries} failed."
                    )
                    logger.debug(f"Sleeping for '{_sleep_in_seconds}' start.")
                    await asyncio.sleep(_sleep_in_seconds)
                    logger.debug(f"Sleeping for '{_sleep_in_seconds}' end.")
                    # Increment sleep after each iteration in server mode as the
                    # rasa-production service might take a while to come up.
                    # This is not necessary in local mode due to faster startup
                    # times.
                    if not rasa_x_config.LOCAL_MODE:
                        _sleep_in_seconds += 2

            logger.warning("Could not run model discovery.")

        logger.debug("ModelService.discover_models._run_loop awaiting start.")
        await _run_loop(max_retries, sleep_in_seconds)
        logger.debug("ModelService.discover_models._run_loop awaiting end.")
        self._mark_model_discovery_as_finished()

    @staticmethod
    def _mark_model_discovery_as_finished() -> None:
        logger.debug("Changing were_models_discovered to True.")
        with were_models_discovered.get_lock():
            were_models_discovered.value = True
            logger.debug("Changed were_models_discovered to True.")

    async def minimum_compatible_version(self) -> Optional[Text]:
        """Get the minimum compatible version of the model for the Rasa Open Source."""
        from rasax.community.services.settings_service import SettingsService

        settings_service = SettingsService(self.session)
        stack_service = settings_service.get_stack_service(self.environment)

        logger.debug(
            "ModelService.minimum_compatible_version.stack_service.version awaiting start."
        )
        info = await stack_service.version()
        logger.debug(
            "ModelService.minimum_compatible_version.stack_service.version awaiting end."
        )

        if info:
            minimum_compatible_version = info.get("minimum_compatible_version")
            logger.debug(
                f"Minimum compatible version found: {minimum_compatible_version}"
            )
            return minimum_compatible_version
        else:
            logger.debug("Couldn't get a minimum compatible model version.")
            return None

    async def _retry_fetching_minimum_compatible_version(
        self,
        attempts: int = 20,
        sleep_between_retries_in_seconds: Union[int, float] = 0.5,
    ) -> Optional[Text]:
        minimum_version = None
        while attempts > 0:
            try:
                minimum_version = await self.minimum_compatible_version()
            # Using very broad exception since it's not clear what can go wrong:
            # - request can time out
            # - some borken connection
            # - other networking issues
            # And asyncio doesn't seem to have a general Exception subclass.
            except Exception as e:
                logger.debug(
                    f"Error trying to get minimum compatible version, error: {e}"
                )
            if minimum_version:
                break
            await asyncio.sleep(sleep_between_retries_in_seconds)
            attempts -= 1

        return minimum_version

    async def _discover_models(
        self, project_id: Text = rasa_x_config.project_name
    ) -> None:
        logger.debug("Fetching the minimum compatible version.")
        minimum_version = await self._retry_fetching_minimum_compatible_version()
        logger.debug(f"Minimum version: '{minimum_version}'")

        available_model_names = []
        for path in glob.glob(os.path.join(self.model_directory, "*.tar.gz")):
            logger.debug("Found a model file.")

            metadata = self.get_model_metadata(path)

            logger.debug(f"Version: '{metadata.model_version}.'")

            logger.debug("Checking compatibility.")
            is_compatible = self.is_model_compatible(
                minimum_version, model_version=metadata.model_version
            )
            logger.debug(f"Compatible: '{is_compatible}.'")

            if not is_compatible:
                cli_utils.print_warning(
                    f"Version of model {os.path.basename(path)} version is not "
                    f"compatible. "
                    f"The model was trained with Rasa version {metadata.model_version} "
                    f"but the current Rasa requires a minimum version of "
                    f"{minimum_version}. "
                    f"Please retrain your model with a more recent Rasa "
                    f"version."
                )

            filename: Text = os.path.basename(path)

            model_name = filename.split(".tar.gz")[0]
            logger.debug(f"Model name: '{model_name}'.")

            available_model_names.append(model_name)
            existing_model = self._get_model_by_name(project_id, model_name)

            if not existing_model:
                logger.debug(f"Importing model '{model_name}'.")
                _ = await self.add_model(project_id, model_name, path)
                logger.debug(f"Imported model '{model_name}'.")
            elif not is_compatible:
                # Delete all tags from existing incompatible model
                existing_model.tags = []
                logger.info(
                    f"Deleting all tags from model '{existing_model.name}' since its "
                    f"current version {existing_model.version} does not suffice the "
                    f"minimum compatible version {minimum_version}."
                )

        logger.debug(
            "model_service._discover_models.delete_not_existing_models_from_db start."
        )
        self.delete_not_existing_models_from_db(project_id, available_model_names)
        logger.debug(
            "model_service._discover_models.delete_not_existing_models_from_db end."
        )

    def delete_not_existing_models_from_db(
        self, project_id: Text, available_models: List[Text]
    ):
        """Delete models from the database which are not available on disk."""
        for m in available_models:
            logger.debug(f"Available model: '{m}'.")

        self.query(Model)
        old_models_in_db = (
            self.query(Model)
            .filter(Model.project_id == project_id, Model.name.notin_(available_models))
            .all()
        )

        for m in old_models_in_db:
            logger.info(
                "Deleting model '{}' from database since it could not be found "
                "on disk.".format(m.name)
            )
            self.delete(m)

    @staticmethod
    def _model_name_from_path(path: Text) -> Text:
        # noinspection PyTypeChecker
        return os.path.basename(path).split(".tar.gz")[0]

    async def save_trained_model(self, project: Text, content: bytes) -> Optional[Text]:
        """Store model trained through Rasa X on disk and its metadata in database."""
        model_path = self._store_trained_model_on_disk(content)
        if not model_path:
            return None

        model_name = self._model_name_from_path(model_path)
        await self.add_model(project, model_name=model_name, path=model_path)

        return model_name

    def _store_trained_model_on_disk(self, content: bytes) -> Optional[Text]:
        # save model at temporary location to extract metadata timestamp
        temp_model_path = io_utils.create_temporary_file(data=content, mode="w+b")
        metadata = self.get_model_metadata(temp_model_path)

        # move model to permanent location
        return self._store_zipped_model(
            model_name=metadata.trained_at_as_string, file_path=temp_model_path
        )

    async def save_uploaded_model(
        self, project: Text, model_name: Text, path: Text
    ) -> Optional[Dict[Text, Any]]:
        """Store an uploaded model on disk and its metadata in the database.

        IMPORTANT: the `path` needs to be "safe", e.g. if it is
        a user input it needs to be ensured that it doesn't contain
        malicious names (`../../../.ssh/id_rsa`).
        """
        if not os.path.isfile(path):
            raise Exception("Can only handle model files, no dirs.")

        path = os.path.abspath(path)
        if path.startswith(os.path.abspath(self.model_directory)):
            # no need to move model already in model directory
            stored_path = path
        else:
            stored_path = self._store_zipped_model(model_name, path)
            logger.debug(f"Saved zipped model file at '{stored_path}'.")

        return await self.add_model(project, model_name, stored_path)

    async def add_model(
        self, project: Text, model_name: Text, path: Text
    ) -> Optional[Dict[Text, Any]]:
        """Try to add a model to the database."""
        try:
            metadata = self.get_model_metadata(path)

            new_model = self._save_model_data(
                project,
                model_name,
                path,
                metadata.model_file_hash,
                metadata.model_version,
                metadata.trained_at.timestamp(),
            )

            # in server mode, inject domain and training data from first model
            await self.inject_data_from_first_model(project, path)
            return new_model

        except IntegrityError as ex:
            logger.debug(f"Model {model_name} already exists: {ex}")
            return self.get_model_by_name(project, model_name)

    @staticmethod
    def get_model_server_url(tag: Text = constants.DEFAULT_RASA_ENVIRONMENT) -> Text:
        """Creates the model server url for a given tag."""
        model_server_url = http_utils.concat_url(
            rasa_x_config.self_url, "/api/models/tags/{}"
        )

        return model_server_url.format(tag)

    async def _inject_domain_from_model(self, project: Text, domain_path: Text) -> None:
        from rasax.community.services.domain_service import DomainService

        domain_service = DomainService(self.session)

        # do not inject if domain_service already contains a domain
        if domain_service.has_non_empty_domain(project):
            return

        from rasax.community.services.nlg_service import NlgService

        data = yaml_utils.read_yaml_file(domain_path)

        # store responses if no responses found in NLG service
        _, number_of_responses = NlgService(self.session).fetch_responses()
        should_store_responses = number_of_responses == 0

        domain_service.create_domain(
            data,
            project,
            username=rasa_x_config.SYSTEM_USER,
            filename=Path(domain_path).name,
            store_responses=should_store_responses,
            # responses injected by a model were already included in a training
            have_responses_been_edited=False,
        )

    async def inject_data_from_first_model(self, project: Text, path: Text) -> None:
        """Inject domain into db from first model if in server mode."""
        # skip if in local mode or there already exists a model in db
        if rasa_x_config.LOCAL_MODE or (await self.get_models(project))[1] > 0:
            return

        unpacked_model_path = io_utils.unpack_file(path)

        # inject domain
        domain_path = os.path.join(unpacked_model_path, "core", "domain.yml")
        await self._inject_domain_from_model(project, domain_path)

    @staticmethod
    def save_model_to_disk(req: Request) -> Text:
        """Saves a model to the filesystem.

        Args:
            req: Incoming HTTP request.

        Response:
            Path to saved model.
        """
        rfiles = req.files

        if "model" not in rfiles or not len(rfiles["model"]):
            raise FileNotFoundError("No `model` file found.")

        _file = rfiles["model"][0]  # type: File
        filename = common_utils.secure_filename(_file.name)
        if not filename.endswith(".tar.gz"):
            raise TypeError("No `.tar.gz` file found.")

        return io_utils.write_request_file_to_disk(_file, filename)

    def _store_zipped_model(self, model_name, file_path):
        """Moves a zipped model from a temporary to a permanent location."""
        zpath = self._create_model_save_path(model_name)

        if os.path.exists(zpath):
            raise FileExistsError(zpath)

        shutil.move(file_path, zpath)
        return zpath

    def _create_model_save_path(self, model_name: Text) -> Text:
        """Creates a directory to save the model at.

        Example: /app/core-projects/default/models/my_model.tar.gz

        Args:
            model_name: Name of the model to be saved.

        Returns:
            The path at which the model is to be saved.

        """
        if not os.path.isdir(self.model_directory):
            os.makedirs(self.model_directory)
        return os.path.join(self.model_directory, model_name + ".tar.gz")

    def is_model_compatible(
        self,
        minimum_compatible_version: Text,
        fpath: Optional[Text] = None,
        model_version: Optional[Text] = None,
    ) -> bool:
        """Checks if a model on disk is compatible with the connected NLU."""
        if not model_version and fpath and Path(fpath).is_file():
            # TODO: Test
            metadata = self.get_model_metadata(fpath)
            model_version = metadata.model_version

        return (
            model_version is not None
            and minimum_compatible_version is not None
            and version.parse(model_version)
            >= version.parse(minimum_compatible_version)
        )

    def _save_model_data(
        self,
        project: Text,
        model: Text,
        stored_path: Text,
        model_hash: Text,
        _version: Text,
        training_time: float,
    ) -> Dict[Text, Any]:
        model = Model(
            hash=model_hash,
            name=model,
            path=stored_path,
            project_id=project,
            version=_version,
            trained_at=training_time,
        )
        self.add(model)

        return model.as_dict()

    async def tag_model(
        self, project: Text, model_name: Text, tag: Text
    ) -> Dict[Text, Any]:
        """Tag a model if it's compatible.

        Args:
            project: Project the model belongs to.
            model_name: Name of the model which should be tagged.
            tag: Tag which this model should get.

        Returns:
            Tagged model.

        """
        model = (
            self.query(Model)
            .filter(and_(Model.project_id == project, Model.name == model_name))
            .first()
        )

        if not model:
            raise ValueError(
                f"Model '{model_name}' was not found for project '{project}'."
            )

        min_compatible_version = await self.minimum_compatible_version()

        if not self.is_model_compatible(
            min_compatible_version, model_version=model.version
        ):
            raise ValueError(
                "Model '{}' cannot be tagged since its version {} is lower than the "
                "minimum required version ({}).".format(
                    model_name, model.version, min_compatible_version
                )
            )

        self._remove_tag_from_all_models(project, tag)

        tag = ModelTag(tag=tag)
        model.tags.append(tag)

        logger.debug(f"Tagged model '{model_name}' as '{tag}'.")

        return model.as_dict()

    def _remove_tag_from_all_models(self, project: Text, tag: Text) -> None:
        model = (
            self.query(Model)
            .join(ModelTag)
            .filter(and_(Model.project_id == project, ModelTag.tag == tag))
            .first()
        )

        if model:
            self.query(ModelTag).filter(
                and_(ModelTag.tag == tag, ModelTag.model_id == model.id)
            ).delete()

    def delete_model(self, project: Text, model_name: Text) -> Dict[Text, Any]:
        """Delete entry and remove model from path."""
        to_delete = (
            self.query(Model)
            .filter(and_(Model.name == model_name, Model.project_id == project))
            .first()
        )

        if to_delete:
            if os.path.exists(to_delete.path):
                os.remove(to_delete.path)

            self.delete(to_delete)

            return to_delete.as_dict()
        else:
            logger.warning(f"Model '{model_name}' was already removed from database.")
            return {}

    def model_for_tag(self, project: Text, tag: Text) -> Optional[Dict[Text, Any]]:
        """Try to get the model by tag."""
        logger.debug("Checking the model discovery from model_for_tag.")
        if not _model_discovery_completed():
            return None

        model = (
            self.query(Model)
            .join(ModelTag)
            .filter(and_(ModelTag.tag == tag, Model.project_id == project))
            .first()
        )
        return model.as_dict() if model else None

    def get_model_by_name(
        self, project: Text, model_name: Text
    ) -> Optional[Dict[Text, Any]]:
        """Try to get the model by name."""
        logger.debug("Checking the model discovery from get_model_by_name.")
        if not _model_discovery_completed():
            return None

        model = self._get_model_by_name(project, model_name)

        return model.as_dict() if model else None

    def _get_model_by_name(self, project: Text, model_name: Text) -> Optional[Model]:
        """Return a model by name.

        Args:
            project: Project the model should belong to.
            model_name: The name the model should have.

        Returns:
            A model if one was found or `None` otherwise.
        """
        return (
            self.query(Model)
            .filter(and_(Model.project_id == project, Model.name == model_name))
            .first()
        )

    def delete_tag(self, project: Text, model_name: Text, tag: Text) -> None:
        """Delete model tag."""
        model = (
            self.query(Model)
            .filter(
                Model.project_id == project,
                Model.name == model_name,
                Model.tags.any(ModelTag.tag == tag),
            )
            .first()
        )

        if not model:
            raise ValueError(f"No model '{model_name}' found for project '{project}'.")

        for t in model.tags:
            if t.tag == tag:
                self.delete(t)

    @staticmethod
    def get_model_metadata(path: Text) -> ModelMetadata:
        """Retrieve model metadata for file at `path`."""
        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                with tarsafe.open(path) as tar:
                    tar.extractall(temp_dir)

                rasa_2_metadata_file = Path(temp_dir, RASA_2_METADATA_FILE)
                file_hash = common_utils.get_text_hash(
                    io_utils.read_file_as_bytes(path)
                )

                if rasa_2_metadata_file.exists():
                    return ModelService._extract_rasa_2_model_metadata(
                        file_hash, rasa_2_metadata_file
                    )

                metadata_file = Path(temp_dir, RASA_3_METADATA_FILE)
                return ModelService._extract_rasa_3_model_metadata(
                    file_hash, metadata_file
                )

        except (
            tarfile.ReadError,
            tarsafe.TarSafeException,
            FileNotFoundError,
            ValueError,
            KeyError,
        ) as e:
            logger.error(f"Failed to retrieve metadata from model at '{path}': {e}.")
            raise ValueError(
                f"Failed to retrieve metadata from model at '{path}'."
            ) from e

    @staticmethod
    def _extract_rasa_3_model_metadata(
        file_hash: Text, metadata_file: Path
    ) -> ModelMetadata:
        metadata = io_utils.read_json_file(metadata_file)
        return ModelMetadata(
            model_version=metadata["rasa_open_source_version"],
            trained_at=datetime.datetime.fromisoformat(metadata["trained_at"]).replace(
                tzinfo=datetime.timezone.utc
            ),
            model_file_hash=file_hash,
        )

    @staticmethod
    def _extract_rasa_2_model_metadata(
        file_hash: Text, rasa_2_metadata_file: Path
    ) -> ModelMetadata:
        metadata = io_utils.read_json_file(rasa_2_metadata_file)
        return ModelMetadata(
            model_version=metadata["version"],
            trained_at=datetime.datetime.fromtimestamp(
                float(metadata["trained_at"]), tz=datetime.timezone.utc
            ),
            model_file_hash=file_hash,
        )

    async def get_models(
        self,
        project_id: Text,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        tag: Optional[Text] = None,
    ) -> common_utils.QueryResult:
        """Retrieve models.

        Args:
            project_id: The project which the data belongs to.
            limit: A maximum number of models to return.
            offset: Return models after the `offset`th row in the database.
            tag: Return only those models that have the specified `tag`.

        Returns:
            The paginated models matching the given query and the total
            number of results for the given query.
        """
        models = self.query(Model).filter(Model.project_id == project_id)

        if tag:
            models = models.filter(Model.tags.any(ModelTag.tag == tag))

        total_number_models = models.count()

        # Order by name and trained at in case two models were trained at the same time
        models = (
            models.order_by(Model.trained_at.desc(), Model.name.asc())
            .offset(offset)
            .limit(limit)
            .all()
        )

        minimum_compatible_version = await self.minimum_compatible_version()

        out = []
        for m in models:
            model_version = m.version
            model = m.as_dict()
            model["is_compatible"] = self.is_model_compatible(
                minimum_compatible_version, model_version=model_version
            )
            out.append(model)

        return common_utils.QueryResult(out, total_number_models)

    def get_model_count(self) -> int:
        """Returns the number of models available."""
        return self.query(Model).count()

    @staticmethod
    def extract_domain_from_model(
        model_path: Text,
    ) -> Optional[Union[List[Any], Dict[Text, Any]]]:
        """Extract Domain from model data given path."""
        temp_model_dir = io_utils.unpack_file(model_path)
        domain_path = os.path.join(
            temp_model_dir, "core", constants.DEFAULT_RASA_DOMAIN_PATH
        )

        try:
            return yaml_utils.read_yaml_file(domain_path)
        except (FileNotFoundError, UnicodeDecodeError) as e:
            logger.error(
                "Could not read domain file for model at "
                "'{}'. Details:\n{}".format(model_path, e)
            )
        finally:
            shutil.rmtree(temp_model_dir, ignore_errors=True)

        return None

    @staticmethod
    def from_request(
        model_directory: Text,
        request: Request,
        environment: Text = constants.DEFAULT_RASA_ENVIRONMENT,
        **kwargs,
    ) -> "ModelService":
        """Constructs a `ModelService` from an incoming HTTP request.

        Args:
            model_directory: Path to the directory containing the models.
            request: Incoming HTTP request.
            environment: The environment of the current Rasa X instance, i.e. production, worker or development.
            **kwargs: other key-value args, not used.

        Returns:
            Constructed `ModelService` object.
        """
        return ModelService(model_directory, request.ctx.db_session, environment)

    def get_training_job(self, job_id: Any) -> Optional[ModelTrainingJob]:
        """Get Model Training job by id.

        Args:
            job_id: ID of the Model Training job.

        Return:
            ModelTrainingJob or `None` if none could be found with the given ID.
        """
        try:
            lookup_id = int(job_id)
            return self.query(ModelTrainingJob).get(lookup_id)
        except (AttributeError, ValueError, TypeError):
            return None

    def update_training_job(
        self, job_id: Any, status: TrainingStatus, details: Text,
    ) -> Dict[Text, Any]:
        """Updates a Model Training job.

        Args:
            job_id: A Model Training job id.
            status: status of the model training.
            details: relevant data regarding model training.

        Returns:
            Updated `ModelTrainingJob`.
        """
        job = self.get_training_job(job_id)

        if job is None:
            raise ValueError("Could not find model training job with given ID")

        job.status = status
        job.details = details
        job.finished_at = datetime.datetime.utcnow()

        return job.as_dict()

    def add_training_job(self, initiator: Text) -> Dict[Text, Any]:
        """Adds a Model Training job.

        Args:
            initiator: The websocket recipient.

        Returns:
            `ModelTrainingJob`.
        """
        job = ModelTrainingJob(initiated_by=initiator)
        self.session.add(job)
        self.session.flush()
        return job.as_dict()


async def discover_models() -> None:
    """Synchronize model metadata with models stored on disk."""
    from rasax.community.database import utils as db_utils

    logger.debug(f"discover_models LOCAL_MODE='{rasa_x_config.LOCAL_MODE}'")
    if rasa_x_config.LOCAL_MODE:
        from rasax.community.local import LOCAL_MODELS_DIR

        model_directory = LOCAL_MODELS_DIR
    else:
        model_directory = rasa_x_config.rasa_model_dir

    with db_utils.session_scope() as session:
        model_service = ModelService(
            model_directory, session, constants.DEFAULT_RASA_ENVIRONMENT
        )
        logger.debug("ModelService.discover_models awaiting start.")
        await model_service.discover_models()
        logger.debug("ModelService.discover_models awaiting end.")

        if rasa_x_config.LOCAL_MODE:
            await model_service.mark_latest_as_production()
