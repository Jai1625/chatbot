import json
import logging
from typing import Dict, Text, Any, Optional, Union, List

import typing
from ruamel.yaml.compat import ordereddict
from sanic.request import Request
from sqlalchemy import and_
from sqlalchemy.orm import Session

import rasax.community.config as rasa_x_config
import rasax.community.constants as constants
import rasax.community.utils.cli as cli_utils
import rasax.community.utils.config as config_utils
import rasax.community.utils.io as io_utils
import rasax.community.utils.yaml as yaml_utils
from rasax.community.database.admin import Environment, Project
from rasax.community.database.service import DbService
from rasax.community.services import background_dump_service
from rasax.community.services.data_service import DataService
from rasax.community.services.domain_service import DomainService
from rasax.community.services.story_service import StoryService
from rasax.community.services.license_service import LicenseService

if typing.TYPE_CHECKING:
    from rasax.community.services.stack_service import StackService

logger = logging.getLogger(__name__)


class RasaXEnvironmentError(ValueError):
    """Raised if the deployment environment doesn't match the requirements.

    An example for this is if no Rasa Open Source deployment is available.
    """


def default_environments_config_local(rasa_port: Union[int, Text]) -> Dict[Text, Any]:
    """Returns the default environment config for local mode."""
    return [
        ordereddict(
            [
                ("name", constants.RASA_PRODUCTION_ENVIRONMENT),
                ("url", f"http://localhost:{rasa_port}"),
                ("token", rasa_x_config.rasa_token),
            ]
        ),
        ordereddict(
            [
                ("name", constants.RASA_DEVELOPMENT_ENVIRONMENT),
                ("url", f"http://stuff:{rasa_port}"),
                ("token", rasa_x_config.rasa_token),
            ]
        ),
        ordereddict(
            [
                ("name", constants.RASA_WORKER_ENVIRONMENT),
                ("url", f"http://localhost:{rasa_port}"),
                ("token", rasa_x_config.rasa_token),
            ]
        ),
    ]


def default_stack_config() -> Dict[Text, Union[Text, List[Dict[Text, Text]]]]:
    """Returns a default stack config."""
    # TODO: Find a way to keep this in sync with the defaults that Rasa OSS
    # chooses?

    pipeline = [
        {"name": "WhitespaceTokenizer"},
        {"name": "RegexFeaturizer"},
        {"name": "LexicalSyntacticFeaturizer"},
        {"name": "CountVectorsFeaturizer"},
        {
            "name": "CountVectorsFeaturizer",
            "analyzer": "char_wb",
            "min_ngram": 1,
            "max_ngram": 4,
        },
        {"name": "DIETClassifier", "epochs": 100},
        {"name": "EntitySynonymMapper"},
        {"name": "ResponseSelector", "epochs": 100},
    ]

    policies = [
        {"name": "MemoizationPolicy"},
        {"name": "TEDPolicy", "max_history": 5, "epochs": 100},
        {"name": "RulePolicy"},
    ]

    return ordereddict(
        [("language", "en"), ("pipeline", pipeline), ("policies", policies)]
    )


class ProjectException(Exception):
    """Exception raised for errors related to projects."""

    def __init__(self, username: Text):  # noqa: D107 # Missing docstring
        self.message = username

    def __str__(self) -> Text:
        return self.message


class SettingsService(DbService):
    """A service used to read/write configuration of the Rasa X project."""

    @staticmethod
    def from_request(request: Request, **kwargs) -> "SettingsService":
        """Creates a `SettingsService` from an incoming HTTP request's DB session.

        Args:
            request: Incoming HTTP request.
            **kwargs: other key-value args, not used.

        Returns:
            `SettingsService` instance with a connection to the DB.
        """
        return SettingsService(request.ctx.db_session)

    def init_project(self, team: Text, project_id: Text):
        """Create project for `project_id`.

        Raise `ProjectException` if a project under that name already exists.
        """
        if self.get(team, project_id):
            raise ProjectException(f"Project '{project_id}' already exists.")

        new_project = Project(
            project_id=project_id, team=team, config=json.dumps(default_stack_config())
        )
        self.add(new_project)

        return new_project.as_dict()

    def get(
        self, team: Text, project_id: Text
    ) -> Optional[Dict[Text, Union[Text, Dict]]]:
        """Get project as dictionary."""
        project = self._get_project(team, project_id)
        return project.as_dict() if project else None

    def get_config(
        self, team: Text, project_id: Text
    ) -> Optional[Dict[Text, Union[Text, Dict]]]:
        """Get model config associated with project."""
        project = self._get_project(team, project_id)
        return project.get_model_config() if project else None

    def _get_project(self, team: Text, project_id: Text) -> Optional[Project]:
        return (
            self.query(Project)
            .filter(and_(Project.project_id == project_id, Project.team == team))
            .first()
        )

    def dump_config(
        self, team: Text, project_id: Text, filename: Optional[Text] = None
    ) -> None:
        """Dump domain to `filename` in yml format.

        Args:
            team: Team whose config should be dumped.
            project_id: Project whose config should be dumped.
            filename: Name of the file the config should be dumped into.
        """
        project = self._get_project(team, project_id)
        if project:
            if not filename:
                default_path = str(
                    io_utils.get_project_directory() / rasa_x_config.default_config_path
                )
                filename = json.loads(project.config).get("path") or default_path
            yaml_utils.dump_yaml_to_file(
                filename=filename, content=project.get_model_config()
            )

    def save_config(
        self,
        team: Text,
        project_id: Text,
        stack_config: Dict,
        config_path: Optional[Text] = None,
        should_dump: bool = True,
    ) -> None:
        """Save config as JSON file."""
        logger.debug(stack_config)

        if config_path:
            stack_config["path"] = config_path

        project = self._get_project(team, project_id)
        project.config = json.dumps(stack_config)

        if should_dump:
            background_dump_service.add_model_configuration_change(team, project_id)

    @staticmethod
    def _inspect_config(stack_config: Dict) -> None:
        """Confirm Rasa config has all the mandatory keys."""
        try:
            missing_keys = [
                k
                for k in constants.RASA_CONFIG_MANDATORY_KEYS
                if k not in stack_config or stack_config[k] is None
            ]
        except TypeError:
            raise config_utils.InvalidConfigError(
                "The config file is empty and therefore missing mandatory parameters: "
                "'{}'. Add missing parameters to config file and try again."
                "".format("', '".join(constants.RASA_CONFIG_MANDATORY_KEYS))
            )
        if missing_keys:
            raise config_utils.InvalidConfigError(
                "The config file is missing mandatory parameters: "
                "'{}'. Add missing parameters to config file and try again."
                "".format("', '".join(missing_keys))
            )

    def inspect_and_load_yaml_config(self, config_yaml: Text) -> Dict:
        """Load YAML config file."""
        stack_config = yaml_utils.load_yaml(config_yaml)
        self._inspect_config(stack_config)

        return stack_config

    def inspect_and_save_yaml_config_from_request(
        self, request_body: bytes, team: Text, project_id: Text
    ) -> Text:
        """Inspect and save yaml config from `request_body`."""
        config_yaml = io_utils.convert_bytes_to_string(request_body)
        stack_config = self.inspect_and_load_yaml_config(config_yaml)

        self.save_config(team, project_id, stack_config)

        return config_yaml

    def inject_environments_config_from_file(self, project_id: Text, filename: Text):
        """Inject a deployment environments configuration file at `filename` into the db."""
        if (
            LicenseService.is_enterprise_activated(self.session)
            and len(self.get_environments(project_id)) > 0
        ):
            return

        try:
            yaml_formatted_environments = yaml_utils.read_yaml_file(filename)
            environments = self.environments_from_yaml_format(
                yaml_formatted_environments
            )
            self.inspect_environments(environments, self.session)
            self.save_environments(project_id, environments)
            logger.debug(
                f"Successfully injected deployment environments "
                f"configuration from file '{filename}'."
            )
        except (ValueError, FileNotFoundError) as e:
            logger.warning(
                f"Could not inject deployment environments "
                f"configuration from file '{filename}'. Details:\n{e}"
            )

    @staticmethod
    def inspect_environments(
        environments: List[Dict[Text, Any]], session: Optional[Session] = None
    ) -> List[Dict[Text, Any]]:
        """Inspect a list of deployment environments.

        Check whether required entries `worker` and `production` are available, and if any
        extra entries added should be allowed. Remove unallowed entries.

        Args:
            environments: The environments to inspect.
            session: Optional SQLAlchemy session to use when checking for Enterprise
                license.

        Raises:
            RasaXEnvironmentError: Raised if config is invalid because it does not contain required entries
                for worker or production services.
        """
        environment_names = [env.get("name") for env in environments]

        if any(
            key not in environment_names
            for key in constants.ENVIRONMENTS_MANDATORY_KEYS
        ):
            raise RasaXEnvironmentError(
                "Environment needs to contain entries for production "
                "and worker services."
            )

        if LicenseService.is_enterprise_activated(session):
            return environments

        community_unallowed_keys = [
            key
            for key in environment_names
            if key not in constants.ENVIRONMENTS_MANDATORY_KEYS
        ]
        if community_unallowed_keys:
            cli_utils.raise_warning(
                f"Rasa X only allows for a production environment and "
                f"a worker environment. Rasa X will start up with only these "
                f"environments. To use more environments, please "
                f"contact us at {constants.HI_RASA_EMAIL} for a "
                f"Rasa Enterprise license."
            )
            environments = [
                env
                for env in environments
                if env.get("name") not in community_unallowed_keys
            ]

        return environments

    def update_environment(
        self, project_id: str, name: str, environment: Dict[Text, Any]
    ) -> Dict[Text, Any]:
        """Save or update the provided environment to the project.

        Args:
            project_id: The project to apply the environments to.
            name: The name of the environment
            environment: The environment to create or update

        Returns:
            The environment after creation or updating.
        """
        url = environment.get("url")
        token = environment.get("token")
        existing = self.query(Environment).get((project_id, name))

        if existing:
            existing.name = environment.get("name")
            existing.url = url
            existing.token = token
            return existing.as_dict()

        return self.add(
            Environment(name=name, project=project_id, url=url, token=token)
        ).as_dict()

    def save_environment(
        self, project_id: str, environment: Dict[Text, Any]
    ) -> Dict[Text, Any]:
        """Save the provided environment to the project.

        Args:
            project_id: The project to apply the environments to.
            environment: The environment to save to the project

        Returns:
            The environment after saving.
        """
        return self.update_environment(project_id, environment.get("name"), environment)

    def save_environments(
        self, project_id: Text, environments: List[Dict[Text, Any]]
    ) -> List[Dict[Text, Any]]:
        """Save the provided environments to the project, replacing old environments.

        Args:
            project_id: The project to apply the environments to.
            environments: The environments to save to the project

        Returns:
            The environments stored under the `project_id` after saving.
        """
        self.query(Environment).delete()

        for env in environments:
            self.add(
                Environment(
                    name=env.get("name"),
                    project=project_id,
                    url=env.get("url"),
                    token=env.get("token"),
                )
            )

        return self.get_environments(project_id)

    def get_environments(self, project_id: Text) -> List[Dict[Text, Any]]:
        """Retrieve the environments from the database.

        Args:
            project_id: The project to retrieve environments from.

        Returns:
            A list of environment configs for the given `project_id`.
        """
        envs = self.query(Environment).filter(Environment.project == project_id).all()
        return [e.as_dict() for e in envs]

    def delete_environment(self, project_id: Text, name: Text) -> bool:
        """Delete an environment from the database.

        Args:
            project_id: The project from which to delete the environment.
            name: The name of the environment to delete
        """
        return (
            self.query(Environment)
            .filter(Environment.project == project_id, Environment.name == name)
            .delete()
            > 0
        )

    def get_environment(
        self, project_id: Text, name: Text
    ) -> Optional[Dict[Text, Any]]:
        """Get an environment from the database.

        Args:
            project_id: The project from which to delete the environment.
            name: The name of the environment to delete

        Returns:
            An environment
        """
        env = (
            self.query(Environment)
            .filter(and_(Environment.project == project_id, Environment.name == name))
            .first()
        )
        return env.as_dict() if env is not None else None

    @staticmethod
    def environments_to_yaml_format(
        environments: List[Dict[Text, Any]]
    ) -> Dict[Text, Any]:
        """Convert list of environments to the format we use in our yaml files.

        Args:
            environments: List of environments.

        Returns:
            List of environments formatted for yaml
        """
        return {
            "environments": {
                "rasa": {
                    e["name"]: {k: v for k, v in e.items() if k != "name"}
                    for e in environments
                }
            }
        }

    @staticmethod
    def environments_from_yaml_format(
        yaml_format: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        """Convert list of environments from the format we use in our yaml files.

        Args:
            yaml_format: Environments formatted in the style of our environments yaml file

        Returns:
            List of environment objects
        """
        env = yaml_format.get("environments")
        if env is not None:
            yaml_format = env

        return [
            {"name": name, **env} for name, env in yaml_format.get("rasa", {}).items()
        ]

    def get_stack_service(
        self, environment: Text, project_id: Text = rasa_x_config.project_name
    ) -> Optional["StackService"]:
        """Return StackServices for given environment."""
        return self.stack_services(project_id).get(environment, None)

    def stack_services(
        self, project_id: Text = rasa_x_config.project_name
    ) -> Dict[Text, "StackService"]:
        """Create StackServices for all Stack servers."""
        from rasax.community.services.stack_service import RasaCredentials
        from rasax.community.services.stack_service import StackService

        environments = self.get_environments(project_id)

        _stack_services = {}
        for environment in environments:

            credentials = RasaCredentials(
                url=environment.get("url"), token=environment.get("token")
            )
            _stack_services[environment.get("name")] = StackService(
                credentials,
                DataService(self.session),
                StoryService(self.session),
                DomainService(self.session),
                self,
            )

        return _stack_services
