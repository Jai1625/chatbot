import logging
import typing
from typing import Any, Text, List, Optional, Union, Dict, Tuple

import time

import rasax.community.config as rasa_x_config
from rasax.community.services.event_consumers.event_consumer import EventConsumer
from rasax.community import constants
import rasax.community.utils.io as io_utils

if typing.TYPE_CHECKING:
    from kafka.structs import TopicPartition
    from kafka.consumer.fetcher import ConsumerRecord
    from kafka import KafkaConsumer
    from kafka.errors import KafkaConfigurationError

logger = logging.getLogger(__name__)

SASL_MECHANISMS = ("PLAIN", "GSSAPI", "OAUTHBEARER", "SCRAM-SHA-256", "SCRAM-SHA-512")


class InvalidSASLMechanism(Exception):
    """Exception raised when an invalid SASL mechanism is provided."""


class KafkaConsumerInitializationError(Exception):
    """Exception raised when the Kafka Consumer cannot be properly initialized."""


class KafkaEventConsumer(EventConsumer):
    """Kafka event consumer."""

    type_name = "kafka"

    def __init__(
        self,
        url: Union[Text, List[Text]],
        topic: Text,
        client_id: Optional[Text] = None,
        group_id: Optional[Text] = None,
        security_protocol: Text = "PLAINTEXT",
        sasl_username: Union[Text, int, None] = None,
        sasl_password: Optional[Text] = None,
        sasl_mechanism: Optional[Text] = "PLAIN",
        ssl_cafile: Optional[Text] = None,
        ssl_certfile: Optional[Text] = None,
        ssl_keyfile: Optional[Text] = None,
        ssl_check_hostname: bool = False,
        legacy_iterator: bool = False,
        enable_auto_commit: bool = True,
        auto_commit_interval_ms: int = 5000,
        max_poll_interval_ms: int = 300000,
        max_poll_records: int = 500,
        session_timeout_ms: int = 10000,
        heartbeat_interval_ms: int = 3000,
        should_run_liveness_endpoint: bool = False,
        **kwargs: Any,
    ):
        """Kafka event consumer.

        Args:
            url: 'host[:port]' string (or list of 'host[:port]'
                strings) that the consumer should contact to bootstrap initial
                cluster metadata. This does not have to be the full node list.
                It just needs to have at least one broker that will respond to a
                Metadata API Request. The default port is 9092. If no servers are
                specified, it will default to `localhost:9092`.
            topic: Topics to subscribe to. If not set, call subscribe() or assign()
                before consuming records
            client_id: A name for this client. This string is passed in each request
                to servers and can be used to identify specific server-side log entries
                that correspond to this client. Also submitted to `GroupCoordinator` for
                logging with respect to consumer group administration.
                Default: ‘kafka-python-{version}’
            group_id: The name of the consumer group to join for dynamic partition
                assignment (if enabled), and to use for fetching and committing offsets.
                If None, auto-partition assignment (via group coordinator) and offset
                commits are disabled. Default: None
            sasl_username: Username for sasl PLAIN authentication.
                Required if `sasl_mechanism` is `PLAIN`.
            sasl_password: Password for sasl PLAIN authentication.
                Required if `sasl_mechanism` is PLAIN.
            sasl_mechanism: Authentication mechanism when security_protocol is configured
                for SASL_PLAINTEXT or SASL_SSL.
                Valid values are: PLAIN, GSSAPI, OAUTHBEARER, SCRAM-SHA-256, SCRAM-SHA-512.
                Default: `PLAIN`
            ssl_cafile: Optional filename of ca file to use in certificate
                verification. Default: None.
            ssl_certfile: Optional filename of file in pem format containing
                the client certificate, as well as any ca certificates needed to
                establish the certificate's authenticity. Default: None.
            ssl_keyfile: Optional filename containing the client private key.
                Default: None.
            ssl_check_hostname: Flag to configure whether ssl handshake
                should verify that the certificate matches the brokers hostname.
                Default: False.
            security_protocol: Protocol used to communicate with brokers.
                Valid values are: PLAINTEXT, SSL, SASL_PLAINTEXT, SASL_SSL.
                Default: PLAINTEXT.
            legacy_iterator: Flag that enables the legacy iterator. This is expected
                to improve consumer throughput substantially and help reduce
                heartbeat failures / group rebalancing.
                Default: False
            enable_auto_commit: If True, the consumer’s offset will be periodically
                committed in the background.
                Default: True.
            auto_commit_interval_ms: Number of milliseconds between automatic
                offset commits, if enable_auto_commit is True.
                Default: 5000.
            max_poll_interval_ms: The maximum delay between invocations of poll()
                when using consumer group management. This places an upper bound on the
                amount of time that the consumer can be idle before fetching more records.
                Default: 300000.
            max_poll_records: The maximum number of records returned in a single call
                to poll().
                Default: 500.
            session_timeout_ms: The timeout used to detect failures when using Kafka’s
                group management facilities.
                Default: 10000.
            heartbeat_interval_ms: The expected time in milliseconds between heartbeats
                to the consumer coordinator when using Kafka’s group management facilities.
                The value must be set lower than session_timeout_ms, but typically should be
                set no higher than 1/3 of that value.
                Default: 3000
            should_run_liveness_endpoint: If `True`, runs a simple Sanic server as a
                background process that can be used to probe liveness of this service.
                The service will be exposed at a port defined by the
                `SELF_PORT` environment variable (5673 by default).

        """
        self.url = url
        self.topic = topic
        self.client_id = client_id
        self.group_id = group_id
        self.security_protocol = security_protocol
        self.sasl_username = sasl_username
        self.sasl_password = sasl_password
        self.sasl_mechanism = sasl_mechanism
        self.ssl_cafile = ssl_cafile
        self.ssl_certfile = ssl_certfile
        self.ssl_keyfile = ssl_keyfile
        self.legacy_iterator = legacy_iterator
        self.enable_auto_commit = enable_auto_commit
        self.auto_commit_interval_ms = auto_commit_interval_ms
        self.max_poll_interval_ms = max_poll_interval_ms
        self.max_poll_records = max_poll_records
        self.session_timeout_ms = session_timeout_ms
        self.heartbeat_interval_ms = heartbeat_interval_ms
        self.ssl_check_hostname = ssl_check_hostname
        self.consumer: Optional["KafkaConsumer"] = None
        super().__init__(should_run_liveness_endpoint)

    @classmethod
    def from_endpoint_config(
        cls,
        consumer_config: Optional[Dict],
        should_run_liveness_endpoint: bool = not rasa_x_config.LOCAL_MODE,
    ) -> Optional["KafkaEventConsumer"]:
        if consumer_config is None:
            logger.debug(
                "Could not initialise `KafkaEventConsumer` from endpoint config."
            )
            return None

        # FIXME: pending https://github.com/python/mypy/issues/2582 release
        return cls(
            **consumer_config,
            should_run_liveness_endpoint=should_run_liveness_endpoint,
        )

    def _create_consumer(self) -> None:
        # noinspection PyPackageRequirements
        import kafka

        if self.sasl_mechanism not in SASL_MECHANISMS:
            raise InvalidSASLMechanism(
                f"Cannot initialise `kafka.KafkaConsumer`. "
                f"`sasl_mechanism` must be in {', '.join(SASL_MECHANISMS)}."
            )

        if self.security_protocol.upper() == "PLAINTEXT":
            authentication_params = dict(
                security_protocol="PLAINTEXT", ssl_check_hostname=False,
            )
        elif self.security_protocol.upper() == "SASL_PLAINTEXT":
            authentication_params = dict(
                security_protocol="SASL_PLAINTEXT",
                sasl_plain_username=self.sasl_username,
                sasl_plain_password=self.sasl_password,
                sasl_mechanism=self.sasl_mechanism,
                ssl_check_hostname=False,
            )
        elif self.security_protocol.upper() == "SSL":
            authentication_params = dict(
                security_protocol="SSL",
                ssl_cafile=self.ssl_cafile,
                ssl_certfile=self.ssl_certfile,
                ssl_keyfile=self.ssl_keyfile,
                ssl_check_hostname=self.ssl_check_hostname,
            )
        elif self.security_protocol.upper() == "SASL_SSL":
            authentication_params = dict(
                security_protocol="SASL_SSL",
                sasl_plain_username=self.sasl_username,
                sasl_plain_password=self.sasl_password,
                sasl_mechanism=self.sasl_mechanism,
                ssl_cafile=self.ssl_cafile,
                ssl_certfile=self.ssl_certfile,
                ssl_keyfile=self.ssl_keyfile,
                ssl_check_hostname=self.ssl_check_hostname,
            )

        else:
            raise ValueError(
                f"Cannot initialise `kafka.KafkaConsumer` "
                f"with security protocol '{self.security_protocol}'."
            )

        try:
            self.consumer = kafka.KafkaConsumer(
                self.topic,
                bootstrap_servers=self.url,
                client_id=self.client_id,
                group_id=self.group_id,
                legacy_iterator=self.legacy_iterator,
                enable_auto_commit=self.enable_auto_commit,
                auto_commit_interval_ms=self.auto_commit_interval_ms,
                max_poll_interval_ms=self.max_poll_interval_ms,
                max_poll_records=self.max_poll_records,
                session_timeout_ms=self.session_timeout_ms,
                heartbeat_interval_ms=self.heartbeat_interval_ms,
                **authentication_params,
            )
        except KafkaConfigurationError as e:
            raise KafkaConsumerInitializationError(
                f"Cannot initialise `KafkaConsumer`: {e}"
            )

    @staticmethod
    def _origin_from_message_headers(headers: List[Tuple[Text, bytes]]) -> Text:
        """Fetch message origin from the `RASA_ENVIRONMENT` message header.

        Args:
            headers: kafka message headers.

        Returns:
            The string value of the `RASA_ENVIRONMENT` header value if set, otherwise
            `rasax.community.constants.DEFAULT_RASA_ENVIRONMENT`.
        """
        headers = {key: bytes_value for key, bytes_value in headers}
        origin_environment = headers.get("RASA_ENVIRONMENT", b"").decode(
            encoding=io_utils.DEFAULT_ENCODING
        )
        return origin_environment or constants.DEFAULT_RASA_ENVIRONMENT

    def consume(self):
        """Consume Kafka events."""
        self._create_consumer()
        logger.info(f"Start consuming topic '{self.topic}' on Kafka url '{self.url}'.")
        while True:
            records: Dict[
                "TopicPartition", List["ConsumerRecord"]
            ] = self.consumer.poll()

            # records contain only one topic, so we can just get all values
            for messages in records.values():
                for message in messages:
                    origin_environment = self._origin_from_message_headers(
                        message.headers
                    )
                    self.log_event(message.value, origin=origin_environment)

            time.sleep(0.01)
