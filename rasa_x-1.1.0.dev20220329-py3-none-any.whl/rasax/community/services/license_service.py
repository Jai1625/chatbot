from typing import Optional, Text, Dict, Any
import logging

from sanic.request import Request
import jwt
from sqlalchemy.orm import Session

import rasax.community.telemetry
import rasax.community.database.utils
import rasax.community.config
from rasax.community.database.service import DbService
from rasax.community.services.config_service import (
    ConfigService,
    ConfigKey,
    InvalidConfigValue,
    MissingConfigValue,
)

ALGORITHM = "RS256"
PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA6L90HBMIeiEUkLw85aRx
L8qisVwiJwy3E4E/MPKHEuzguUJG3KwQE3Yb37HWi6I8EXOI5UfP2RvbNPKbmYFo
90P27rKpvhZRCG9sy3cNu3Xr1XcQ6Eue2e12LWBAgzBZSqjzwkCOtt+L6LIm3lPf
2QYSFORTZR9PtOvI1b677W1lVjioRrbg1IG6UXGVOTCmeSFT/JzbsYzR7QFzFdWe
ytjHVgeb/R9inY1/LeiP2KCHYcYUF2sGc+6CsGvr9Kkio5KS10jBF27EeBaeVpXO
JH5viXVuRPCu5ymvnih5Rk4VYK3X3rG1rf5oju9OBDPLq7lKklY1pPZjBHADPU3o
/QIDAQAB
-----END PUBLIC KEY-----"""
CURRENT_VERSION = 2
JTI_BLOCKLIST = set(["a0ce8135-d101-4101-b410-b7a403818b1c"])  # expires: 23-01-2023

logger = logging.getLogger(__name__)


class LicenseValidationException(Exception):
    """Parent class for exceptions raised when handling licenses."""


class LicenseSchemaException(LicenseValidationException):
    """Exception raised when a license does not contain the correct fields."""


class LicenseEncodingException(LicenseValidationException):
    """Exception raised when the JWT representing a license is not well-formed."""


class LicenseVersionException(LicenseValidationException):
    """Exception raised when the license version is invalid."""


class LicenseSignatureInvalidException(LicenseValidationException):
    """Exception raised when a license signature could not be verified."""


class LicenseExpiredException(LicenseValidationException):
    """Exception raised when a license has expired (exp)."""


class LicenseNotYetValidException(LicenseValidationException):
    """Exception raised when a license is not valid yet (nbf)."""


class EnterpriseLicense:
    """Represents a Rasa Enterprise license.

    There a are two ways of instancing an `EnterpriseLicense` object:
    - Via `decode`: This is the option that should be used 99% of the times.
      This option allows callers to decode a JWT into an `EnterpriseLicense`
      object, which means that only correctly signed JWT will be decodable.
      Other checks will be performed on the JWT as well. This implies that any
      `EnterpriseLicense` obtained via `decode` is guaranteed to represent a
      valid license, that is, a license that was obtained via a
      contract/deal/etc. with Rasa Inc (i.e. the owner of the private key).
    - Via `__init__`: This creates an `EnterpriseLicense` object directly, without
      performing any validations. Useful only for creating new licenses (which
      requires access to the private key to then encode) or for testing
      purposes.

    In any case, Rasa Enterprise code should not deal with licenses directly,
    it should instead use `LicenseService`.

    """

    __slots__ = ["jti", "iat", "nbf", "exp", "email", "version"]

    def __init__(
        self, *, jti: Text, email: Text, iat: int, nbf: int, exp: int, version: int,
    ) -> None:
        """Initializes an instance of `EnterpriseLicense`.

        Args:
            jti: JWT unique identifier - a unique identifier for this
                license. Could be a UUID4, for example.
            email: Contact email for this license.
            iat: Created at (UNIX epoch time).
            nbf: Time at which the license starts being valid (UNIX epoch time).
            exp: Expiration date (UNIX epoch time).
            version: License format version.
        """
        self.jti = jti
        self.email = email
        self.iat = iat
        self.nbf = nbf
        self.exp = exp
        self.version = version

    def as_dict(self) -> Dict[Text, Any]:
        """Returns this license as a dictionary object.

        Returns:
            License represented using a `dict`.
        """
        return {attr: getattr(self, attr) for attr in EnterpriseLicense.__slots__}

    def __str__(self) -> Text:
        """Returns a text representation of this license.

        Returns:
            String representing this license.
        """
        return f"EnterpriseLicense <{self.as_dict()}>"

    @staticmethod
    def decode(
        encoded_license: Text,
        check_nbf: Optional[bool] = True,
        check_exp: Optional[bool] = True,
    ) -> "EnterpriseLicense":
        """Returns an instance of `EnterpriseLicense` from an encoded JWT.

        Args:
            encoded_license: JWT in encoded form.
            check_nbf: Check if not_before is in future.
            check_exp: Check if token has expired.

        Raises:
            LicenseSignatureInvalidException: If the license signature could
                not be validated.
            LicenseNotYetValidException: If the license is not valid yet.
            LicenseExpiredException: If the license has expired, or has been
                blocklisted.
            LicenseEncodingException: If the JWT was not correctly encoded.
            LicenseVersionException: If the license version is invalid.
            LicenseSchemaException: If the license contains unknown or extra
                fields, or if it is missing fields.

        Returns:
            A validated enterprise license.
        """
        try:
            decoded = jwt.decode(
                encoded_license,
                key=PUBLIC_KEY,
                algorithms=[ALGORITHM],
                options={"verify_nbf": check_nbf, "verify_exp": check_exp},
            )
        except jwt.exceptions.InvalidSignatureError:
            raise LicenseSignatureInvalidException(
                "Could not verify the license's signature."
            )
        except jwt.exceptions.ImmatureSignatureError:
            raise LicenseNotYetValidException("The license is not valid yet (nbf).")
        except jwt.exceptions.ExpiredSignatureError:
            raise LicenseExpiredException("The license has already expired (exp).")
        except jwt.exceptions.DecodeError:
            # Handle `DecodeError` last since other more specific exceptions
            # such as `InvalidSignatureError` inherit from it.
            raise LicenseEncodingException("Could not decode license as JWT.")

        version = decoded["version"]
        if version != CURRENT_VERSION:
            raise LicenseVersionException(
                f"Invalid license version number: '{version}'."
            )

        if set(decoded.keys()) != set(EnterpriseLicense.__slots__):
            raise LicenseSchemaException("Invalid license schema.")

        if decoded["jti"] in JTI_BLOCKLIST:
            raise LicenseExpiredException("The license has already expired.")

        return EnterpriseLicense(**decoded)

    def encode(self, private_key: Text) -> Text:
        """Encodes this license into a JWT.

        NOTE: This method is only useful in the context of testing, or when
        using administrative scripts such as `create_enterprise_license.py`. It
        should not be used otherwise.

        Args:
            private_key: Private key to use. Should correspond to `PUBLIC_KEY`.

        Returns:
            Encoded license.
        """
        return jwt.encode(self.as_dict(), key=private_key, algorithm=ALGORITHM)


class LicenseService(DbService):
    """Service for managing the stored Rasa Enterprise license in the database.

    `LicenseService` uses `ConfigService` for data management.

    """

    def __init__(self, session: Session):
        """Initializes an instance of `LicenseService`.

        Args:
            session: SQLAlchemy session.
        """
        super().__init__(session)
        self._config_service = ConfigService(session)

    def validate_and_store_license(self, encoded_license: Text) -> EnterpriseLicense:
        """Validates and if valid stores a Rasa Enterprise license in the DB.

        Args:
            encoded_license: License in its encoded JWT form.

        Raises:
            LicenseValidationException: See the `EnterpriseLicense.decode` method.

        Returns:
            `EnterpriseLicense` if the encoded license was successfully decoded
            and validated. If this is the case, the license will also have been
            stored in the DB (as an encoded JWT).
        """
        enterprise_license = EnterpriseLicense.decode(encoded_license)

        try:
            self._config_service.set_value(
                ConfigKey.RASA_ENTERPRISE_LICENSE, encoded_license
            )
            self._post_activation()
        except Exception as e:
            # If anything went wrong during post-activation, remove the license.
            # We won't consider the activation successful, even if the license was
            # valid.
            logger.error(f"Enterprise license activation failed due to: {e}")
            self.delete_license()
            raise e

        logger.info("Rasa Enterprise successfully activated.")

        return enterprise_license

    def _post_activation(self) -> None:
        """Enable Enterprise features after license activation."""
        from rasax.community.services.settings_service import SettingsService

        # Enterprise license activation was successful. Ensure telemetry is
        # disabled, as that is the default for Enterprise.
        rasax.community.telemetry.disable_telemetry(self.session)

        # Reload environments file, in case extra environments are wanted
        settings_service = SettingsService(self.session)
        settings_service.inject_environments_config_from_file(
            rasax.community.config.project_name,
            rasax.community.config.default_environments_config_path,
        )

    def retrieve_encoded_license(self) -> Optional[Text]:
        """Retrieves if possible a license stored in the DB, in its encoded JWT form.

        NOTE: A license can be present but this does not mean it is necessarily
        valid. For example, it could have been stored and validated before its
        expiration date, and then enough time could have elapsed for it to
        expire.

        Returns:
            If present, a string representing the license in its JWT encoded form.
        """
        try:
            return self._config_service.get_value(
                ConfigKey.RASA_ENTERPRISE_LICENSE, expected_type=str
            )
        except (InvalidConfigValue, MissingConfigValue):
            return None

    def retrieve_validated_enterprise_license(self) -> Optional[EnterpriseLicense]:
        """Retrieves if possible a validated stored license in the DB.

        If this method returns an instance of `EnterpriseLicense`, callers can
        assume that we are currently running in a Rasa Enterprise
        server. However, see `is_enterprise_activated` for a more convenient
        way to check this.

        Returns:
            Instance of `EnterpriseLicense` if a valid license is stored in the DB.
        """
        encoded_license = self.retrieve_encoded_license()
        if not encoded_license:
            return None

        try:
            return EnterpriseLicense.decode(encoded_license)
        except LicenseValidationException:
            return None

    def delete_license(self) -> None:
        """Removes any license stored in the DB."""
        self._config_service.set_value(ConfigKey.RASA_ENTERPRISE_LICENSE, None)

    @staticmethod
    def is_enterprise_activated(session: Optional[Session] = None) -> bool:
        """Checks if there's a valid license stored in the DB.

        This is the ideal method to use if you want to quickly check if the
        current server is a Rasa Enterprise instance from any part of the code.

        Args:
            session: SQLAlchemy session. If `None` is provided, a new one will
                be used instead. Callers should ideally provide one if
                possible, to avoid creating new sessions unnecessarily.

        Returns:
            `True` if Rasa Enterprise is activated, `False` otherwise.
        """
        with rasax.community.database.utils.try_reuse_session_scope(
            session
        ) as db_session:
            license_service = LicenseService(db_session)
            return license_service.retrieve_validated_enterprise_license() is not None

    @staticmethod
    def from_request(request: Request, **kwargs) -> "LicenseService":
        """Creates a `LicenseService` from an incoming HTTP request's DB session.

        Args:
            request: Incoming HTTP request.
            **kwargs: Other key-value args, not used.

        Returns:
            `LicenseService` instance with a connection to the DB.
        """
        return LicenseService(request.ctx.db_session)
