import hashlib
import json
import logging
import random
import time
import datetime
import secrets
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Text, Union

import rasax.community.config as rasa_x_config
import rasax.community.constants as constants
from rasax.community.database import Conversation, ConversationSession
from rasax.community.database.admin import Role, SingleUseToken, User
from rasax.community.database.service import DbService
from rasax.community.services.license_service import LicenseService
from sanic.request import Request
from sanic_jwt import exceptions
from sqlalchemy import and_, or_
from passlib.hash import pbkdf2_sha256

if TYPE_CHECKING:
    from rasax.community.database.admin import UserDict

logger = logging.getLogger(__name__)

ADMIN = "admin"
ANNOTATOR = "annotator"
TESTER = "tester"
GUEST = "guest"


class AuthMechanisms:
    """Authentication mechanisms."""

    username_password = "username/password"
    saml = "saml"
    invite_code = "invite_code"


class MismatchedPasswordsException(Exception):
    """Exception raised for errors related to mismatched passwords."""

    def __init__(self):  # noqa: D107 # Missing docstring
        self.message = "Passwords do not match!"

    def __str__(self):
        return self.message


class ConstraintsPasswordsException(Exception):
    """Exception raised for errors related to passwords constraints."""

    def __init__(self):
        """Creates a new ConstraintsPasswordsException."""
        self.message = "Password must be 8 characters or more in length."

    def __str__(self):
        return self.message


class UserException(Exception):
    """Exception raised for errors related to operations involving `User` objects."""

    def __init__(self, username):  # noqa: D107 # Missing docstring
        self.message = username

    def __str__(self):
        return self.message


class RoleException(Exception):
    """Exception raised for errors related to operations involving `Role` objects."""

    def __init__(self, username):  # noqa: D107 # Missing docstring
        self.message = username

    def __str__(self):
        return self.message


class UserService(DbService):
    """Service used to create, delete and modify Rasa X/Enterprise users."""

    def fetch_user(
        self,
        username: Text,
        return_api_token: bool = False,
        return_invite_code: bool = False,
    ) -> Optional["UserDict"]:
        """Retrieve a user.

        Args:
            username: User's unique username.
            return_api_token: Include API token in the return value.

        Returns:
            User represented using a dictionary.
        """
        user = self._fetch_user(username)
        if user:
            return user.as_dict(
                return_api_token=return_api_token, return_invite_code=return_invite_code
            )

        return None

    def _fetch_user(self, username: Text) -> User:
        return self.query(User).filter(User.username == username).first()

    def _fetch_user_by_invite(self, invite: Text) -> User:
        return (
            self.query(User)
            .filter(
                User.invite_code == invite,
                User.authentication_mechanism == AuthMechanisms.invite_code,
            )
            .first()
        )

    def has_invite_expired(self, user: User) -> bool:
        """Return true if the invite has expired.

        Will return false also if this is not an invite_code user.
        """
        if user.authentication_mechanism != AuthMechanisms.invite_code:
            return False

        if user.invite_code is None:
            return False

        return user.invite_expiry < datetime.datetime.utcnow()

    def fetch_all_users(
        self,
        team: Text,
        string_query: Optional[Text] = None,
        role_query: Optional[Text] = None,
        exclude_system_user: bool = True,
    ) -> List[Dict]:
        """Fetch all users.

        Args:
            team: Users' team
            string_query: Query for user's name or fullname
            role_query: comma-separated role query
            exclude_system_user: whether to exclude the system user

        Returns:
            List of users as dict.
        """
        if role_query:
            roles = role_query.split(",")
            query = User.roles.any(Role.role.in_(roles))
        else:
            query = True

        if exclude_system_user:
            query = and_(query, User.username != rasa_x_config.SYSTEM_USER)

        if string_query:
            query = and_(
                query,
                or_(
                    User.username.ilike(f"%{string_query}%"),
                    User.fullname.ilike(f"%{string_query}%"),
                ),
            )

        users = self.query(User).filter(User.team == team).filter(query).all()

        return [u.as_dict() for u in users]

    def get_number_of_users(self) -> int:
        """Return the number of users."""
        return (
            self.query(User).filter(User.username != rasa_x_config.SYSTEM_USER).count()
        )

    def create_system_user(self):
        """Creates a system user.

        Returns:
            When successful, a dictionary representation of the new system user.
        """
        username = rasa_x_config.SYSTEM_USER

        existing_user = self._fetch_user(username)
        if existing_user:
            raise UserException(username)

        new_user = User(
            username=username,
            project="default",
            team=rasa_x_config.team_name,
            password_hash=None,
            api_token=self.generate_api_token(),
            authentication_mechanism=AuthMechanisms.username_password,
            fullname="System User",
        )
        self.add(new_user)
        self._initialize_user_with_roles(new_user, ADMIN)

        return new_user.as_dict()

    def create_user(
        self,
        username: Text,
        raw_password: Optional[Text],
        team: Text,
        roles: Optional[Union[List[Text], Text]],
        auth_mechanism: Text,
        fullname: Optional[Text] = None,
    ) -> Optional["UserDict"]:
        """Create a new user.

        Args:
            username: User name to use.
            raw_password: Password plaintext.
            team: Team to assign user to.
            roles: List of roles, or single role, to assign to the user.
            auth_mechanism: Authentication mechanism to use.

        Raises:
            UserException: When the user with `username` already exists.

        Returns:
            When successful, a dictionary representation of the new user.
        """
        # System users are made with create_system_user
        if username == rasa_x_config.SYSTEM_USER:
            logger.error(
                "System users cannot be created through the create_user() function."
            )
            return None

        # Only allow creating one non-system user when Enterprise is not
        # activated. However, if a user already exists, always allow creating
        # the `admin` user, to make initialization more consistent.
        enterprise_activated = LicenseService.is_enterprise_activated(self.session)
        if (
            username != constants.DEFAULT_USERNAME
            and not enterprise_activated
            and self.get_number_of_users() > 0
        ):
            logger.error(
                f"Rasa X does not support multiple users. "
                f"If you'd like to create more users, please contact us at "
                f"{constants.HI_RASA_EMAIL} for a Rasa Enterprise license."
            )
            return None

        existing_user = self._fetch_user(username)
        if existing_user:
            if self.has_invite_expired(existing_user):
                self.delete_user(existing_user.username)
            else:
                raise UserException(username)

        api_token = self.generate_api_token()

        invite_code = None
        invite_expiry = None
        password_hash = None

        if raw_password is not None:
            password_hash = self.hash_pw(raw_password)
        elif auth_mechanism == AuthMechanisms.invite_code:
            invite_code = self.generate_invite_code()
            invite_expiry = datetime.datetime.utcnow() + datetime.timedelta(days=1)
            auth_mechanism = AuthMechanisms.invite_code

        new_user = User(
            username=username,
            project="default",
            team=team,
            password_hash=password_hash,
            api_token=api_token,
            fullname=fullname,
            authentication_mechanism=auth_mechanism,
            invite_code=invite_code,
            invite_expiry=invite_expiry,
        )
        self.add(new_user)
        self._initialize_user_with_roles(new_user, roles)

        return new_user.as_dict(return_invite_code=True)

    def _initialize_user_with_roles(
        self, user: User, roles: Optional[Union[List[Text], Text]]
    ) -> None:
        """Initialize a new user with a list of roles.

        In case one of the roles are invalid, it will
        erase the user because it cannot be configured as intended.

        This is an internal method used when creating users.

        Args:
            user: the new user
            roles: a list of role names
        Raises:
            RoleException: If one of the `roles` doesn't exist.
        """
        roles = roles or []
        if isinstance(roles, str):
            roles = [roles]

        for role in roles:
            self._add_role_to_user(user, role)

    def insert_or_update_user(
        self, username: Text, password: Text, team: Text, role: Text = ADMIN
    ):
        """Inserts a user or updates their password if the user already exists."""
        user = self._fetch_user(username)
        if user:
            logger.debug(f"Found user: '{username}'.")
            self.admin_change_password(username, password)
            user.authentication_mechanism = AuthMechanisms.username_password
            logger.debug(f"Updated password for user '{username}' to '{password}'.")
        else:
            self.create_user(
                username, password, team, role, AuthMechanisms.username_password
            )
            logger.debug(
                "Created local user named {} "
                "with password {}".format(username, password)
            )

    def _delete_conversation_sessions_created_by_user(self, username: Text) -> None:
        conversation_sessions_created_by_username = (
            self.query(ConversationSession)
            .join(Conversation)
            .filter(
                and_(
                    ConversationSession.conversation_id == Conversation.sender_id,
                    Conversation.created_by == username,
                )
            )
            .all()
        )
        if conversation_sessions_created_by_username:
            self.delete_all(conversation_sessions_created_by_username)

    def _delete_conversations_created_by_user(self, username: Text) -> None:
        # check if `username` has created any conversations at all
        conversations = (
            self.query(Conversation).filter(Conversation.created_by == username).all()
        )
        if not conversations:
            logger.debug(
                f"Skip deleting conversations created by user '{username}'. "
                f"No conversations were found."
            )
            return

        logger.debug(f"Deleting conversations created by user '{username}'.")
        # delete conversation sessions for all conversations that were `created_by`
        # `username`
        self._delete_conversation_sessions_created_by_user(username)

        # delete the actual conversations
        self.delete_all(conversations)

    def delete_user(
        self,
        username: Text,
        requesting_user: Optional[Text] = None,
        delete_created_conversations: bool = True,
    ) -> "UserDict":
        """Deletes a user by the username.

        Args:
            username: The name of the user to be deleted.
            requesting_user: The name of the user requesting the deletion.
            delete_created_conversations: Whether or not the interactive learning
                conversations that were created by this user should be deleted.

        Returns:
            The serialized user that has been deleted.
        """
        if requesting_user and username == requesting_user:
            raise UserException(f"Requesting user '{username}' cannot delete itself.")

        existing_user = self._fetch_user(username)
        if not existing_user:
            raise UserException(username)

        if username == rasa_x_config.SYSTEM_USER:
            raise UserException(f"Cannot delete user '{username}'.")

        if delete_created_conversations:
            self._delete_conversations_created_by_user(username)

        deleted_user = existing_user.as_dict()
        self.delete(existing_user)

        return deleted_user

    def _add_role_to_user(self, existing_user: User, role: Text) -> None:
        """Gives `existing_user` an additional role."""
        _role = self.query(Role).get(role)

        if not _role:
            raise RoleException(f"Role '{role}' does not exist.")

        if not any([r.role == _role.role for r in existing_user.roles]):
            existing_user.roles.append(_role)
        else:
            logger.debug(
                f"User '{existing_user.username or existing_user.name_id}' already "
                f"had role '{_role.role}'."
            )

    def add_role_to_user(self, username: Text, role: Text) -> None:
        """Gives the user an additional role."""
        existing_user = self._fetch_user(username)

        if not existing_user:
            raise UserException(f"User '{username}' does not exist.")

        self._add_role_to_user(existing_user, role)

    def add_role_to_saml_user(self, name_id: Text, role: Text) -> None:
        """Gives the user an additional role."""
        existing_user = self._fetch_saml_user(name_id)

        if not existing_user:
            raise UserException(f"SAML user with name ID '{name_id}' does not exist.")

        self._add_role_to_user(existing_user, role)

    @staticmethod
    def _inspect_admin_role_update(
        existing_user: User, requesting_user: Optional[Text], username: Text
    ) -> None:
        """Inspect role update operation on `existing_user` by `requesting_user`.

        Raises `RoleException` if `requesting_user` currently holds `admin` role
        and tries to remove that role.
        """
        if (
            requesting_user
            and username == requesting_user
            and has_role(existing_user.as_dict(), ADMIN)
        ):
            raise RoleException(
                "User '{}' currently holds 'admin' role and "
                "cannot remove that role.".format(username)
            )

    def replace_user_roles(
        self,
        username: Text,
        roles: Union[List[Text], Text, None],
        requesting_user: Optional[Text] = None,
    ) -> None:
        """Removes all roles from a user and replaces them with new ones."""
        existing_user = self._fetch_user(username)

        roles = roles or []
        if not isinstance(roles, list):
            roles = [roles]

        if ADMIN not in roles:
            self._inspect_admin_role_update(existing_user, requesting_user, username)

        # remove all roles
        existing_user.roles = []

        # add new set of roles
        if roles and roles[0]:
            for role in roles:
                self.add_role_to_user(username, role)

    def delete_user_role(
        self, username: Text, role: Text, requesting_user: Optional[Text] = None
    ) -> None:
        """Deletes a role from a user."""
        existing_user = self._fetch_user(username)
        if not existing_user:
            raise UserException(username)

        if role == ADMIN:
            self._inspect_admin_role_update(existing_user, requesting_user, username)

        roles_to_delete = [r for r in existing_user.roles if r.role == role]

        if not roles_to_delete:
            raise RoleException(role)

        for role in roles_to_delete:
            existing_user.roles.remove(role)

    def create_saml_user(
        self,
        name_id: Text,
        team: Text,
        roles: Optional[Union[List[Text], Text]],
        username: Optional[Text] = None,
        api_token: Optional[Text] = None,
    ) -> "UserDict":
        """Create a SAML user.

        Returns:
            If successful, the SAML user that has been created.
        """
        api_token = api_token or self.generate_api_token()

        existing_name_id = self._fetch_user(name_id)
        if existing_name_id:
            raise UserException(f"Username for SAML ID '{name_id}' already exists.")

        new_user = User(
            username=username or name_id,
            name_id=name_id,
            project="default",
            team=team,
            api_token=api_token,
            authentication_mechanism=AuthMechanisms.saml,
            username_is_assigned=username is not None,
        )
        self.add(new_user)
        self._initialize_user_with_roles(new_user, roles)

        return new_user.as_dict()

    def update_saml_username(
        self, name_id: Text, username: Text
    ) -> Optional["UserDict"]:
        """Creates a new user for `username`.

        Deletes the old user associated with `name_id`.
        """
        existing_user = self._fetch_saml_user(name_id)

        if not existing_user:
            raise UserException(f"User with SAML ID '{name_id}' not found")

        if self._fetch_user(username):
            raise UserException(f"Username '{username}' already exists")

        # delete old user
        self.delete_user(existing_user.username)

        self.create_saml_user(
            name_id=name_id,
            team=existing_user.team,
            roles=[role.role for role in existing_user.roles],
            username=username,
            api_token=existing_user.api_token,
        )

        return self.fetch_saml_user(name_id)

    def _fetch_saml_user(self, name_id: Text) -> User:
        return self.query(User).filter(User.name_id == name_id).first()

    def fetch_saml_user(self, name_id: Text) -> Optional["UserDict"]:
        """Fetch SAML user.

        Args:
            name_id: Id of the user

        Returns:
            If successful, dictionary representing the User
        """
        user = self._fetch_saml_user(name_id)
        if user:
            return user.as_dict()
        else:
            return None

    def _delete_single_use_token(self, token: Text) -> None:
        existing_token = self.query(SingleUseToken).get(token)
        if not existing_token:
            return None

        self.delete(existing_token)

    def update_single_use_token(
        self,
        name_id: Text,
        single_use_token: Text,
        lifetime: float = 60.0
        # 1 minute
    ) -> None:
        """Updates single use token."""
        existing_name_id_user = self.query(User).filter(User.name_id == name_id).first()

        if not existing_name_id_user:
            raise UserException(f"name_id '{name_id}' not found")

        expires = time.time() + lifetime

        existing_token = existing_name_id_user.single_use_token

        if existing_token:
            self._delete_single_use_token(existing_token.token)

        new_token = SingleUseToken(
            token=single_use_token, expires=expires, username=name_id
        )
        existing_name_id_user.single_use_token = new_token

    def single_use_token_login(
        self, single_use_token: Text, return_api_token: bool = False
    ) -> Optional[Dict]:
        """Returns single use token."""
        user = (
            self.query(User)
            .filter(User.single_use_token.has(SingleUseToken.token == single_use_token))
            .first()
        )
        if not user:
            logger.debug(f"No user found for single-use token '{single_use_token}'.")
            return None

        # check if token has expired
        token_expires = user.single_use_token.expires
        if time.time() > token_expires:
            logger.debug(
                "single-use token '{}' expired at '{}'"
                "".format(single_use_token, token_expires)
            )
            return None

        # delete single-use token
        self._delete_single_use_token(single_use_token)

        return user.as_dict(return_api_token=return_api_token)

    @staticmethod
    def legacy_hash_pw(pw):
        """SHA256 hash the supplied string."""
        salted_pw = (rasa_x_config.password_salt + pw).encode()
        return hashlib.sha256(salted_pw).hexdigest()

    @staticmethod
    def hash_pw(pw):
        """PBKDF2-HMAC-SHA256 hash the supplied string."""
        return pbkdf2_sha256.using(
            rounds=constants.PBKDF2_ITERATIONS_COUNT, salt_size=16
        ).hash(pw)

    @staticmethod
    def verify_password(password, pw_hash) -> bool:
        """Returns `True` if supplied password matches the hash."""
        return pbkdf2_sha256.verify(password, pw_hash)

    @staticmethod
    def generate_api_token() -> Text:
        """Generate a random API token."""
        body = "{}".format(random.random()).encode()
        return hashlib.sha1(body).hexdigest()

    @staticmethod
    def generate_invite_code() -> Text:
        """Generate a random invite code."""
        return secrets.token_hex(16)

    @staticmethod
    def is_invite_code_user(user: User) -> bool:
        """Check if a user uses an invite token as authentication mechanism.

        Args:
            user: `User` object.

        Returns:
            `True` if the user uses an invite token.
        """
        return user.authentication_mechanism == AuthMechanisms.invite_code

    @staticmethod
    def is_username_password_user(user: User) -> bool:
        """Check if a user uses a password as authentication mechanism.

        Args:
            user: `User` object.

        Returns:
            `True` if the user uses a password.
        """
        return user.authentication_mechanism == AuthMechanisms.username_password

    def is_user_password_set_required(self, username: Text) -> bool:
        """Checks if a user still needs its password to be set.

        Args:
            username: User's username.

        Raises:
            UserException: If the user does not exist.

        Returns:
            `True` if the user's password is missing and should be set in order
            to log in.
        """
        user = self._fetch_user(username)
        if not user:
            raise UserException(username)

        return (
            user.authentication_mechanism == AuthMechanisms.username_password
            and not user.password_hash
        )

    def login(
        self, username: Text, password: Text, return_api_token: bool = False
    ) -> "UserDict":
        """Performs login for a user using a password.

        Args:
            username: User's username.
            password: Password plaintext.
            return_api_token: If `True`, include `api_token` property in the return
                value.

        Returns:
            If login was successful, returns a user represented using a dictionary.
        """
        user = self._fetch_user(username)

        if user is None:
            raise exceptions.AuthenticationFailed("Incorrect user or password.")

        if username == rasa_x_config.SYSTEM_USER:
            raise exceptions.AuthenticationFailed(f"Cannot log in user '{username}'.")

        if not self.is_username_password_user(user):
            logger.info(
                "Cannot log in user '{}' with username/password. User "
                "has auth mechanism '{}'."
                "".format(user.username, user.authentication_mechanism)
            )
            raise exceptions.AuthenticationFailed("Incorrect user or password.")

        # legacy password check branch
        if user.is_password_legacy():
            legacy_pw_hash = self.legacy_hash_pw(password)
            if not secrets.compare_digest(user.password_hash, legacy_pw_hash):
                raise exceptions.AuthenticationFailed("Incorrect user or password.")

            # upgrade password
            user.password_hash = self.hash_pw(password)

        if not self.verify_password(password, user.password_hash):
            raise exceptions.AuthenticationFailed("Incorrect user or password.")

        return user.as_dict(return_api_token=return_api_token)

    def invite_login(self, invite_code: Text) -> "UserDict":
        """Performs login for a user using an invite code.

        Args:
            invite_code: User's invite code

        Returns:
            If login was successful, returns a user represented using a dictionary.
        """
        user = self._fetch_user_by_invite(invite_code)

        if user is None:
            raise exceptions.AuthenticationFailed("Invalid invite code.")

        if self.has_invite_expired(user):
            raise exceptions.AuthenticationFailed("Expired invite code.")

        return user.as_dict(return_invite_code=True)

    def change_password(self, fields: Dict[Text, Text]) -> Optional["UserDict"]:
        """Changes a user's password.

        Args:
            fields: User-related fields included in request.

        Returns:
            If password change was successful, user represented using a dictionary.
        """
        username = fields[constants.USERNAME_KEY]
        new_password = fields.get("new_password")
        new_password_confirm = fields.get("new_password_confirm")

        if new_password != new_password_confirm:
            raise MismatchedPasswordsException

        if len(new_password) < 8:
            raise ConstraintsPasswordsException

        user = self._fetch_user(username)

        if user is None:
            return None

        if self.is_invite_code_user(user):
            user.invite_code = None
            user.invite_expiry = None
            user.authentication_mechanism = AuthMechanisms.username_password
        else:
            old_password = fields.get("old_password", "")
            if self.login(username, old_password) is None:
                return None

        user.password_hash = self.hash_pw(fields["new_password"])

        return user.as_dict()

    def update_user(
        self,
        username: Text,
        values: Dict[Text, Any],
        requesting_user: Optional[Text] = None,
    ) -> "UserDict":
        """Update select properties of a `User`.

        Only a subset of properties can be updated at
        the moment (`data`, `roles` and `fullname`)

        Args:
            username: The user's username.
            values: Values to update the user with.
            requesting_user: The user requesting the update.
        """
        user = self._fetch_user(username)
        if not user:
            raise UserException(username)

        for key, value in values.items():
            if key == "data":
                user.data = json.dumps(value)
            elif key == "roles":
                # This will throw if it fails and the user will not be committed
                self.replace_user_roles(
                    username, value, requesting_user=requesting_user
                )
            elif key in ["fullname"]:
                setattr(user, key, value)

        return user.as_dict()

    def update_saml_user(self, name_id: Text, values: Dict[Text, Any]) -> None:
        """Updates select properties of a SAML `User`.

        Only the `data` property can be updated at
        the moment.

        Args:
            name_id: saml_id of the user.
            values: Values to update the user with.
        """
        user = self._fetch_saml_user(name_id)
        if not user:
            raise UserException(name_id)

        user.data = json.dumps(values["data"])

    def admin_change_password(self, username: Text, password: Text) -> "UserDict":
        """Set a user's password without needing confirmation or login.

        Args:
            username: The user's username.
            password: New password to set.

        Returns:
            Dictionary containing user attributes.
        """
        existing_user = self._fetch_user(username)
        if not existing_user:
            raise UserException(username)

        existing_user.password_hash = self.hash_pw(password)

        return existing_user.as_dict()

    def api_token_auth(self, api_token: Text, return_api_token: bool = False) -> Dict:
        """Login via an API token.

        Args:
            api_token: Token text value.
            return_api_token: Include the API token in the return value.

        Returns:
            User corresponding to the API token, as a dictionary.
        """
        users = self.query(User).all()
        token_matches = [
            user for user in users if secrets.compare_digest(user.api_token, api_token)
        ]
        if not token_matches:
            raise exceptions.AuthenticationFailed("Incorrect api_token.")
        elif len(token_matches) >= 2:
            raise exceptions.AuthenticationFailed(
                "Multiple users with same api_token found."
            )

        return token_matches[0].as_dict(return_api_token=return_api_token)

    def assign_project_to_user(self, user: Dict, project_id: Text) -> None:
        """Update user's project_id."""
        username = user.get(constants.USERNAME_KEY)  # type: Optional[Text]
        if not username:
            return

        owner = self._fetch_user(username)
        if not user:
            return
        owner.project = project_id
        owner.role_name = ADMIN

    @staticmethod
    def from_request(request: "Request", **kwargs) -> "UserService":
        """Creates an `UserService` from an incoming HTTP request's DB session.

        Args:
            request: Incoming HTTP request.
            **kwargs: other key-value args, not used.

        Returns:
            `UserService` instance with a connection to the DB.
        """
        return UserService(request.ctx.db_session)


def has_role(user: "UserDict", role: Text) -> bool:
    """Checks whether the user possesses a role."""
    return role in user["roles"]
