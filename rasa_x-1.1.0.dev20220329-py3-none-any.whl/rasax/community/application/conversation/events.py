import enum
from enum import Enum


class EventType(str, Enum):
    """Enum of event types."""

    ACTION_EXECUTED = "action"
    ACTION_EXECUTION_REJECTED = "action_execution_rejected"
    ACTION_REVERTED = "undo"
    ACTIVE_LOOP = "active_loop"
    BOT_UTTERED = "bot"
    DEFINE_PREV_USER_UTTERED_FEATURIZATION = "user_featurization"
    ENTITIES_ADDED = "entities"
    RESTARTED = "restart"
    SESSION_STARTED = "session_started"
    SLOT_SET = "slot"
    USER_UTTERANCE_REVERTED = "rewind"
    USER_UTTERED = "user"


@enum.unique
class EventVerbosity(Enum):
    """Filter on which events to include in tracker dumps."""

    # all events, that contribute to the trackers state are included
    # these are all you need to reconstruct the tracker state
    APPLIED = 2

    # include even more events, in this case everything that comes
    # after the most recent restart event. this will also include
    # utterances that got reverted and actions that got undone.
    AFTER_RESTART = 3

    # include every logged event
    ALL = 4
