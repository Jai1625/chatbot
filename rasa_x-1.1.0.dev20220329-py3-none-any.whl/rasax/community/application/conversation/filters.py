from __future__ import annotations

import abc
import logging
from abc import ABC
from typing import List, Text, Optional, Type, Mapping

from rasax.community.application.conversation.events import EventType, EventVerbosity
from rasax.community.database import ConversationEvent

logger = logging.getLogger(__name__)


class FilterFactory:
    """Factory class for creating conversation filters."""

    @staticmethod
    def from_verbosity(verbosity: EventVerbosity) -> ConversationFilter:
        """Takes an event verbosity and returns the correct filter.

        Args:
            verbosity: A value from the EventVerbosity enum.

        Raises:
            KeyError: If an incorrect verbosity is provided, which does not map to a filter class.

        Returns:
            A subclass of ConversationFilter.
        """
        try:
            return FilterFactory._mapping()[verbosity]()
        except KeyError:
            logger.error(
                f"Tried to get an event filter for the unexpected verbosity: {verbosity}"
            )
            raise NotImplementedError

    @staticmethod
    def _mapping() -> Mapping[EventVerbosity, Type[ConversationFilter]]:
        return {
            EventVerbosity.ALL: All,
            EventVerbosity.AFTER_RESTART: AfterRestart,
            EventVerbosity.APPLIED: Applied,
        }


class ConversationFilter(ABC):
    """Base class for filters."""

    @abc.abstractmethod
    def satisfy(self, events: List[ConversationEvent]) -> List[ConversationEvent]:
        """Filters the provided list of events in some way and returns the result
        must be implemented by subclasses."""
        raise NotImplementedError


class All(ConversationFilter):
    """Just return all events unfiltered."""

    def satisfy(self, events: List[ConversationEvent]) -> List[ConversationEvent]:
        """Returns the event list provided."""
        return events


class AfterRestart(ConversationFilter):
    """Return events since the last restart."""

    def satisfy(self, events: List[ConversationEvent]) -> List[ConversationEvent]:
        """Finds the position of the last restart event in the list and returns everything after it."""
        return events[self._idx_after_latest_restart(events) :]

    @staticmethod
    def _idx_after_latest_restart(events: List[ConversationEvent]) -> int:
        """Return the idx of the most recent restart in the list of events.
        If the conversation has not been restarted, ``0`` is returned."""

        for i, event in enumerate(reversed(events)):
            if event.type_name == EventType.RESTARTED:
                return len(events) - i

        return 0


class Applied(ConversationFilter):
    """Returns all events that should be applied - w/o reverted events."""

    def satisfy(self, events: List[ConversationEvent]) -> List[ConversationEvent]:
        """Returns every applied event."""
        loop_names = [
            event.data_dict.get("name")
            for event in events
            if event.type_name == EventType.ACTIVE_LOOP and event.data_dict.get("name")
        ]

        applied_events = []

        for event in events:
            if event.type_name in [EventType.SESSION_STARTED, EventType.RESTARTED]:
                applied_events = []
            elif event.type_name == EventType.ACTION_REVERTED:
                self._undo_till_previous(EventType.ACTION_EXECUTED, applied_events)
            elif event.type_name == EventType.USER_UTTERANCE_REVERTED:
                # Seeing a user uttered event automatically implies there was
                # a listen event right before it, so we'll first rewind the
                # user utterance, then get the action right before it (also removes
                # the `action_listen` action right before it).
                self._undo_till_previous(EventType.USER_UTTERED, applied_events)
                self._undo_till_previous(EventType.ACTION_EXECUTED, applied_events)
            elif (
                event.type_name == EventType.ACTION_EXECUTED
                and event.action_name in loop_names
                and not self._first_loop_execution_or_unhappy_path(
                    event.action_name, applied_events
                )
            ):
                self._undo_till_previous_loop_execution(
                    event.action_name, applied_events
                )
            else:
                applied_events.append(event)

        return applied_events

    @staticmethod
    def _undo_till_previous(
        event_type: EventType, done_events: List[ConversationEvent]
    ) -> None:
        """Removes events from `done_events` until the first occurrence `event_type`
        is found which is also removed."""
        # list gets modified - hence we need to copy events!
        for e in reversed(done_events[:]):
            del done_events[-1]
            if e.type_name == event_type:
                break

    def _first_loop_execution_or_unhappy_path(
        self, loop_action_name: Text, applied_events: List[ConversationEvent]
    ) -> bool:
        next_action: Optional[Text] = None

        for event in reversed(applied_events):
            # Stop looking for a previous loop execution if there is a loop deactivation
            # event because it means that the current loop is running for the first
            # time and previous loop events belong to different loops.
            if (
                event.type_name == EventType.ACTIVE_LOOP
                and event.data_dict.get("name") is None
            ):
                return True

            if self._is_within_unhappy_path(loop_action_name, event, next_action):
                return True

            if event.type_name == EventType.ACTION_EXECUTED:
                # We found a previous execution of the loop and we are not within an
                # unhappy path.
                if event.action_name == loop_action_name:
                    return False

                # Remember the action as we need that to check whether we might be
                # within an unhappy path.
                next_action = event.action_name

        return True

    @staticmethod
    def _is_within_unhappy_path(
        loop_action_name: Text,
        event: ConversationEvent,
        next_action_in_the_future: Optional[Text],
    ) -> bool:
        """When actual users are talking to the action has to return an
         `ActionExecutionRejected` in order to enter an unhappy path."""
        loop_was_rejected_previously = (
            event.type_name == EventType.ACTION_EXECUTION_REJECTED
            and event.action_name == loop_action_name
        )
        # During the policy training there are no `ActionExecutionRejected` events
        # which let us see whether we are within an unhappy path. Hence, we check if a
        # different action was executed instead of the loop after last user utterance.
        other_action_after_latest_user_utterance = (
            event.type_name == EventType.USER_UTTERED
            and next_action_in_the_future is not None
            and next_action_in_the_future != loop_action_name
        )

        return loop_was_rejected_previously or other_action_after_latest_user_utterance

    @staticmethod
    def _undo_till_previous_loop_execution(
        loop_action_name: Text, done_events: List[ConversationEvent]
    ) -> None:
        """Returns all events from the current loop."""
        offset = 0
        for e in reversed(done_events[:]):
            if (
                e.type_name == EventType.ACTION_EXECUTED
                and e.action_name == loop_action_name
            ):
                break

            if e.type_name in [
                EventType.ACTION_EXECUTED,
                EventType.USER_UTTERED,
                EventType.DEFINE_PREV_USER_UTTERED_FEATURIZATION,
            ]:
                del done_events[-1 - offset]
            else:
                # Remember events which aren't unfeaturized to get the index right
                offset += 1
