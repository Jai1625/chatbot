import logging
from typing import Text, Optional, List

import sqlalchemy
from sqlalchemy.orm import Session

from rasax.community.application.conversation.filters import ConversationFilter
from rasax.community.caches.cached_query import CachedQuery
from rasax.community.database import ConversationEvent, Conversation
from rasax.community.database.service import DbService

logger = logging.getLogger(__name__)


class ConversationRepository(DbService):
    """Class that encapsulates db interactions for conversations and conversation events."""

    def __init__(
        self,
        session: Optional[Session] = None,
        cached_query: Optional[CachedQuery] = None,
    ) -> None:
        """Constructs `EventService` object.

        Args:
            session: DB session to be used with the service.
            cached_query: Cache that contrains recent SQL query results.
        """
        self._import_process_id = None
        self.cached_query = cached_query or CachedQuery()
        super().__init__(session)

    def get_conversation_events_by_verbosity(
        self,
        conversation_id: Text,
        verbosity_filter: ConversationFilter,
        until_time: Optional[float] = None,
        since_time: Optional[float] = None,
        rasa_environment_query: Optional[Text] = None,
    ) -> Optional[List[ConversationEvent]]:
        """Retrieves a list of conversation events and then filters them to the specified verbosity."""
        events = self.get_conversation_events(
            conversation_id, until_time, since_time, rasa_environment_query
        )

        if events or self.conversation_exists(conversation_id):
            return verbosity_filter.satisfy(events)

        return None

    def get_conversation_events(
        self,
        conversation_id: Text,
        until_time: Optional[float] = None,
        since_time: Optional[float] = None,
        rasa_environment_query: Optional[Text] = None,
    ) -> List[ConversationEvent]:
        """Gets conversation events based on the input parameters.

        Args:
            conversation_id: ID of a conversation.
            until_time: timestamp of the latest event to look for.
            since_time: timestamp of the earliest event to look for.
            rasa_environment_query: environment of rasa deployment.

        Returns:
            Conversation events that match the input parameters.
        """
        since_time = since_time or 0
        filter_query = [
            ConversationEvent.conversation_id == conversation_id,
            ConversationEvent.timestamp > since_time,
        ]

        if until_time:
            filter_query.append(ConversationEvent.timestamp <= until_time)

        if rasa_environment_query:
            filter_query.append(
                ConversationEvent.rasa_environment == rasa_environment_query
            )

        return (
            self.query(ConversationEvent)
            .filter(*filter_query)
            .order_by(ConversationEvent.timestamp.asc())
            .all()
        )

    def conversation_exists(self, conversation_id: Text) -> bool:
        """Returns a boolean value indicating whether the conversation exists"""
        query = self.query(Conversation).filter(
            Conversation.sender_id == conversation_id
        )

        return (
            self.query(sqlalchemy.literal(True)).filter(query.exists()).scalar() is True
        )
