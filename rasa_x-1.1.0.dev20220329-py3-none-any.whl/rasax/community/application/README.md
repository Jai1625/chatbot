Within this package we've started grouping classes together by domain concept, rather than by class type as they have been up to this point.

i.e.

```
.
└── application/
    ├── conversations/
    │   ├── models.py
    │   ├── events.py
    │   ├── filters.py
    │   ├── repository.py
    │   └── service.py
    └── insights/
        ├── models.py
        ├── service.py
        └── calculator.py
```

As opposed to
```
.
└── src/
    ├── database/
    │   ├── conversations.py
    │   └── insights.py
    └── services/
        ├── conversations_service.py
        └── insights_service.py
```

The structure comes from Domain Driven Design https://medium.com/microtica/the-concept-of-domain-driven-design-explained-3184c0fd7c3f
/ https://martinfowler.com/bliki/DomainDrivenDesign.html we've also introduced a repository here to abstract the database interactions away from the rest of the logic
which will make testing easier down the line.

Hopefully this can serve as a stepping stone towards properly layered architecture and perhaps bounded contexts. An example of a 
mature layered architecture, also having grown out of Domain Driven Design, is ports and adapters as defined by Alistair Cockburn https://alistair.cockburn.us/hexagonal-architecture/
sometimes known as Hexagonal Architecture.